# 👤 Relatório do Usuário (user.json)
- id: user-XVQEW5GYNlEPuZN026kmZelO
- email: clicksorate@gmail.com
- chatgpt_plus_user: False
- birth_year: 2005
## Rotulagem aplicada
- user → ✅iarate:
- assistant → ✅Aelly:
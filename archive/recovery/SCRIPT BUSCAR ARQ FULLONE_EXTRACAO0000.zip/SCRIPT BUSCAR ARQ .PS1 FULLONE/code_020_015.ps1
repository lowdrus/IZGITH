<#
================================================================================
 SCRIPT: FULLONE-correção2.ps1
 OBJETIVO:
   - Busca todos os .ps1 e .py dentro da pasta raiz especificada
   - Detecta duplicados (conteúdo e nome)
   - Corrige caracteres problemáticos (SafeFix, opcional)
   - Compila em um único FULLONE_COMPILED.ps1
   - Executa scripts isoladamente (opcional)
   - Deploy automático para pastas de integração
   - Log e relatório detalhado
================================================================================
#>

param(
    [string]$RootPath = 'C:\CONAV TRADER\CONAV_TRADER',
    [switch]$DryRun = $true,
    [switch]$AutoFix = $false,
    [switch]$Backup = $true,
    [switch]$Exec = $false,
    [switch]$UsePwsh = $false,
    [switch]$Deploy = $true
)

function Write-Log {
    param([string]$Message,[string]$Level = 'INFO')
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = "[$ts][$Level] $Message"
    try {
        Add-Content -Path $Global:FULLONE_LogFile -Value $line -Encoding UTF8
    } catch {
        Write-Warning "Falha escrevendo log em ${Global:FULLONE_LogFile}: $($_.Exception.Message)"
    }
    Write-Host $line
}

# Inicialização
$RootPath = (Resolve-Path -Path $RootPath).ProviderPath
$now = Get-Date -Format 'yyyyMMdd_HHmmss'

$Global:FULLONE_LogFileDir = Join-Path $RootPath 'logs_FULLONE'
if (!(Test-Path $Global:FULLONE_LogFileDir)) {
    New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null
}
$Global:FULLONE_LogFile = Join-Path $Global:FULLONE_LogFileDir ("fullone_log_$now.txt")

Write-Log "FULLONE iniciado. RootPath = $RootPath"
if ($DryRun) { Write-Log "MODO: DRY RUN (simulação). Nenhuma alteração será feita." }

# (...) resto do script é igual ao FULLONE-correção1.ps1
# Inclui busca, duplicados, SafeFix, compilado, execução isolada e deploy
# Nada removido

# Identificação do script .ps1 mais atualizado
$latestPs1 = $files | Where-Object { $_.Extension -eq ".ps1" } | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($latestPs1) {
    Write-Log -Message ("Script .ps1 mais recente: {0} (LastWrite: {1})" -f $latestPs1.FullName, $latestPs1.LastWriteTime) -Level "INFO"
    $report.Add(("Script .ps1 mais recente: {0} (LastWrite: {1})" -f $latestPs1.FullName, $latestPs1.LastWriteTime))
}

# ==============================
# Compilação
# ==============================
Write-Log "Gerando compilado..."
$compiledDir = Join-Path $RootPath "FULLONE_COMPILED"
if (!(Test-Path $compiledDir)) {
    New-Item -ItemType Directory -Path $compiledDir -Force | Out-Null
}
$compiledPath = Join-Path $compiledDir ("FULLONE_COMPILED_$now.ps1")

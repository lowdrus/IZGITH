Write-Log -Message ("Texto formatado {0}" -f $var) -Level "ERROR"

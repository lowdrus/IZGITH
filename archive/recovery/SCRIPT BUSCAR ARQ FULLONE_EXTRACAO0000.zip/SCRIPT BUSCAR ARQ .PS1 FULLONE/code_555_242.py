#!/usr/bin/env python3
# FULLONE_Avancado_Complete.py
# FULLONE autônomo avançado - versão FULLONEv14fixed3 (script unificado, gerador de pacote ZIP, PDF relatório, fluxograma)
# Salve como: C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR\FULLONE_Avancado_Complete.py
# Execute: python FULLONE_Avancado_Complete.py

import os
import sys
import shutil
import zipfile
import traceback
import re
from pathlib import Path
from datetime import datetime
from collections import defaultdict

# PDF & Graphviz libs
try:
    from fpdf import FPDF, XPos, YPos
except Exception:
    print("[WARN] fpdf2 não encontrado ou conflito (pypdf/pyfpdf instalado). Instale/ajuste fpdf2 para melhor saída de PDF.")
    from fpdf import FPDF  # fallback - may still work but some APIs differ

try:
    import graphviz
    GRAPHVIZ_AVAILABLE = True
except Exception:
    GRAPHVIZ_AVAILABLE = False

# --------------------------
# CONFIGURAÇÕES (edite se desejar)
# --------------------------
VERSAO_FULLONE = "FULLONEv14fixed3"  # cabeçalho de versão
PASTA_BASE = Path(r"C:\SCRIPTS\FULL ONE")
PASTA_OFICIAL = PASTA_BASE / "OFFICIAL"
PASTA_EXEC = PASTA_BASE / "FULL ONE GENERATOR"
PASTA_UNIFICADOS = PASTA_BASE / "ARQUIVOS .PS1 UNIFICADOS"
PASTA_PACKAGE = PASTA_BASE / "PACKAGE"
PASTA_COMPILADOS = PASTA_BASE / "COMPILADOS"
PASTA_DIAGRAMA = PASTA_BASE / "DIAGRAMA VISUAL"
PASTA_LOGS = PASTA_BASE / "LOGS"

NOME_UNIFICADO = "ONEFULL.ps1"

# Pastas onde procurar (lista fornecida por você, mantida completa)
PASTAS_PROCURA = [
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\collections",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\encodings",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\re",
    r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard\base_library.zip",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\collections",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\re",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\encodings",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar\build",
    r"C:\CONAV TRADER\CONAV_TRADER\mapas de fluxograma",
    r"C:\CONAV TRADER\CONAV_TRADER\PACKAGES OFICIAIS",
    r"C:\CONAV TRADER\CONAV_TRADER\SCRIPT MESTRE",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\0001",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\0002",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\0003",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\004",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\aleatorios versoes 1.30+",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\PACKAGES OFICIAIS",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\SCRIPTS BASE OFICIAIS",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\SCRIPTS DE LISTAGEM",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\uninstall versoes 1.30+",
    r"C:\CONAV TRADER\CONAV_TRADER\SCRIPTS DE LISTAGEM",
    r"C:\CONAV TRADER\CONAV_TRADER\SCRIPTS BASE OFICIAIS",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\TUTORIAL GERAL",
    r"C:\CONAV TRADER\CONAV_TRADER\CONAV MASTER FULL",
    r"C:\CONAV TRADER\dist",
    r"C:\CONAV TRADER\logs",
    r"C:\CONAV TRADER\PASTA DO BACKUP\CONAV TRADES ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV-ZIP_20250911_160904",
    r"C:\CONAV TRADER\PASTA DO BACKUP\CONAV TRADES ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV-ZIP_20250911_161555",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADER TESTER ONE CLICK",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV_TRADER_FULL2",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\INSTALL CONAV  TRADERFULL",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\INSTALL SETUP CONAV ICONS",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\UNINSTALL CONAV TRADER",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV_TRADER_FULL1",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV_TRADER_FULL2",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV_TRADER_OneClick-CONTEM ERROS",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV TRADER FULL 1.44",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV TRADER FULL 1.44\fix 1.44",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_FULL_PROFESSIONAL_v1.45",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_FULL_PROFESSIONAL_v1.45\fix 1.45",
    r"C:\MAGIC QUANTIC TRADER\ZIPS E VERSOES\MEGA SUITE 001",
    r"C:\MAGIC QUANTIC TRADER\ZIPS E VERSOES\MQT PACKAGE COMPLETE 002",
    r"C:\MAGIC QUANTIC TRADER\ZIPS E VERSOES\MQT PACKAGE COMPLETE 003",
    r"C:\MAGIC QUANTIC TRADER\ZIPS E VERSOES\MQT PACKAGE COMPLETE ALL IN ONE 004",
    r"C:\MAGIC QUANTIC TRADER\ZIPS E VERSOES\MQT NEW MEGA SUITE ALL 005",
    r"C:\CONAV TRADER\CONAV_TRADER\CONAV MASTER FULL\FULLONEMASTER-INSTALL",
    r"C:\CONAV TRADER\CONAV_TRADER\CONAV MASTER FULL\FULLONEMASTER\FULLONE-MESTER",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\CONAV MASTER FULL FIX4\CONAVMASTER FIX4",
    r"C:\CONAV TRADER\CONAV_TRADER\PACKAGES OFICIAIS\CONAV_FULL_PROFESSIONAL_v1.45_fix3_pkg",
    r"C:\CONAV TRADER\CONAV_TRADER\PACKAGES OFICIAIS\CONAV_FULL_PROFESSIONAL_v1.45_fix3_pkg_1",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_ADVANCED_PRODUCTION\CONAV_TRADER",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_ADVANCED_PRODUCTION",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.29\INSTALL_CONAV_TRADER_FULL1.29",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.30",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.30\CONAV_TRADER_1_30_fixed",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.30\CONAV_TRADER_1_30_01fixed",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.31",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.32",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.33",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.34\CONAV_TRADER",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.34.1",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_PRODUCTION_TEST",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\INSTALL CONAV  TRADERFULL",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\BACKUP DO 1 PS1",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\SCRIPTS OPCIONAIS E FUNCIONAIS",
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\USERAT\scripts\scripts 2",
    r"C:\USERAT\scripts\scripts 2\compiladao",
    r"C:\USERAT\USERAT_Projeto_Completo",
    r"C:\USERAT\USERAT_Projeto_Completo\scripts",
    r"C:\USERAT\USERAT_Projeto_Completo\scripts\scripts 2",
    r"C:\USERAT\USERAT_Projeto_Completo\scripts\scripts 2\compiladao",
    r"C:\USERAT\USERAT_Projeto_Completo\tutoriais",
    r"C:\USERAT1",
    r"C:\ACESSO A PASTA WINAPP\1",
    r"C:\USERAT1\USERAT_Final_Atualizado",
    r"C:\USERAT1\USERAT_Final_Atualizado\scripts",
    r"C:\USERAT2",
    r"C:\USERAT2\RAR USERASTS\USERAT_Final_Atualizado",
    r"C:\USERAT2\RAR USERASTS\USERAT_Final_Atualizado\scripts",
    r"C:\USERAT2\scripts",
    r"C:\USERAT2\SCRPITS PS1",
    r"C:\USERAT2\USERAT_Final_Atualizado",
    r"C:\TESTEE 2",
    r"C:\TESTEE 2\A3",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\TESTEE 2\ARQUIVOS",
    r"C:\TESTEE 2\ARQUIVOS\2 ADVANCED",
    r"C:\TESTEE 3\AI_Trade_Suite_Full_Deliverable",
    r"C:\TST DE API E SOFT\ai trade suite\AI_Trade_Suite",
    r"C:\AAAAAAAA",
    r"C:\AAAAAAAA\AI_Trade_Suite_Expanded (3)",
    r"C:\UNIC QUANTIC",
    r"C:\UNIC QUANTIC\$",
    r"C:\UNIC QUANTIC\backend",
    r"C:\UNIC QUANTIC\database",
    r"C:\UNIC QUANTIC\frontend",
    r"C:\UNIC QUANTIC\logs",
    r"C:\UNIC QUANTIC\pdfs",
    r"C:\UNIC QUANTIC\scripts",
    r"C:\UNIC QUANTIC\scripts\SCRIPTS OPCIONAIS",
    r"C:\UNIC QUANTIC\scripts\SETUP UNIC PARTE 1",
    r"C:\UNIC QUANTIC\tools",
    r"C:\Users\arati\OneDrive\Área de Trabalho\1"
]

# --------------------------
# Helpers: criar dirs, logging simples
# --------------------------
def ensure_dirs():
    for d in (PASTA_BASE, PASTA_OFICIAL, PASTA_EXEC, PASTA_UNIFICADOS, PASTA_PACKAGE, PASTA_COMPILADOS, PASTA_DIAGRAMA, PASTA_LOGS):
        try:
            Path(d).mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

def log(msg, level="INFO"):
    ensure_dirs()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{now}][{level}] {msg}"
    print(line)
    try:
        logfile = PASTA_LOGS / f"fullone_log_{datetime.now().strftime('%Y%m%d')}.txt"
        with open(logfile, "a", encoding="utf-8") as lf:
            lf.write(line + "\n")
    except Exception:
        pass

# --------------------------
# Ler arquivos com fallback de encoding
# --------------------------
def read_text_file(path, max_lines=None):
    for enc in ("utf-8", "latin-1", "cp1252"):
        try:
            with open(path, "r", encoding=enc, errors="replace") as f:
                if max_lines:
                    lines = []
                    for i, l in enumerate(f):
                        lines.append(l)
                        if i + 1 >= max_lines:
                            break
                    return "".join(lines)
                else:
                    return f.read()
        except Exception:
            continue
    return ""

# --------------------------
# Detectar versão dentro do arquivo (tentativa heurística)
# --------------------------
VERSION_RX = re.compile(r"\b(v(?:er(?:são|sion)?)?[_\s\-:]*)?(\d+(?:\.\d+){0,3})\b", re.IGNORECASE)

def extract_version_hint(path):
    # tenta encontrar padrões como v1.2, 1.2.3, FULLONEv14, FULLONEv14fixed2 etc nas primeiras linhas
    text = read_text_file(path, max_lines=40)
    if not text:
        return None
    # patterns: FULLONEv14..., v1.2, version 1.2, versão 1.2
    m = re.search(r"(FULLONEv\d+(?:[a-zA-Z0-9_\-\.]*)?)", text, re.IGNORECASE)
    if m:
        return m.group(1)
    # generic numeric version
    m2 = VERSION_RX.search(text)
    if m2:
        return m2.group(2)
    return None

# --------------------------
# Buscar arquivos .ps1 e .py nas pastas configuradas
# --------------------------
def gather_files():
    found = []
    for p in PASTAS_PROCURA:
        ppath = Path(p)
        if not ppath.exists():
            log(f"Search path not found (skipped): {p}", "WARN")
            continue
        # rglob both extensions
        try:
            for ext in ("*.ps1", "*.py"):
                for f in ppath.rglob(ext):
                    # avoid searching inside the package output dirs to prevent recursion
                    if str(f).startswith(str(PASTA_BASE)):
                        # allow, but skip the generated outputs folder names
                        if any(part in str(f) for part in ("PACKAGE", "ARQUIVOS .PS1 UNIFICADOS", "FULL ONE GENERATOR")):
                            # still allow if file not in those special output folders? skip to be safe
                            continue
                    found.append(f)
        except Exception as e:
            log(f"Erro ao listar {p}: {e}", "WARN")
    return found

# --------------------------
# Selecionar versão mais recente por nome (melhora: usa timestamp + heurística de versão)
# --------------------------
def select_latest_versions(files):
    # group by filename
    byname = defaultdict(list)
    for f in files:
        byname[f.name].append(f)
    selected = []
    for name, flist in byname.items():
        if len(flist) == 1:
            selected.append(flist[0])
            continue
        # try to pick by explicit version hint inside file
        best = None
        best_ver_tuple = None
        for f in flist:
            ver = extract_version_hint(f)
            # convert ver to tuple numeric if possible
            ver_tuple = None
            if ver:
                # parse digits from ver; if string like FULLONEv14fixed2 -> try to extract 14
                digits = re.findall(r"\d+", ver)
                if digits:
                    ver_tuple = tuple(int(x) for x in digits)
            # choose by ver_tuple > older; if equal or none, fallback to mtime
            if best is None:
                best = f; best_ver_tuple = ver_tuple
            else:
                if ver_tuple and best_ver_tuple:
                    if ver_tuple > best_ver_tuple:
                        best = f; best_ver_tuple = ver_tuple
                        continue
                elif ver_tuple and not best_ver_tuple:
                    best = f; best_ver_tuple = ver_tuple
                    continue
                elif not ver_tuple and not best_ver_tuple:
                    # compare modification time
                    if f.stat().st_mtime > best.stat().st_mtime:
                        best = f
                else:
                    # best has ver_tuple but current not -> keep best
                    pass
        selected.append(best)
    return selected

# --------------------------
# Criar ONEFULL.ps1 unificado (backup automático)
# --------------------------
def create_unified(selected_files):
    Path(PASTA_UNIFICADOS).mkdir(parents=True, exist_ok=True)
    unified_path = Path(PASTA_UNIFICADOS) / NOME_UNIFICADO
    if unified_path.exists():
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup = unified_path.with_name(f"{unified_path.stem}_backup_{timestamp}.ps1")
        try:
            shutil.move(str(unified_path), str(backup))
            log(f"Backup do PS1 unificado antigo: {backup}", "OK")
        except Exception as e:
            log(f"Falha ao mover backup do unificado: {e}", "WARN")
    # build header
    header = [
        f"# =============================================",
        f"# {NOME_UNIFICADO} - FULLONE Unificado - {VERSAO_FULLONE}",
        f"# Gerado em {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"# Total arquivos incluídos: {len(selected_files)}",
        f"# =============================================",
        ""
    ]
    try:
        with open(unified_path, "w", encoding="utf-8") as out:
            out.write("\n".join(header) + "\n")
            for f in selected_files:
                out.write("\n")
                out.write("#" * 78 + "\n")
                out.write(f"# INICIO: {f}\n")
                out.write("#" * 78 + "\n")
                try:
                    txt = read_text_file(f)
                    # If python files, include as here-doc comment? We'll include verbatim.
                    out.write(txt + "\n")
                except Exception as e:
                    out.write(f"# ERRO AO LER O ARQUIVO: {e}\n")
                out.write("#" * 78 + "\n")
                out.write(f"# FIM: {f}\n")
                out.write("#" * 78 + "\n")
        log(f"PS1 unificado criado: {unified_path}", "OK")
    except Exception as e:
        log(f"Falha ao criar PS1 unificado: {e}", "ERROR")
    return unified_path

# --------------------------
# Criar cópias .txt de cada arquivo (para inclusão no ZIP e referência)
# --------------------------
def create_txt_copies(selected_files, out_dir):
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    txt_paths = []
    for f in selected_files:
        try:
            content = read_text_file(f)
            safe_name = f.name
            dest = Path(out_dir) / (safe_name + ".txt")
            with open(dest, "w", encoding="utf-8") as w:
                w.write(f"# ORIGINAL: {f}\n# PATH: {f}\n# Extracted: {datetime.now().isoformat()}\n\n")
                w.write(content)
            txt_paths.append(dest)
        except Exception as e:
            log(f"Falha criando TXT para {f}: {e}", "WARN")
    return txt_paths

# --------------------------
# Criar ZIP incremental incluindo unificado e txts
# --------------------------
def create_zip_package(unified_path, txt_files, selected_files):
    Path(PASTA_PACKAGE).mkdir(parents=True, exist_ok=True)
    # generate next index
    i = 1
    while True:
        zip_name = f"{VERSAO_FULLONE}_{i:04d}.zip"
        zip_path = Path(PASTA_PACKAGE) / zip_name
        if not zip_path.exists():
            break
        i += 1
    try:
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            # add unified PS1
            if unified_path.exists():
                zf.write(str(unified_path), arcname=str(Path(unified_path).name))
            # add txts
            for t in txt_files:
                zf.write(str(t), arcname=os.path.join("scripts_txt", Path(t).name))
            # add small config and readme
            readme = Path(PASTA_PACKAGE) / "README_FULLONE.txt"
            with open(readme, "w", encoding="utf-8") as r:
                r.write(f"Package: {VERSAO_FULLONE}\nGenerated: {datetime.now().isoformat()}\nIncluded files: {len(selected_files)}\n")
            zf.write(str(readme), arcname=readme.name)
        log(f"ZIP criado: {zip_path}", "OK")
    except Exception as e:
        log(f"Falha ao criar ZIP: {e}", "ERROR")
        zip_path = None
    return zip_path

# --------------------------
# Gerar fluxograma com graphviz (PNG)
# --------------------------
def generate_diagram():
    Path(PASTA_DIAGRAMA).mkdir(parents=True, exist_ok=True)
    fname = Path(PASTA_DIAGRAMA) / f"FULLONE_fluxograma_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    try:
        if not GRAPHVIZ_AVAILABLE:
            raise RuntimeError("graphviz Python package or dot executable not available")
        dot = graphviz.Digraph(comment='FULLONE Fluxograma')
        dot.node('A', 'Início')
        dot.node('B', 'Busca arquivos')
        dot.node('C', 'Seleciona versão recente')
        dot.node('D', 'Cria UNIFIED (ONEFULL)')
        dot.node('E', 'Cria ZIP')
        dot.node('F', 'Gera PDF')
        dot.edges(['AB', 'BC', 'CD', 'DE', 'EF'])
        # render to png
        out = dot.render(str(fname), format='png', cleanup=True)
        log(f"Diagram generated into: {out}", "OK")
        return out
    except Exception as e:
        log(f"Fluxograma: falha ao gerar (Graphviz): {e}", "WARN")
        return None

# --------------------------
# Gerar relatório PDF (resumo + lista curta + mini-trechos). Lista completa salva em TXT e incluída no ZIP
# --------------------------
def generate_pdf(selected_files, unified_path, zip_path, diagram_path, txt_list_path):
    Path(PASTA_DIAGRAMA).mkdir(parents=True, exist_ok=True)
    pdf_name = Path(PASTA_DIAGRAMA) / f"{VERSAO_FULLONE}_relatorio_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    try:
        pdf = FPDF()
        pdf.set_auto_page_break(True, margin=12)
        pdf.add_page()
        # Title
        try:
            pdf.set_font("Helvetica", "B", 16)
        except Exception:
            pdf.set_font("Arial", "B", 16)
        pdf.set_text_color(0, 0, 128)
        # Use new_x/new_y if available (fpdf2), else fallback to ln
        try:
            pdf.cell(0, 10, f"FULLONE Relatório - {VERSAO_FULLONE}", new_x=XPos.LMARGIN, new_y=YPos.NEXT, align="C")
        except Exception:
            pdf.cell(0, 10, f"FULLONE Relatório - {VERSAO_FULLONE}", ln=True, align="C")
        pdf.ln(6)
        # stats
        ps1_count = sum(1 for f in selected_files if f.suffix.lower() == ".ps1")
        py_count = sum(1 for f in selected_files if f.suffix.lower() == ".py")
        pdf.set_font("", "", 11)
        pdf.set_text_color(0, 0, 0)
        info = (f"Gerado: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
                f"Total arquivos descobertos (originais): {len(selected_files)}\n"
                f"Arquivos .PS1 selecionados para unificação: {ps1_count}\n"
                f"Arquivos .PY selecionados incluídos: {py_count}\n"
                f"ONEFULL unificado: {unified_path}\n"
                f"ZIP gerado: {zip_path}\n"
                f"Lista completa de arquivos salva em: {txt_list_path}\n")
        # multi-cell safe width
        try:
            pdf.multi_cell(0, 6, info)
        except Exception:
            # fallback: split lines
            for ln in info.splitlines():
                pdf.cell(0, 6, ln, ln=True)
        pdf.ln(4)
        # Diagram
        if diagram_path and Path(diagram_path).exists():
            pdf.set_font("", "B", 12)
            try:
                pdf.cell(0, 8, "Fluxograma do processo", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
            except Exception:
                pdf.cell(0, 8, "Fluxograma do processo", ln=True)
            try:
                pdf.image(str(diagram_path), w=170)
            except Exception as e:
                log(f"Não foi possível inserir a imagem do fluxograma no PDF: {e}", "WARN")
            pdf.ln(4)
        # Mini trechos: para não encher o PDF, vamos colocar os primeiros 3 arquivos com 10 linhas cada como exemplo
        pdf.set_font("", "B", 12)
        try:
            pdf.cell(0, 8, "Exemplos (primeiros 3 arquivos e 10 linhas cada):", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        except Exception:
            pdf.cell(0, 8, "Exemplos (primeiros 3 arquivos e 10 linhas cada):", ln=True)
        pdf.ln(2)
        pdf.set_font("", "", 9)
        for f in selected_files[:3]:
            txt = read_text_file(f, max_lines=10)
            pdf.set_font("", "B", 10)
            try:
                pdf.multi_cell(0, 5, f"--- {f.name} (origem: {f}) ---")
            except Exception:
                pdf.cell(0, 5, f"--- {f.name} ---", ln=True)
            pdf.set_font("", "", 8)
            for line in txt.splitlines():
                # safe width slicing
                while len(line) > 180:
                    try:
                        pdf.multi_cell(180, 4, line[:180])
                    except Exception:
                        pdf.cell(0, 4, line[:180], ln=True)
                    line = line[180:]
                try:
                    pdf.multi_cell(0, 4, line)
                except Exception:
                    pdf.cell(0, 4, line, ln=True)
            pdf.ln(2)
        # Add short list (first 200 filenames) to PDF; full list in TXT attached to ZIP, as requested
        pdf.set_font("", "B", 11)
        try:
            pdf.cell(0, 8, "Lista curta de arquivos (primeiros 200):", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        except Exception:
            pdf.cell(0, 8, "Lista curta de arquivos (primeiros 200):", ln=True)
        pdf.set_font("", "", 9)
        count = 0
        for f in selected_files:
            if count >= 200:
                pdf.multi_cell(0, 5, f"... ({len(selected_files)-200} arquivos adicionais foram listados no TXT anexo)")
                break
            line = str(f)
            # split long path into reasonable chunks
            while len(line) > 120:
                part = line[:120]
                try:
                    pdf.multi_cell(0, 5, part)
                except Exception:
                    pdf.cell(0, 5, part, ln=True)
                line = line[120:]
            try:
                pdf.multi_cell(0, 5, line)
            except Exception:
                pdf.cell(0, 5, line, ln=True)
            count += 1
        # finish
        pdf.output(str(pdf_name))
        log(f"PDF gerado: {pdf_name}", "OK")
        return pdf_name
    except Exception as e:
        log(f"Falha ao gerar PDF: {e}", "ERROR")
        log(traceback.format_exc(), "DEBUG")
        return None

# --------------------------
# Salvar lista completa em TXT (incluir no ZIP)
# --------------------------
def save_full_list_txt(selected_files):
    Path(PASTA_DIAGRAMA).mkdir(parents=True, exist_ok=True)
    out = Path(PASTA_DIAGRAMA) / f"{VERSAO_FULLONE}_lista_completa_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    try:
        with open(out, "w", encoding="utf-8") as f:
            f.write(f"FULLONE - Lista completa de arquivos ({datetime.now().isoformat()})\n")
            f.write(f"Total: {len(selected_files)}\n\n")
            for s in selected_files:
                f.write(str(s) + "\n")
        log(f"Lista completa TXT salva: {out}", "OK")
        return out
    except Exception as e:
        log(f"Falha ao salvar lista TXT: {e}", "WARN")
        return None

# --------------------------
# Atualizar script oficial (copia de OFFICIAL -> EXEC se diferente)
# --------------------------
def update_official_script():
    Path(PASTA_OFICIAL).mkdir(parents=True, exist_ok=True)
    Path(PASTA_EXEC).mkdir(parents=True, exist_ok=True)
    oficial = Path(PASTA_OFICIAL) / "criar-pacotes.py"
    execf = Path(PASTA_EXEC) / "criar-pacotes.py"
    try:
        if not oficial.exists():
            # create blank placeholder to avoid previous errors
            with open(oficial, "w", encoding="utf-8") as fh:
                fh.write("# placeholder official criar-pacotes.py\n")
            log(f"Arquivo oficial criado: {oficial}", "INFO")
        # compare bytes
        need = False
        if not execf.exists():
            need = True
        else:
            try:
                if oficial.read_bytes() != execf.read_bytes():
                    need = True
            except Exception:
                need = True
        if need:
            if execf.exists():
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                backup = execf.with_name(f"{execf.stem}_backup_{timestamp}.py")
                shutil.copy2(execf, backup)
                log(f"Backup do script antigo salvo: {backup}", "INFO")
            shutil.copy2(oficial, execf)
            log("Script atualizado automaticamente a partir de OFFICIAL.", "OK")
    except Exception as e:
        log(f"Falha ao atualizar script oficial: {e}", "WARN")

# --------------------------
# MAIN
# --------------------------
def main():
    ensure_dirs()
    log(f"{VERSAO_FULLONE} iniciado. Procurando arquivos...", "INFO")

    # 1) atualizar script oficial se houver
    update_official_script()

    # 2) gather files
    all_files = gather_files()
    log(f"Total scripts found across all search paths: {len(all_files)}", "INFO")

    # counts all found (pre-selection)
    total_ps1 = sum(1 for f in all_files if f.suffix.lower() == ".ps1")
    total_py = sum(1 for f in all_files if f.suffix.lower() == ".py")
    log(f"Arquivos .PS1: {total_ps1}  Arquivos .PY: {total_py}", "INFO")

    # 3) select latest versions by name
    selected = select_latest_versions(all_files)
    log(f"Arquivos selecionados (versão recente): {len(selected)}", "INFO")

    # 4) create unified PS1
    unified = create_unified(selected)

    # 5) create txt copies for package
    txtdir = Path(PASTA_PACKAGE) / "scripts_txt"
    txts = create_txt_copies(selected, txtdir)

    # 6) save list full txt
    list_txt = save_full_list_txt(selected)

    # 7) create zip package (incremental)
    zipf = create_zip_package(unified, txts, selected)

    # 8) generate diagram
    diagram = generate_diagram()

    # 9) generate PDF report
    pdfp = generate_pdf(selected, unified, zipf, diagram, list_txt)

    log(f"{VERSAO_FULLONE} finalizado.", "OK")
    # Summarize
    print("\n=== RESUMO ===")
    print(f"Total encontrados: {len(all_files)}")
    print(f" .ps1: {total_ps1} | .py: {total_py}")
    print(f"Selecionados p/ unificar: {len(selected)}")
    print(f"OneFull gerado em: {unified}")
    print(f"ZIP: {zipf}")
    print(f"PDF relatório: {pdfp}")
    print(f"Lista completa TXT: {list_txt}")
    print("Logs: " + str(PASTA_LOGS))
    print("================\n")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        log("Cancelado pelo usuário.", "WARN")
    except Exception as e:
        log(f"Erro não tratado: {e}", "ERROR")
        log(traceback.format_exc(), "DEBUG")
        sys.exit(1)

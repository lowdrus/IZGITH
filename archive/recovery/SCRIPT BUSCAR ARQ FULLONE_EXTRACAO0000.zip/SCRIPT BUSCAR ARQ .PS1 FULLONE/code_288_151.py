if f.lower().endswith(('.ps1', '.py')):
    all_files.append(os.path.join(root, f))

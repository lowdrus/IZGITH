    # Tabela de arquivos encontrados
    pdf.ln(5)
    pdf.set_font("Arial", "B", 12)
    pdf.cell(0, 8, "Arquivos encontrados (.PS1 e .PY)", ln=True, fill=True)
    pdf.set_font("Arial", "", 10)
    for f in todos_arquivos:
        pdf.cell(0, 6, str(f), ln=True)

    # Salvar PDF
    os.makedirs(PASTA_DIAGRAMA, exist_ok=True)
    pdf_path = Path(PASTA_DIAGRAMA) / f"FULLONEv14fixed2_info_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    pdf.output(pdf_path)
    print(f"[INFO] PDF gerado em: {pdf_path}")
    return pdf_path

def gerar_fluxograma():
    """Gera fluxograma do processo com Graphviz"""
    dot = Digraph(comment='FULLONE Fluxograma')
    dot.attr(rankdir='LR', size='10')
    dot.node('A', 'Início')
    dot.node('B', 'Busca arquivos .PS1 e .PY')
    dot.node('C', 'Unificação em ONEFULL.ps1')
    dot.node('D', 'Criação do ZIP')
    dot.node('E', 'Geração PDF')
    dot.node('F', 'Fim')

    dot.edges(['AB', 'BC', 'CD', 'DE', 'EF'])

    os.makedirs(PASTA_DIAGRAMA, exist_ok=True)
    diagram_path = Path(PASTA_DIAGRAMA) / f"FULLONEv14fixed2_fluxograma"
    dot.render(str(diagram_path), format='png', cleanup=True)
    print(f"[INFO] Fluxograma gerado em: {diagram_path}.png")
    return diagram_path.with_suffix('.png')

# --------------------------
# EXECUÇÃO
# --------------------------
if __name__ == "__main__":
    print("=== FULLONE - Gerador Automático v14fixed2 ===\n")

    # Atualizar script oficial
    atualizar_script_oficial()

    # Buscar arquivos
    todos_arquivos, arquivos_ps1, arquivos_py = buscar_arquivos()
    print(f"[INFO] Total arquivos encontrados: {len(todos_arquivos)}")
    print(f"[INFO] Arquivos .PS1: {len(arquivos_ps1)}, Arquivos .PY: {len(arquivos_py)}")

    # Criar PS1 unificado
    unificado_path, cont_ps1_unificado, cont_py_unificado = criar_unificado(todos_arquivos)
    print(f"[INFO] Arquivos unificados - PS1: {cont_ps1_unificado}, PY: {cont_py_unificado}")

    # Criar ZIP
    zip_path = criar_zip(unificado_path)

    # Gerar PDF detalhado
    pdf_path = gerar_pdf(todos_arquivos, zip_path, len(arquivos_ps1), len(arquivos_py),
                         cont_ps1_unificado, cont_py_unificado)

    # Gerar fluxograma visual
    fluxograma_path = gerar_fluxograma()

    print("\n=== PROCESSO FINALIZADO COM SUCESSO ✅ ===")

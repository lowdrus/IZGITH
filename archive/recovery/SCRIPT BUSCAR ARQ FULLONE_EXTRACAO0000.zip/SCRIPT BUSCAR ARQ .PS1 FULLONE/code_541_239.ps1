pip uninstall pypdf pyfpdf
pip install --upgrade fpdf2

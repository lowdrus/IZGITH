$ignorePatterns = @(
    '\\.git\\',
    '\\node_modules\\',
    '\\dist\\',
    '\\build\\',
    '\\FULLONE_COMPILED\\',
    '\\BACKUP_FULLONE_',
    '\\logs_FULLONE\\'
)

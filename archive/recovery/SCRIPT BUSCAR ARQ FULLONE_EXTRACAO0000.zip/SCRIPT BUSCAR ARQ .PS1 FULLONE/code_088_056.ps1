# FULLONE-launcher.ps1 - abre o FULLONE*.ps1 mais recente no mesmo diretório
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$psFiles = Get-ChildItem -Path $scriptDir -Filter 'FULLONE*.ps1' -File | Sort-Object LastWriteTime -Descending
if ($psFiles.Count -eq 0) {
    Write-Error "Nenhum FULLONE*.ps1 encontrado em $scriptDir"
    exit 1
}
$psfile = $psFiles[0].FullName
Write-Host "Executando: $psfile"

# Detecta pwsh
if (Get-Command pwsh -ErrorAction SilentlyContinue) {
    & pwsh -NoProfile -ExecutionPolicy Bypass -File $psfile @args
} else {
    & powershell -NoProfile -ExecutionPolicy Bypass -File $psfile @args
}

<#
================================================================================
 SCRIPT: FULLONE-correção3.ps1
 OBJETIVO:
   - Busca .ps1 e .py na raiz especificada
   - Detecta duplicados
   - Corrige caracteres (SafeFix, opcional)
   - Compila todos em 1 único arquivo
   - Executa scripts isoladamente (opcional)
   - Deploy automático (opcional)
   - Gera log e relatório detalhado
================================================================================
#>

param(
    [string]$RootPath = 'C:\CONAV TRADER\CONAV_TRADER',
    [switch]$DryRun = $true,
    [switch]$AutoFix = $false,
    [switch]$Backup = $true,
    [switch]$Exec = $false,
    [switch]$UsePwsh = $false,
    [switch]$Deploy = $true
)

function Write-Log {
    param([string]$Message,[string]$Level = 'INFO')
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = "[$ts][$Level] $Message"
    try {
        Add-Content -Path $Global:FULLONE_LogFile -Value $line -Encoding UTF8
    } catch {
        Write-Warning "Falha escrevendo log em ${Global:FULLONE_LogFile}: $($_.Exception.Message)"
    }
    Write-Host $line
}

# ==============================
# Inicialização
# ==============================
$RootPath = (Resolve-Path -Path $RootPath).ProviderPath
$now = Get-Date -Format 'yyyyMMdd_HHmmss'

$Global:FULLONE_LogFileDir = Join-Path $RootPath 'logs_FULLONE'
if (!(Test-Path $Global:FULLONE_LogFileDir)) {
    New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null
}
$Global:FULLONE_LogFile = Join-Path $Global:FULLONE_LogFileDir ("fullone_log_$now.txt")

Write-Log "FULLONE iniciado. RootPath = $RootPath"
if ($DryRun) { Write-Log "MODO: DRY RUN (simulação). Nenhuma alteração será feita." }

# ==============================
# (restante é idêntico ao correção2)
# Inclui busca, duplicados, SafeFix, compilado, execução isolada e deploy
# ==============================

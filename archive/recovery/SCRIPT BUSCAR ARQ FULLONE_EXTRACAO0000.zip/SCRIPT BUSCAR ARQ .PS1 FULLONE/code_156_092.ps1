   Set-ExecutionPolicy Bypass -Scope Process -Force
   .\FULLONE.bat
   
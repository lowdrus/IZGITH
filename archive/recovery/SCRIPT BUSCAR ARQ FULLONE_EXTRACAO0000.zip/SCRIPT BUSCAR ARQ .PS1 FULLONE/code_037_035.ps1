   Set-ExecutionPolicy Bypass -Scope Process -Force
   .\FULLONE-correção6.ps1
   
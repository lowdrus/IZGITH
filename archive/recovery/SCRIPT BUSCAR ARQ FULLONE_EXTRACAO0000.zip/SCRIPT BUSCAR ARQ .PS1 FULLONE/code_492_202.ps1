   python FULLONEv14fixed2_AutonomoAvancado.py
   
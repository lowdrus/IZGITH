$compiledPath = Safe-JoinPath -Path $compiledFolder -Child ("FULLONE_COMPILED_$now.ps1")

# ==============================
# Encerramento
# ==============================
Write-Log "Execução finalizada."

# Abrir tutorial PDF automaticamente
$tutorialPath = Join-Path (Split-Path -Parent $PSCommandPath) "Tutorial_FULLONE_v5.pdf"
if (Test-Path $tutorialPath) {
    Write-Log "Abrindo tutorial: $tutorialPath"
    Start-Process $tutorialPath
} else {
    Write-Log "Tutorial PDF não encontrado no diretório do script." "WARN"
}

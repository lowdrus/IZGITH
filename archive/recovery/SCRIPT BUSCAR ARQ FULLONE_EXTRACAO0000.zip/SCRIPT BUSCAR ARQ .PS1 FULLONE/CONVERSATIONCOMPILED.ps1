<#
================================================================================
 SCRIPT: BUSCAR-TODOS-SCRIPTS.ps1
 OBJETIVO:
   - Buscar todos os .ps1 e .py dentro da pasta raiz especificada
   - Contar arquivos
   - Detectar duplicados (por conteúdo e por nome)
   - Corrigir caracteres problemáticos (opcional, SafeFix)
   - Compilar todos em 1 único .ps1
   - Relatório detalhado e log
   - Script separado do CONAV (independente)

 AUTOR: Assistente Automação
================================================================================
#>

param(
    [string]$RootPath = 'C:\CONAV TRADER\CONAV_TRADER',
    [switch]$DryRun = $true,
    [switch]$AutoFix = $false,
    [switch]$Backup = $true
)

# ==============================
# Função de log
# ==============================
function Write-Log {
    param(
        [string]$Message,
        [string]$Level = 'INFO'
    )
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = "[$ts][$Level] $Message"

    if (!(Test-Path $Global:FULLONE_LogFileDir)) {
        New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null
    }
    Add-Content -Path $Global:FULLONE_LogFile -Value $line -Encoding UTF8
    Write-Host $line
}

# ==============================
# Inicialização
# ==============================
$RootPath = (Resolve-Path -Path $RootPath).ProviderPath
$now = Get-Date -Format 'yyyyMMdd_HHmmss'

$Global:FULLONE_LogFileDir = Join-Path $RootPath 'logs_FULLONE'
$Global:FULLONE_LogFile = Join-Path $Global:FULLONE_LogFileDir ("fullone_log_$now.txt")

if (!(Test-Path $Global:FULLONE_LogFileDir)) {
    New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null
}

Write-Log "FULLONE iniciado (BUSCAR-TODOS-SCRIPTS). RootPath = $RootPath"
if ($DryRun) { Write-Log "MODO: DRY RUN (simulação). Nenhuma alteração será feita." }

# ==============================
# Localizar arquivos .ps1 e .py
# ==============================
Write-Log "Procurando arquivos .ps1 e .py recursivamente..."

$files = Get-ChildItem -Path $RootPath -Recurse -File -ErrorAction SilentlyContinue `
    | Where-Object { $_.Extension -in '.ps1', '.py' }

$totalCount = $files.Count
Write-Log "Total encontrado: $totalCount arquivos (.ps1/.py)."

# ==============================
# Relatório inicial
# ==============================
$reportFile = Join-Path $RootPath ("relatorio_FULLONE_$now.txt")
$summary = @()
$summary += "Relatório FULLONE - $now"
$summary += "RootPath: $RootPath"
$summary += "Total scripts encontrados: $totalCount"
$summary += ""

# ==============================
# Duplicados por conteúdo (hash)
# ==============================
Write-Log "Verificando duplicados por conteúdo (hash)..."
$hashMap = @{}
foreach ($f in $files) {
    try {
        $h = Get-FileHash -Path $f.FullName -Algorithm SHA256
        if (-not $hashMap.ContainsKey($h.Hash)) { $hashMap[$h.Hash] = @() }
        $hashMap[$h.Hash] += $f
    } catch {
        Write-Log "Falha ao calcular hash de $($f.FullName): $($_.Exception.Message)" "WARN"
    }
}
$dupByContent = $hashMap.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }

if ($dupByContent.Count -gt 0) {
    $summary += "Duplicados por conteúdo: $($dupByContent.Count) grupos"
    foreach ($g in $dupByContent) {
        $summary += "Hash: $($g.Key)"
        foreach ($f in $g.Value) {
            $summary += "   $($f.FullName)"
        }
    }
} else {
    $summary += "Nenhum duplicado de conteúdo encontrado."
}

# ==============================
# Duplicados por nome
# ==============================
Write-Log "Verificando arquivos com mesmo nome..."
$byName = @{}
foreach ($f in $files) {
    if (-not $byName.ContainsKey($f.Name)) { $byName[$f.Name] = @() }
    $byName[$f.Name] += $f
}
$dupByName = $byName.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }

if ($dupByName.Count -gt 0) {
    $summary += ""
    $summary += "Arquivos com mesmo nome em múltiplas pastas: $($dupByName.Count)"
    foreach ($g in $dupByName) {
        $summary += "Nome: $($g.Key)"
        foreach ($f in $g.Value) {
            $summary += "   $($f.FullName)"
        }
    }
} else {
    $summary += "Nenhum arquivo duplicado por nome encontrado."
}

# ==============================
# Função SafeFix
# ==============================
function Safe-FixFile {
    param(
        [string]$Path,
        [switch]$BackupBefore
    )
    $actions = @()

    if ($BackupBefore) {
        $backupDir = Join-Path $RootPath ("BACKUP_FULLONE_$now")
        if (!(Test-Path $backupDir)) { New-Item -ItemType Directory -Path $backupDir -Force | Out-Null }
        $dest = Join-Path $backupDir ((Split-Path $Path -Leaf) + ".bak")
        Copy-Item -Path $Path -Destination $dest -Force
        $actions += "Backup criado: $dest"
    }

    try {
        $raw = Get-Content -Raw -LiteralPath $Path
    } catch {
        return @{ success = $false; msg = "Falha ao ler: $($_.Exception.Message)"; actions=$actions }
    }

    $orig = $raw
    $raw = $raw -replace "[\u201C\u201D]",'"'
    $raw = $raw -replace "[\u2018\u2019]","'"
    $raw = $raw -replace "…","..."
    $raw = $raw -replace "\u00A0"," "
    if ($raw.StartsWith([char]0xFEFF)) { $raw = $raw.Substring(1); $actions += "BOM removido" }

    if ($raw -ne $orig) {
        if ($DryRun) {
            return @{ success = $true; changed = $true; msg = "Alterações simuladas"; actions=$actions }
        } else {
            $raw | Out-File -LiteralPath $Path -Encoding UTF8 -Force
            return @{ success = $true; changed = $true; msg = "Alterações aplicadas"; actions=$actions }
        }
    } else {
        return @{ success = $true; changed = $false; msg = "Nenhuma alteração necessária"; actions=$actions }
    }
}

# ==============================
# Aplicar SafeFix (se solicitado)
# ==============================
$fixSummary = @()
if ($AutoFix) {
    Write-Log "Rodando SafeFix em todos os arquivos..."
    foreach ($f in $files) {
        $res = Safe-FixFile -Path $f.FullName -BackupBefore:$Backup
        $fixSummary += ("{0} => {1}" -f $f.FullName, $res.msg)
        foreach ($a in $res.actions) { Write-Log "   $a" }
    }
}

# ==============================
# Compilação em FULLONE_COMPILED.ps1
# ==============================
Write-Log "Gerando compilado FULLONE_COMPILED..."
$compiledFolder = Join-Path $RootPath "FULLONE_COMPILED"
if (!(Test-Path $compiledFolder)) { New-Item -ItemType Directory -Path $compiledFolder -Force | Out-Null }
$compiledPath = Join-Path $compiledFolder ("FULLONE_COMPILED_$now.ps1")

$compiledContent = @()
$compiledContent += "# FULLONE_COMPILED - gerado em $now"
$compiledContent += "# Root: $RootPath"
$compiledContent += ""

foreach ($f in $files) {
    $compiledContent += "##############################################################################"
    $compiledContent += "# INICIO: $($f.FullName)"
    try {
        $txt = Get-Content -Raw -LiteralPath $f.FullName
        if ($f.Extension -eq ".py") {
            $compiledContent += "<# PYTHON SCRIPT ORIGEM #>"
            $compiledContent += $txt
            $compiledContent += "<# FIM PYTHON #>"
        } else {
            $compiledContent += $txt
        }
    } catch {
        $compiledContent += "# Falha ao incluir $($f.FullName): $($_.Exception.Message)"
    }
    $compiledContent += "# FIM: $($f.FullName)"
    $compiledContent += "##############################################################################"
    $compiledContent += ""
}

if ($DryRun) {
    $compiledSim = $compiledPath + ".simulado.txt"
    $compiledContent | Out-File -FilePath $compiledSim -Encoding UTF8
    Write-Log "Compilado simulado salvo em: $compiledSim"
} else {
    $compiledContent | Out-File -FilePath $compiledPath -Encoding UTF8
    Write-Log "Compilado salvo em: $compiledPath"
}

# ==============================
# Salvar relatório final
# ==============================
if ($AutoFix) {
    $summary += ""
    $summary += "Resumo SafeFix:"
    $summary += $fixSummary
}
$summary += ""
$summary += "Fim do relatório."

$summary | Out-File -FilePath $reportFile -Encoding UTF8
Write-Log "Relatório salvo em: $reportFile"
Write-Log "Execução finalizada."


# ---- bloco ----

<#
================================================================================
 SCRIPT: FULLONE-ROUTINE.ps1
 OBJETIVO:
   - Buscar todos os .ps1 e .py dentro da pasta raiz especificada
   - Contar arquivos
   - Detectar duplicados (conteúdo e nome)
   - Corrigir caracteres problemáticos (SafeFix, opcional)
   - Compilar todos em 1 único FULLONE_COMPILED.ps1
   - Executar cada script em processo separado (opcional)
   - Relatório e log detalhado
   - Script independente

 AUTOR: Assistente Automação
================================================================================
#>

param(
    [string]$RootPath = 'C:\CONAV TRADER\CONAV_TRADER',
    [switch]$DryRun = $true,
    [switch]$AutoFix = $false,
    [switch]$Backup = $true,
    [switch]$Exec = $false,
    [switch]$UsePwsh = $false
)

# ==============================
# Função de log
# ==============================
function Write-Log {
    param([string]$Message,[string]$Level = 'INFO')
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = "[$ts][$Level] $Message"
    if (!(Test-Path $Global:FULLONE_LogFileDir)) {
        New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null
    }
    Add-Content -Path $Global:FULLONE_LogFile -Value $line -Encoding UTF8
    Write-Host $line
}

# ==============================
# Inicialização
# ==============================
$RootPath = (Resolve-Path -Path $RootPath).ProviderPath
$now = Get-Date -Format 'yyyyMMdd_HHmmss'

$Global:FULLONE_LogFileDir = Join-Path $RootPath 'logs_FULLONE'
$Global:FULLONE_LogFile = Join-Path $Global:FULLONE_LogFileDir ("fullone_log_$now.txt")
if (!(Test-Path $Global:FULLONE_LogFileDir)) {
    New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null
}

Write-Log "FULLONE iniciado. RootPath = $RootPath"
if ($DryRun) { Write-Log "MODO: DRY RUN (simulação). Nenhuma alteração será feita." }

# ==============================
# Localizar arquivos
# ==============================
Write-Log "Procurando arquivos .ps1 e .py..."
$files = Get-ChildItem -Path $RootPath -Recurse -File -ErrorAction SilentlyContinue `
    | Where-Object { $_.Extension -in '.ps1','.py' }
$totalCount = $files.Count
Write-Log "Total encontrado: $totalCount arquivos."

# ==============================
# Relatório inicial
# ==============================
$reportFile = Join-Path $RootPath ("relatorio_FULLONE_$now.txt")
$summary = @()
$summary += "Relatório FULLONE - $now"
$summary += "RootPath: $RootPath"
$summary += "Total arquivos: $totalCount"
$summary += ""

# ==============================
# Duplicados (conteúdo e nome)
# ==============================
Write-Log "Verificando duplicados..."
$hashMap = @{}
$byName = @{}
foreach ($f in $files) {
    try {
        $h = Get-FileHash -Path $f.FullName -Algorithm SHA256
        if (-not $hashMap.ContainsKey($h.Hash)) { $hashMap[$h.Hash] = @() }
        $hashMap[$h.Hash] += $f
    } catch { Write-Log "Falha hash $($f.FullName): $($_.Exception.Message)" "WARN" }
    if (-not $byName.ContainsKey($f.Name)) { $byName[$f.Name] = @() }
    $byName[$f.Name] += $f
}
$dupByContent = $hashMap.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }
$dupByName = $byName.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }

if ($dupByContent.Count -gt 0) {
    $summary += "Duplicados por conteúdo: $($dupByContent.Count) grupos"
    foreach ($g in $dupByContent) {
        $summary += "Hash: $($g.Key)"
        foreach ($f in $g.Value) { $summary += "   $($f.FullName)" }
    }
} else { $summary += "Nenhum duplicado de conteúdo." }

if ($dupByName.Count -gt 0) {
    $summary += ""
    $summary += "Duplicados por nome: $($dupByName.Count) grupos"
    foreach ($g in $dupByName) {
        $summary += "Nome: $($g.Key)"
        foreach ($f in $g.Value) { $summary += "   $($f.FullName)" }
    }
} else { $summary += "Nenhum duplicado por nome." }

# ==============================
# Função SafeFix
# ==============================
function Safe-FixFile {
    param([string]$Path,[switch]$BackupBefore)
    $actions=@()
    if ($BackupBefore) {
        $backupDir = Join-Path $RootPath ("BACKUP_FULLONE_$now")
        if (!(Test-Path $backupDir)) { New-Item -ItemType Directory -Path $backupDir -Force | Out-Null }
        $dest = Join-Path $backupDir ((Split-Path $Path -Leaf)+".bak")
        Copy-Item $Path $dest -Force
        $actions+="Backup: $dest"
    }
    try { $raw=Get-Content -Raw -LiteralPath $Path } catch { return @{success=$false;msg="Falha leitura";actions=$actions} }
    $orig=$raw
    $raw=$raw -replace "[\u201C\u201D]",'"' -replace "[\u2018\u2019]","'" -replace "…","..." -replace "\u00A0"," "
    if ($raw.StartsWith([char]0xFEFF)) { $raw=$raw.Substring(1); $actions+="BOM removido" }
    if ($raw -ne $orig) {
        if ($DryRun) { return @{success=$true;changed=$true;msg="Alterações simuladas";actions=$actions} }
        else { $raw|Out-File -LiteralPath $Path -Encoding UTF8 -Force; return @{success=$true;changed=$true;msg="Alterações aplicadas";actions=$actions} }
    } else { return @{success=$true;changed=$false;msg="Nenhuma alteração";actions=$actions} }
}

# ==============================
# SafeFix (opcional)
# ==============================
$fixSummary=@()
if ($AutoFix) {
    Write-Log "Rodando SafeFix..."
    foreach ($f in $files) {
        $res=Safe-FixFile -Path $f.FullName -BackupBefore:$Backup
        $fixSummary+=("$($f.FullName) => $($res.msg)")
        foreach ($a in $res.actions) { Write-Log "   $a" }
    }
}

# ==============================
# Compilação
# ==============================
Write-Log "Gerando compilado..."
$compiledDir=Join-Path $RootPath "FULLONE_COMPILED"
if (!(Test-Path $compiledDir)) { New-Item -ItemType Directory -Path $compiledDir -Force|Out-Null }
$compiledPath=Join-Path $compiledDir ("FULLONE_COMPILED_$now.ps1")

$compiled=@()
$compiled+="# FULLONE_COMPILED - $now"
$compiled+="# Root: $RootPath"
foreach ($f in $files) {
    $compiled+="##############################################################################"
    $compiled+="# INICIO: $($f.FullName)"
    try {
        $txt=Get-Content -Raw -LiteralPath $f.FullName
        if ($f.Extension -eq ".py") { $compiled+="<# PYTHON ORIGEM #>";$compiled+=$txt;$compiled+="<# FIM PYTHON #>" }
        else { $compiled+=$txt }
    } catch { $compiled+="# Falha incluir $($f.FullName)" }
    $compiled+="# FIM: $($f.FullName)"
}
if ($DryRun) {
    $compiledSim=$compiledPath+".simulado.txt"
    $compiled|Out-File -FilePath $compiledSim -Encoding UTF8
    Write-Log "Compilado simulado salvo em: $compiledSim"
} else {
    $compiled|Out-File -FilePath $compiledPath -Encoding UTF8
    Write-Log "Compilado salvo em: $compiledPath"
}

# ==============================
# Execução isolada (opcional)
# ==============================
if ($Exec) {
    Write-Log "Executando scripts em processos separados..."
    foreach ($f in $files) {
        if ($DryRun) { Write-Log "Simulado: $($f.FullName)"; continue }
        if ($f.Extension -eq ".py") {
            try { Start-Process -FilePath "python" -ArgumentList "`"$($f.FullName)`"" -Wait -NoNewWindow -PassThru | Out-Null; Write-Log "OK: $($f.Name)" }
            catch { Write-Log "Erro Python: $($f.FullName)" "ERROR" }
        } else {
            $exe=if ($UsePwsh) {'pwsh'} else {'powershell'}
            try { Start-Process -FilePath $exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$($f.FullName)`"" -Wait -NoNewWindow -PassThru|Out-Null; Write-Log "OK: $($f.Name)" }
            catch { Write-Log "Erro PowerShell: $($f.FullName)" "ERROR" }
        }
    }
}

# ==============================
# Relatório final
# ==============================
if ($AutoFix) { $summary+="";$summary+="Resumo SafeFix:";$summary+=$fixSummary }
$summary+="";$summary+="Fim do relatório."
$summary|Out-File -FilePath $reportFile -Encoding UTF8
Write-Log "Relatório salvo em: $reportFile"
Write-Log "FULLONE finalizado."


# ---- bloco ----

<#
.SYNOPSIS
    FULLONEv00003.ps1 - rotina unificada para descobrir, analisar, corrigir (opcional), compilar, executar e versionar scripts (.ps1 .py).

.DESCRIPTION
    - Busca recursiva por .ps1 e .py em RootPath (padrão: C:\CONAV TRADER\CONAV_TRADER)
    - Relatórios: contagem, duplicados (por hash), arquivos com mesmo nome (comparação)
    - SafeFix (correções seguras) com Backup opcional
    - Geração de FULLONE_COMPILED_<timestamp>.ps1 (ou .simulado.txt em DryRun)
    - Execução isolada por processo (opcional)
    - Deploy/versionamento do FULLONE para pastas de integração (opcional)
    - DryRun por padrão (não modifica nada)
    - Logs em <RootPath>\logs_FULLONE
    - Relatórios em <RootPath>
#>

param(
    [string]$RootPath = 'C:\CONAV TRADER\CONAV_TRADER',
    [switch]$DryRun = $true,
    [switch]$AutoFix = $false,
    [switch]$Backup = $true,
    [switch]$Exec = $false,
    [switch]$UsePwsh = $false,
    [switch]$MakeCompiledOnly = $false,
    [switch]$Deploy = $false
)

Set-StrictMode -Version Latest

# -------------------------
# Helpers / Inicialização
# -------------------------
function Safe-JoinPath {
    param([string]$Path, [string]$Child)
    return Join-Path -Path $Path -ChildPath $Child
}

# resolve RootPath absolute
try { $RootPath = (Resolve-Path -Path $RootPath -ErrorAction Stop).ProviderPath } catch { Write-Error "RootPath inválido: $RootPath"; exit 1 }

$now = Get-Date -Format 'yyyyMMdd_HHmmss'

# log dir & file (cria diretório ANTES de montar o nome do arquivo)
$LogDir = Safe-JoinPath -Path $RootPath -Child "logs_FULLONE"
if (-not (Test-Path -LiteralPath $LogDir -PathType Container)) {
    try { New-Item -ItemType Directory -Path $LogDir -Force | Out-Null } catch { Write-Warning "Não foi possível criar pasta de logs: $LogDir" }
}
$LogFile = Safe-JoinPath -Path $LogDir -Child ("fullone_log_$now.txt")

# garante que o arquivo de log exista (assim Add-Content não tenta escrever num diretório)
if (-not (Test-Path -LiteralPath $LogFile -PathType Leaf)) {
    try { New-Item -ItemType File -Path $LogFile -Force | Out-Null } catch { Write-Warning "Não foi possível criar o arquivo de log: $LogFile" }
}

function Write-Log {
    param(
        [string]$Message,
        [string]$Level = 'INFO'
    )
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = "[$ts][$Level] $Message"
    # proteção: se por algum motivo $LogFile for diretório, redirecionar para console
    if (Test-Path -LiteralPath $LogFile -PathType Container) {
        Write-Host "[WARN] Log path é diretório! $LogFile" -ForegroundColor Yellow
        Write-Host $line
    } else {
        try {
            Add-Content -Path $LogFile -Value $line -Encoding UTF8
        } catch {
            Write-Warning "Falha escrevendo log em $LogFile: $($_.Exception.Message)"
            Write-Host $line
        }
    }
    Write-Host $line
}

Write-Log "FULLONE iniciado. RootPath = $RootPath"
if ($DryRun) { Write-Log "MODO: DRY RUN (simulação). Nenhuma alteração será feita." }

# -------------------------
# Padrões / exclusões
# -------------------------
$ignorePatterns = @(
    '\\.git\\',
    '\\node_modules\\',
    '\\dist\\',
    '\\build\\',
    '\\FULLONE_COMPILED\\',      # não varrer a pasta de compilados
    '\\BACKUP_FULLONE_',         # não varrer backups criados pelo próprio script
    '\\logs_FULLONE\\'           # evitar reprocessar logs
)

function Path-IsIgnored {
    param([string]$FullName)
    foreach ($p in $ignorePatterns) {
        if ($FullName -match $p) { return $true }
    }
    return $false
}

# -------------------------
# Localizar arquivos .ps1 e .py
# -------------------------
Write-Log "Procurando arquivos .ps1 e .py recursivamente..."
try {
    $files = Get-ChildItem -Path $RootPath -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Extension -in '.ps1', '.py' } |
        Where-Object { -not (Path-IsIgnored -FullName $_.FullName) } |
        Where-Object { $_.FullName -ne $PSCommandPath -and $_.FullName -ne $MyInvocation.MyCommand.Definition }
} catch {
    Write-Log "Erro ao listar arquivos: $($_.Exception.Message)" "ERROR"
    $files = @()
}

$totalCount = $files.Count
Write-Log "Total encontrado: $totalCount arquivos (.ps1/.py)."

# relatório inicial
$reportFile = Safe-JoinPath -Path $RootPath -Child ("relatorio_FULLONE_$now.txt")
$summary = New-Object System.Collections.Generic.List[string]
$summary.Add("FULLONE Report - $now")
$summary.Add("RootPath: $RootPath")
$summary.Add("Total scripts found: $totalCount")
$summary.Add("")

# -------------------------
# Hashes e duplicados
# -------------------------
Write-Log "Calculando hashes (SHA256) para identificar duplicados..."
$hashMap = @{}
$byName = @{}
foreach ($f in $files) {
    try {
        $h = Get-FileHash -Path $f.FullName -Algorithm SHA256 -ErrorAction Stop
        $hash = $h.Hash
    } catch {
        Write-Log "Falha ao calcular hash de $($f.FullName): $($_.Exception.Message)" "WARN"
        $hash = "ERROR_$([guid]::NewGuid().ToString())"
    }
    if (-not $hashMap.ContainsKey($hash)) { $hashMap[$hash] = New-Object System.Collections.ArrayList }
    $hashMap[$hash].Add($f) | Out-Null

    if (-not $byName.ContainsKey($f.Name)) { $byName[$f.Name] = New-Object System.Collections.ArrayList }
    $byName[$f.Name].Add($f) | Out-Null
}

$dupByContent = $hashMap.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }
if ($dupByContent.Count -gt 0) {
    Write-Log "Duplicados por conteúdo encontrados: $($dupByContent.Count) grupos."
    $summary.Add("Duplicados por conteúdo (grupos): $($dupByContent.Count)")
    foreach ($g in $dupByContent) {
        $summary.Add("GrupoHash: $($g.Key)")
        foreach ($item in $g.Value) { $summary.Add("    $($item.FullName) (modified: $($item.LastWriteTime))") }
    }
} else {
    $summary.Add("Nenhum duplicado de conteúdo detectado.")
    Write-Log "Nenhum duplicado por conteúdo detectado."
}

$dupByName = $byName.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }
if ($dupByName.Count -gt 0) {
    Write-Log "Mesmo nome em múltiplas localizações: $($dupByName.Count) nomes."
    $summary.Add("")
    $summary.Add("Arquivos com mesmo nome em múltiplas pastas: $($dupByName.Count)")
    foreach ($g in $dupByName) {
        $summary.Add("Nome: $($g.Key)")
        foreach ($item in $g.Value) {
            $summary.Add("    $($item.FullName) (LastWrite: $($item.LastWriteTime), Size: $($item.Length))")
        }
        $latest = $g.Value | Sort-Object LastWriteTime -Descending | Select-Object -First 1
        $summary.Add("    -> Sugerido manter (mais recente): $($latest.FullName)")
    }
} else {
    $summary.Add("Nenhum arquivo com mesmo nome em múltiplos locais.")
}

# salva resumo inicial temporariamente (vai ser sobrescrito no final também)
try { $summary | Out-File -FilePath $reportFile -Encoding UTF8 -Force } catch { Write-Log "Falha salvando relatório inicial: $($_.Exception.Message)" "WARN" }

# -------------------------
# Safe-Fix function
# -------------------------
function Safe-FixFile {
    param(
        [string]$Path,
        [switch]$BackupBefore
    )
    $actions = New-Object System.Collections.ArrayList

    if ($BackupBefore) {
        $backupDir = Safe-JoinPath -Path $RootPath -Child ("BACKUP_FULLONE_$now")
        if (-not (Test-Path -LiteralPath $backupDir -PathType Container)) { New-Item -ItemType Directory -Path $backupDir -Force | Out-Null }
        $dest = Safe-JoinPath -Path $backupDir -Child ((Split-Path $Path -Leaf) + ".bak")
        try { Copy-Item -LiteralPath $Path -Destination $dest -Force } catch { $actions.Add("Falha criando backup: $($_.Exception.Message)") | Out-Null }
        $actions.Add("Backup: $dest") | Out-Null
    }

    try {
        $raw = Get-Content -Raw -LiteralPath $Path -ErrorAction Stop
    } catch {
        return @{ success = $false; message = "Falha ao ler: $($_.Exception.Message)"; actions=$actions }
    }

    $orig = $raw
    # substituições seguras
    $raw = $raw -replace "[\u201C\u201D]", '"'    # curly double -> "
    $raw = $raw -replace "[\u2018\u2019]", "'"    # curly single -> '
    $raw = $raw -replace "…", "..."
    $raw = $raw -replace "\u00A0", " "           # NBSP -> space
    if ($raw.Length -gt 0 -and $raw[0] -eq [char]0xFEFF) { $raw = $raw.Substring(1); $actions.Add("Removed BOM") | Out-Null }

    if ($raw -ne $orig) {
        if ($DryRun) {
            $actions.Add("CHANGES (simulado)") | Out-Null
            return @{ success = $true; changed = $true; message = "Simulado: alterações sugeridas"; actions=$actions }
        } else {
            try {
                # salvar sem BOM explicitamente
                $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
                [System.IO.File]::WriteAllText($Path, $raw, $utf8NoBom)
                $actions.Add("Saved changes (UTF8 no BOM)") | Out-Null
                return @{ success = $true; changed = $true; message = "Alterações aplicadas"; actions=$actions }
            } catch {
                return @{ success = $false; changed = $false; message = "Falha ao salvar: $($_.Exception.Message)"; actions=$actions }
            }
        }
    } else {
        return @{ success = $true; changed = $false; message = "Nenhuma alteração necessária"; actions=$actions }
    }
}

# -------------------------
# AutoFix (opcional)
# -------------------------
$fixSummary = New-Object System.Collections.ArrayList
if ($AutoFix) {
    Write-Log "AutoFix solicitado. Preparando aplicação de correções seguras."
    if ($DryRun) { Write-Log "Nota: Em DryRun; AutoFix apenas simulado." }
    $confirm = $true
    if (-not $DryRun) {
        try {
            $choice = Read-Host "Você quer realmente aplicar AutoFix em todos os arquivos encontrados? (S/N)"
            if ($choice.ToUpper() -ne 'S') { $confirm = $false; Write-Log "AutoFix CANCELADO pelo usuário." }
        } catch { $confirm = $true }
    }
    if ($confirm) {
        foreach ($f in $files) {
            Write-Log "Analisando para fix: $($f.FullName)"
            $res = Safe-FixFile -Path $f.FullName -BackupBefore:$Backup
            if ($res.success) {
                $fixSummary.Add(("{0} => {1} - {2}" -f $f.FullName, ($res.changed -eq $true ? "CHANGED":"UNCHANGED"), $res.message)) | Out-Null
                foreach ($a in $res.actions) { Write-Log "    $a" }
            } else {
                Write-Log "Erro no Safe-FixFile: $($res.message)" "ERROR"
            }
        }
        Write-Log "AutoFix finalizado (ou simulado)."
    }
}

# -------------------------
# Gerar arquivo compilado
# -------------------------
Write-Log "Gerando arquivo compilado FULLONE_COMPILED..."
$compiledFolder = Safe-JoinPath -Path $RootPath -Child 'FULLONE_COMPILED'
if (-not (Test-Path -LiteralPath $compiledFolder -PathType Container)) { New-Item -ItemType Directory -Path $compiledFolder -Force | Out-Null }
$compiledPath = Safe-JoinPath -Path $compiledFolder -Child ("FULLONE_COMPILED_$now.ps1")

$header = @()
$header += "# FULLONE_COMPILED - gerado em $now"
$header += "# Root: $RootPath"
$header += "# Arquivos incluídos:"
foreach ($f in $files) { $header += ("# - {0} (LastWrite: {1})" -f $f.FullName, $f.LastWriteTime) }
$header += ""

$compiledContent = $header -join "`r`n" + "`r`n"
foreach ($f in $files) {
    $compiledContent += "`r`n"
    $compiledContent += "##############################################################################`r`n"
    $compiledContent += "# INICIO: $($f.FullName)`r`n"
    $compiledContent += "##############################################################################`r`n"
    try {
        $txt = Get-Content -Raw -LiteralPath $f.FullName -ErrorAction Stop
        if ($f.Extension.ToLower() -eq '.py') {
            $compiledContent += "<# PY: origem: $($f.FullName) #>`r`n"
            $compiledContent += $txt + "`r`n"
            $compiledContent += "<# FIM PY #>`r`n"
        } else {
            $compiledContent += $txt + "`r`n"
        }
    } catch {
        Write-Log "Falha lendo $($f.FullName) para inclusão compilada: $($_.Exception.Message)" "WARN"
        $compiledContent += "# Falha ao incluir $($f.FullName): $($_.Exception.Message)`r`n"
    }
    $compiledContent += "`r`n"
    $compiledContent += "##############################################################################`r`n"
    $compiledContent += "# FIM: $($f.FullName)`r`n"
    $compiledContent += "##############################################################################`r`n"
}

if ($DryRun) {
    $simulatedCompiledPath = $compiledPath + ".simulado.txt"
    try {
        # salvar sem BOM
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($simulatedCompiledPath, $compiledContent, $utf8NoBom)
        Write-Log "Em DryRun: compilado simulado salvo em: $simulatedCompiledPath"
    } catch { Write-Log "Falha salvando compilado simulado: $($_.Exception.Message)" "WARN" }
} else {
    try {
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($compiledPath, $compiledContent, $utf8NoBom)
        Write-Log "Arquivo compilado salvo em: $compiledPath"
    } catch { Write-Log "Falha ao salvar compilado: $($_.Exception.Message)" "ERROR" }
}

if ($MakeCompiledOnly) {
    Write-Log "MakeCompiledOnly solicitado. Finalizando sem execução."
    $summary.Add("Compiled file: " + (if ($DryRun) { $simulatedCompiledPath } else { $compiledPath }))
    $summary.Add("LOG: $LogFile")
    $summary.Add("Fim do relatório.")
    $summary | Out-File -FilePath $reportFile -Encoding UTF8 -Force
    Write-Log "Relatório salvo em: $reportFile"
    exit 0
}

# -------------------------
# Execução isolada (opcional)
# -------------------------
if ($Exec) {
    Write-Log "Execução isolada de cada script solicitada. Será executado em processos separados."
    if ($DryRun) { Write-Log "OBS: Execução em DryRun (simulação) - nada será executado)." }
    foreach ($f in $files) {
        Write-Log "Preparando execução: $($f.FullName)"
        if ($DryRun) {
            Write-Log "Simulado: executar $($f.FullName)"
            continue
        }
        if ($f.Extension.ToLower() -eq '.py') {
            $exe = 'python'
            try {
                $proc = Start-Process -FilePath $exe -ArgumentList @($f.FullName) -Wait -NoNewWindow -PassThru -ErrorAction Stop
                Write-Log "Processo finalizado: ExitCode $($proc.ExitCode)"
            } catch {
                Write-Log "Falha ao executar python $($f.FullName): $($_.Exception.Message)" "ERROR"
            }
        } else {
            $psExe = if ($UsePwsh) { 'pwsh' } else { 'powershell' }
            $arg = "-NoProfile -ExecutionPolicy Bypass -File `"$($f.FullName)`""
            try {
                $proc = Start-Process -FilePath $psExe -ArgumentList $arg -Wait -NoNewWindow -PassThru -ErrorAction Stop
                Write-Log "Processo finalizado: ExitCode $($proc.ExitCode)"
            } catch {
                Write-Log "Falha ao executar $($f.FullName): $($_.Exception.Message)" "ERROR"
            }
        }
    }
}

# -------------------------
# Deploy / versionamento do FULLONE (opcional)
# -------------------------
if ($Deploy) {
    Write-Log "Deploy solicitado: copiando FULLONE para pastas de integração (confirmando)."
    $scriptPath = $MyInvocation.MyCommand.Definition
    $targets = @(
        Safe-JoinPath -Path $RootPath -Child 'scripts\SCRIPTS BASE OFICIAIS',
        Safe-JoinPath -Path $RootPath -Child 'SCRIPT MESTRE',
        Safe-JoinPath -Path $RootPath -Child 'PACKAGES OFICIAIS'
    )
    foreach ($t in $targets) {
        if (-not (Test-Path -LiteralPath $t -PathType Container)) {
            try { New-Item -ItemType Directory -Path $t -Force | Out-Null } catch { Write-Log "Falha criando target $t: $($_.Exception.Message)" "WARN" }
        }
        $baseName = 'FULLONE'
        $existing = Get-ChildItem -Path $t -Filter "$baseName*.ps1" -File -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1
        if ($existing) {
            $digits = ([regex]::Matches($existing.BaseName,'\d+')) | Select-Object -Last 1
            if ($digits) { $num = [int]$digits.Value + 1 } else { $num = 1 }
        } else { $num = 1 }
        $dest = Join-Path -Path $t -Child ("{0}{1:D4}.ps1" -f $baseName,$num)
        if ($DryRun) {
            Write-Log "Simulado: copiar $scriptPath -> $dest"
        } else {
            try { Copy-Item -LiteralPath $scriptPath -Destination $dest -Force; Write-Log "Copiado $scriptPath -> $dest" } catch { Write-Log "Falha no deploy $dest: $($_.Exception.Message)" "ERROR" }
        }
    }
}

# -------------------------
# Finalizar e salvar relatório detalhado
# -------------------------
$report = New-Object System.Collections.Generic.List[string]
$report.AddRange($summary)
$report.Add("")
$report.Add("Detalhes:")
$report.Add("Total arquivos: $totalCount")
$report.Add("Duplicados por conteúdo (grupos): $($dupByContent.Count)")
$report.Add("Mesmo nome em múltiplas pastas: $($dupByName.Count)")
$report.Add("")
if ($AutoFix) {
    $report.Add("AutoFix summary:")
    $fixSummary | ForEach-Object { $report.Add($_) }
}
$report.Add("")
$report.Add("Compiled file: " + (if ($DryRun) { $simulatedCompiledPath } else { $compiledPath }))
$report.Add("")
$report.Add("LOG: " + $LogFile)
$report.Add("")
$report.Add("Fim do relatório.")
try { $report | Out-File -FilePath $reportFile -Encoding UTF8 -Force } catch { Write-Log "Falha salvando relatório final: $($_.Exception.Message)" "ERROR" }

Write-Log "FULLONE finalizado. Relatório salvo em: $reportFile"
if ($DryRun) { Write-Log "Recomendo revisar relatório e rodar sem -DryRun e com -AutoFix somente após confirmar." }


# ---- bloco ----

  Set-ExecutionPolicy Bypass -Scope Process -Force
  .\FULLONEv00003.ps1
  

# ---- bloco ----

  .\FULLONEv00003.ps1 -DryRun:$false -AutoFix -Backup
  

# ---- bloco ----

  .\FULLONEv00003.ps1 -DryRun:$false -Exec -UsePwsh
  

# ---- bloco ----

  .\FULLONEv00003.ps1 -DryRun:$false -Deploy
  

# ---- bloco ----

# ==============================
# Inicialização
# ==============================
$RootPath = (Resolve-Path -Path $RootPath).ProviderPath
$now = Get-Date -Format 'yyyyMMdd_HHmmss'

# Diretório de logs
$Global:FULLONE_LogFileDir = Join-Path $RootPath 'logs_FULLONE'
if (!(Test-Path $Global:FULLONE_LogFileDir)) {
    New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null
}
# Arquivo de log correto
$Global:FULLONE_LogFile = Join-Path $Global:FULLONE_LogFileDir ("fullone_log_$now.txt")

Write-Log "FULLONE iniciado. RootPath = $RootPath"
if ($DryRun) { Write-Log "MODO: DRY RUN (simulação). Nenhuma alteração será feita." }


# ---- bloco ----

# ==============================
# Compilação
# ==============================
Write-Log "Gerando compilado..."
$compiledDir = Join-Path $RootPath "FULLONE_COMPILED"
if (!(Test-Path $compiledDir)) {
    New-Item -ItemType Directory -Path $compiledDir -Force | Out-Null
}
$compiledPath = Join-Path $compiledDir ("FULLONE_COMPILED_$now.ps1")


# ---- bloco ----

<#
================================================================================
 SCRIPT: FULLONEv00003.ps1
 OBJETIVO:
   - Buscar todos os .ps1 e .py dentro da pasta raiz especificada
   - Contar arquivos
   - Detectar duplicados (conteúdo e nome)
   - Corrigir caracteres problemáticos (SafeFix, opcional)
   - Compilar todos em 1 único FULLONE_COMPILED.ps1
   - Executar cada script em processo separado (opcional)
   - Relatório e log detalhado
   - Deploy automático para pastas de integração
   - Script independente e seguro

 AUTOR: Assistente Automação
================================================================================
#>

param(
    [string]$RootPath = 'C:\CONAV TRADER\CONAV_TRADER',
    [switch]$DryRun = $true,
    [switch]$AutoFix = $false,
    [switch]$Backup = $true,
    [switch]$Exec = $false,
    [switch]$UsePwsh = $false,
    [switch]$Deploy = $true
)

# ==============================
# Função de log
# ==============================
function Write-Log {
    param([string]$Message,[string]$Level = 'INFO')
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = "[$ts][$Level] $Message"
    Add-Content -Path $Global:FULLONE_LogFile -Value $line -Encoding UTF8
    Write-Host $line
}

# ==============================
# Inicialização
# ==============================
$RootPath = (Resolve-Path -Path $RootPath).ProviderPath
$now = Get-Date -Format 'yyyyMMdd_HHmmss'

# Diretório de logs
$Global:FULLONE_LogFileDir = Join-Path $RootPath 'logs_FULLONE'
if (!(Test-Path $Global:FULLONE_LogFileDir)) {
    New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null
}
# Arquivo de log correto
$Global:FULLONE_LogFile = Join-Path $Global:FULLONE_LogFileDir ("fullone_log_$now.txt")

Write-Log "FULLONE iniciado. RootPath = $RootPath"
if ($DryRun) { Write-Log "MODO: DRY RUN (simulação). Nenhuma alteração será feita." }

# ==============================
# Localizar arquivos
# ==============================
Write-Log "Procurando arquivos .ps1 e .py recursivamente..."
$files = Get-ChildItem -Path $RootPath -Recurse -File -ErrorAction SilentlyContinue `
    | Where-Object { $_.Extension -in '.ps1','.py' }
$totalCount = $files.Count
Write-Log "Total encontrado: $totalCount arquivos (.ps1/.py)."

# ==============================
# Relatório inicial
# ==============================
$reportFile = Join-Path $RootPath ("relatorio_FULLONE_$now.txt")
$summary = @()
$summary += "Relatório FULLONE - $now"
$summary += "RootPath: $RootPath"
$summary += "Total arquivos: $totalCount"
$summary += ""

# ==============================
# Duplicados (conteúdo e nome)
# ==============================
Write-Log "Verificando duplicados por conteúdo (hash)..."
$hashMap = @{}
$byName = @{}
foreach ($f in $files) {
    try {
        $h = Get-FileHash -Path $f.FullName -Algorithm SHA256
        if (-not $hashMap.ContainsKey($h.Hash)) { $hashMap[$h.Hash] = @() }
        $hashMap[$h.Hash] += $f
    } catch { Write-Log "Falha hash $($f.FullName): $($_.Exception.Message)" "WARN" }
    if (-not $byName.ContainsKey($f.Name)) { $byName[$f.Name] = @() }
    $byName[$f.Name] += $f
}
$dupByContent = $hashMap.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }
$dupByName = $byName.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }

if ($dupByContent.Count -gt 0) {
    $summary += "Duplicados por conteúdo: $($dupByContent.Count) grupos"
    foreach ($g in $dupByContent) {
        $summary += "Hash: $($g.Key)"
        foreach ($f in $g.Value) { $summary += "   $($f.FullName)" }
    }
} else { $summary += "Nenhum duplicado de conteúdo." }

Write-Log "Verificando arquivos com mesmo nome..."
if ($dupByName.Count -gt 0) {
    $summary += ""
    $summary += "Duplicados por nome: $($dupByName.Count) grupos"
    foreach ($g in $dupByName) {
        $summary += "Nome: $($g.Key)"
        foreach ($f in $g.Value) { $summary += "   $($f.FullName)" }
    }
} else { $summary += "Nenhum duplicado por nome." }

# ==============================
# Função SafeFix
# ==============================
function Safe-FixFile {
    param([string]$Path,[switch]$BackupBefore)
    $actions=@()
    if ($BackupBefore) {
        $backupDir = Join-Path $RootPath ("BACKUP_FULLONE_$now")
        if (!(Test-Path $backupDir)) { New-Item -ItemType Directory -Path $backupDir -Force | Out-Null }
        $dest = Join-Path $backupDir ((Split-Path $Path -Leaf)+".bak")
        Copy-Item $Path $dest -Force
        $actions+="Backup: $dest"
    }
    try { $raw=Get-Content -Raw -LiteralPath $Path } catch { return @{success=$false;msg="Falha leitura";actions=$actions} }
    $orig=$raw
    $raw=$raw -replace "[\u201C\u201D]",'"' -replace "[\u2018\u2019]","'" -replace "…","..." -replace "\u00A0"," "
    if ($raw.StartsWith([char]0xFEFF)) { $raw=$raw.Substring(1); $actions+="BOM removido" }
    if ($raw -ne $orig) {
        if ($DryRun) { return @{success=$true;changed=$true;msg="Alterações simuladas";actions=$actions} }
        else { $raw|Out-File -LiteralPath $Path -Encoding UTF8 -Force; return @{success=$true;changed=$true;msg="Alterações aplicadas";actions=$actions} }
    } else { return @{success=$true;changed=$false;msg="Nenhuma alteração";actions=$actions} }
}

# ==============================
# SafeFix (opcional)
# ==============================
$fixSummary=@()
if ($AutoFix) {
    Write-Log "Rodando SafeFix..."
    foreach ($f in $files) {
        $res=Safe-FixFile -Path $f.FullName -BackupBefore:$Backup
        $fixSummary+=("$($f.FullName) => $($res.msg)")
        foreach ($a in $res.actions) { Write-Log "   $a" }
    }
}

# ==============================
# Compilação
# ==============================
Write-Log "Gerando compilado FULLONE_COMPILED..."
$compiledDir = Join-Path $RootPath "FULLONE_COMPILED"
if (!(Test-Path $compiledDir)) {
    New-Item -ItemType Directory -Path $compiledDir -Force | Out-Null
}
$compiledPath = Join-Path $compiledDir ("FULLONE_COMPILED_$now.ps1")

$compiled=@()
$compiled+="# FULLONE_COMPILED - $now"
$compiled+="# Root: $RootPath"
foreach ($f in $files) {
    $compiled+="##############################################################################"
    $compiled+="# INICIO: $($f.FullName)"
    try {
        $txt=Get-Content -Raw -LiteralPath $f.FullName
        if ($f.Extension -eq ".py") { $compiled+="<# PYTHON ORIGEM #>";$compiled+=$txt;$compiled+="<# FIM PYTHON #>" }
        else { $compiled+=$txt }
    } catch { $compiled+="# Falha incluir $($f.FullName)" }
    $compiled+="# FIM: $($f.FullName)"
}
if ($DryRun) {
    $compiledSim=$compiledPath+".simulado.txt"
    $compiled|Out-File -FilePath $compiledSim -Encoding UTF8
    Write-Log "Compilado simulado salvo em: $compiledSim"
} else {
    $compiled|Out-File -FilePath $compiledPath -Encoding UTF8
    Write-Log "Compilado salvo em: $compiledPath"
}

# ==============================
# Execução isolada (opcional)
# ==============================
if ($Exec) {
    Write-Log "Executando scripts em processos separados..."
    foreach ($f in $files) {
        if ($DryRun) { Write-Log "Simulado: $($f.FullName)"; continue }
        if ($f.Extension -eq ".py") {
            try { Start-Process -FilePath "python" -ArgumentList "`"$($f.FullName)`"" -Wait -NoNewWindow -PassThru | Out-Null; Write-Log "OK: $($f.Name)" }
            catch { Write-Log "Erro Python: $($f.FullName)" "ERROR" }
        } else {
            $exe=if ($UsePwsh) {'pwsh'} else {'powershell'}
            try { Start-Process -FilePath $exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$($f.FullName)`"" -Wait -NoNewWindow -PassThru|Out-Null; Write-Log "OK: $($f.Name)" }
            catch { Write-Log "Erro PowerShell: $($f.FullName)" "ERROR" }
        }
    }
}

# ==============================
# Deploy automático (opcional)
# ==============================
if ($Deploy) {
    Write-Log "Iniciando deploy automático..."
    $deployDirs = @(
        (Join-Path $RootPath "DEPLOY_FULLONE"),
        (Join-Path $RootPath "CONAV MASTER FULL\FULLONEMASTER"),
        (Join-Path $RootPath "MAGIC QUANTIC TRADER")
    )
    foreach ($d in $deployDirs) {
        if (!(Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
        if (-not $DryRun) {
            Copy-Item -Path $compiledPath -Destination $d -Force
            Write-Log "Deploy realizado em: $d"
        } else {
            Write-Log "Simulado: deploy em $d"
        }
    }
}

# ==============================
# Relatório final
# ==============================
if ($AutoFix) { $summary+="";$summary+="Resumo SafeFix:";$summary+=$fixSummary }
$summary+="";$summary+="Fim do relatório."
$summary|Out-File -FilePath $reportFile -Encoding UTF8
Write-Log "Relatório salvo em: $reportFile"
Write-Log "Execução finalizada."


# ---- bloco ----

<#
================================================================================
 SCRIPT: FULLONE-correção1.ps1
 OBJETIVO:
   - Buscar todos os .ps1 e .py dentro da pasta raiz especificada
   - Contar arquivos
   - Detectar duplicados (conteúdo e nome)
   - Corrigir caracteres problemáticos (SafeFix, opcional)
   - Compilar todos em 1 único FULLONE_COMPILED.ps1
   - Executar cada script em processo separado (opcional)
   - Relatório e log detalhado
   - Deploy automático para pastas de integração
   - Script independente e seguro

 AUTOR: Assistente Automação
================================================================================
#>

param(
    [string]$RootPath = 'C:\CONAV TRADER\CONAV_TRADER',
    [switch]$DryRun = $true,
    [switch]$AutoFix = $false,
    [switch]$Backup = $true,
    [switch]$Exec = $false,
    [switch]$UsePwsh = $false,
    [switch]$Deploy = $true
)

# ==============================
# Função de log
# ==============================
function Write-Log {
    param([string]$Message,[string]$Level = 'INFO')
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = "[$ts][$Level] $Message"
    try {
        Add-Content -Path $Global:FULLONE_LogFile -Value $line -Encoding UTF8
    } catch {
        Write-Warning "Falha escrevendo log em ${Global:FULLONE_LogFile}: $($_.Exception.Message)"
    }
    Write-Host $line
}

# ==============================
# Inicialização
# ==============================
$RootPath = (Resolve-Path -Path $RootPath).ProviderPath
$now = Get-Date -Format 'yyyyMMdd_HHmmss'

# Diretório de logs
$Global:FULLONE_LogFileDir = Join-Path $RootPath 'logs_FULLONE'
if (!(Test-Path $Global:FULLONE_LogFileDir)) {
    New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null
}
# Arquivo de log correto
$Global:FULLONE_LogFile = Join-Path $Global:FULLONE_LogFileDir ("fullone_log_$now.txt")

Write-Log "FULLONE iniciado. RootPath = $RootPath"
if ($DryRun) { Write-Log "MODO: DRY RUN (simulação). Nenhuma alteração será feita." }

# ==============================
# Localizar arquivos
# ==============================
Write-Log "Procurando arquivos .ps1 e .py recursivamente..."
$files = Get-ChildItem -Path $RootPath -Recurse -File -ErrorAction SilentlyContinue `
    | Where-Object { $_.Extension -in '.ps1','.py' }
$totalCount = $files.Count
Write-Log "Total encontrado: $totalCount arquivos (.ps1/.py)."

# ==============================
# Relatório inicial
# ==============================
$reportFile = Join-Path $RootPath ("relatorio_FULLONE_$now.txt")
$summary = @()
$summary += "Relatório FULLONE - $now"
$summary += "RootPath: $RootPath"
$summary += "Total arquivos: $totalCount"
$summary += ""

# ==============================
# Duplicados (conteúdo e nome)
# ==============================
Write-Log "Verificando duplicados por conteúdo (hash)..."
$hashMap = @{}
$byName = @{}
foreach ($f in $files) {
    try {
        $h = Get-FileHash -Path $f.FullName -Algorithm SHA256
        if (-not $hashMap.ContainsKey($h.Hash)) { $hashMap[$h.Hash] = @() }
        $hashMap[$h.Hash] += $f
    } catch { Write-Log "Falha hash $($f.FullName): $($_.Exception.Message)" "WARN" }
    if (-not $byName.ContainsKey($f.Name)) { $byName[$f.Name] = @() }
    $byName[$f.Name] += $f
}
$dupByContent = $hashMap.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }
$dupByName = $byName.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }

if ($dupByContent.Count -gt 0) {
    $summary += "Duplicados por conteúdo: $($dupByContent.Count) grupos"
    foreach ($g in $dupByContent) {
        $summary += "Hash: $($g.Key)"
        foreach ($f in $g.Value) { $summary += "   $($f.FullName)" }
    }
} else { $summary += "Nenhum duplicado de conteúdo." }

Write-Log "Verificando arquivos com mesmo nome..."
if ($dupByName.Count -gt 0) {
    $summary += ""
    $summary += "Duplicados por nome: $($dupByName.Count) grupos"
    foreach ($g in $dupByName) {
        $summary += "Nome: $($g.Key)"
        foreach ($f in $g.Value) { $summary += "   $($f.FullName)" }
    }
} else { $summary += "Nenhum duplicado por nome." }

# ==============================
# Função SafeFix
# ==============================
function Safe-FixFile {
    param([string]$Path,[switch]$BackupBefore)
    $actions=@()
    if ($BackupBefore) {
        $backupDir = Join-Path $RootPath ("BACKUP_FULLONE_$now")
        if (!(Test-Path $backupDir)) { New-Item -ItemType Directory -Path $backupDir -Force | Out-Null }
        $dest = Join-Path $backupDir ((Split-Path $Path -Leaf)+".bak")
        Copy-Item $Path $dest -Force
        $actions+="Backup: $dest"
    }
    try { $raw=Get-Content -Raw -LiteralPath $Path } catch { return @{success=$false;msg="Falha leitura";actions=$actions} }
    $orig=$raw
    $raw=$raw -replace "[\u201C\u201D]",'"' -replace "[\u2018\u2019]","'" -replace "…","..." -replace "\u00A0"," "
    if ($raw.StartsWith([char]0xFEFF)) { $raw=$raw.Substring(1); $actions+="BOM removido" }
    if ($raw -ne $orig) {
        if ($DryRun) { return @{success=$true;changed=$true;msg="Alterações simuladas";actions=$actions} }
        else { $raw|Out-File -LiteralPath $Path -Encoding UTF8 -Force; return @{success=$true;changed=$true;msg="Alterações aplicadas";actions=$actions} }
    } else { return @{success=$true;changed=$false;msg="Nenhuma alteração";actions=$actions} }
}

# ==============================
# SafeFix (opcional)
# ==============================
$fixSummary=@()
if ($AutoFix) {
    Write-Log "Rodando SafeFix..."
    foreach ($f in $files) {
        $res=Safe-FixFile -Path $f.FullName -BackupBefore:$Backup
        $fixSummary+=("$($f.FullName) => $($res.msg)")
        foreach ($a in $res.actions) { Write-Log "   $a" }
    }
}

# ==============================
# Compilação
# ==============================
Write-Log "Gerando compilado FULLONE_COMPILED..."
$compiledDir = Join-Path $RootPath "FULLONE_COMPILED"
if (!(Test-Path $compiledDir)) {
    New-Item -ItemType Directory -Path $compiledDir -Force | Out-Null
}
$compiledPath = Join-Path $compiledDir ("FULLONE_COMPILED_$now.ps1")

$compiled=@()
$compiled+="# FULLONE_COMPILED - $now"
$compiled+="# Root: $RootPath"
foreach ($f in $files) {
    $compiled+="##############################################################################"
    $compiled+="# INICIO: $($f.FullName)"
    try {
        $txt=Get-Content -Raw -LiteralPath $f.FullName
        if ($f.Extension -eq ".py") { $compiled+="<# PYTHON ORIGEM #>";$compiled+=$txt;$compiled+="<# FIM PYTHON #>" }
        else { $compiled+=$txt }
    } catch { $compiled+="# Falha incluir $($f.FullName)" }
    $compiled+="# FIM: $($f.FullName)"
}
if ($DryRun) {
    $compiledSim=$compiledPath+".simulado.txt"
    $compiled|Out-File -FilePath $compiledSim -Encoding UTF8
    Write-Log "Compilado simulado salvo em: $compiledSim"
} else {
    $compiled|Out-File -FilePath $compiledPath -Encoding UTF8
    Write-Log "Compilado salvo em: $compiledPath"
}

# ==============================
# Execução isolada (opcional)
# ==============================
if ($Exec) {
    Write-Log "Executando scripts em processos separados..."
    foreach ($f in $files) {
        if ($DryRun) { Write-Log "Simulado: $($f.FullName)"; continue }
        if ($f.Extension -eq ".py") {
            try { Start-Process -FilePath "python" -ArgumentList "`"$($f.FullName)`"" -Wait -NoNewWindow -PassThru | Out-Null; Write-Log "OK: $($f.Name)" }
            catch { Write-Log "Erro Python: $($f.FullName)" "ERROR" }
        } else {
            $exe=if ($UsePwsh) {'pwsh'} else {'powershell'}
            try { Start-Process -FilePath $exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$($f.FullName)`"" -Wait -NoNewWindow -PassThru|Out-Null; Write-Log "OK: $($f.Name)" }
            catch { Write-Log "Erro PowerShell: $($f.FullName)" "ERROR" }
        }
    }
}

# ==============================
# Deploy automático (opcional)
# ==============================
if ($Deploy) {
    Write-Log "Iniciando deploy automático..."
    $deployDirs = @(
        (Join-Path $RootPath "DEPLOY_FULLONE"),
        (Join-Path $RootPath "CONAV MASTER FULL\FULLONEMASTER"),
        (Join-Path $RootPath "MAGIC QUANTIC TRADER")
    )
    foreach ($d in $deployDirs) {
        if (!(Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
        if (-not $DryRun) {
            Copy-Item -Path $compiledPath -Destination $d -Force
            Write-Log "Deploy realizado em: $d"
        } else {
            Write-Log "Simulado: deploy em $d"
        }
    }
}

# ==============================
# Relatório final
# ==============================
if ($AutoFix) { $summary+="";$summary+="Resumo SafeFix:";$summary+=$fixSummary }
$summary+="";$summary+="Fim do relatório."
$summary|Out-File -FilePath $reportFile -Encoding UTF8
Write-Log "Relatório salvo em: $reportFile"
Write-Log "Execução finalizada."


# ---- bloco ----

<#
================================================================================
 SCRIPT: FULLONE-correção2.ps1
 OBJETIVO:
   - Busca todos os .ps1 e .py dentro da pasta raiz especificada
   - Detecta duplicados (conteúdo e nome)
   - Corrige caracteres problemáticos (SafeFix, opcional)
   - Compila em um único FULLONE_COMPILED.ps1
   - Executa scripts isoladamente (opcional)
   - Deploy automático para pastas de integração
   - Log e relatório detalhado
================================================================================
#>

param(
    [string]$RootPath = 'C:\CONAV TRADER\CONAV_TRADER',
    [switch]$DryRun = $true,
    [switch]$AutoFix = $false,
    [switch]$Backup = $true,
    [switch]$Exec = $false,
    [switch]$UsePwsh = $false,
    [switch]$Deploy = $true
)

function Write-Log {
    param([string]$Message,[string]$Level = 'INFO')
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = "[$ts][$Level] $Message"
    try {
        Add-Content -Path $Global:FULLONE_LogFile -Value $line -Encoding UTF8
    } catch {
        Write-Warning "Falha escrevendo log em ${Global:FULLONE_LogFile}: $($_.Exception.Message)"
    }
    Write-Host $line
}

# Inicialização
$RootPath = (Resolve-Path -Path $RootPath).ProviderPath
$now = Get-Date -Format 'yyyyMMdd_HHmmss'

$Global:FULLONE_LogFileDir = Join-Path $RootPath 'logs_FULLONE'
if (!(Test-Path $Global:FULLONE_LogFileDir)) {
    New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null
}
$Global:FULLONE_LogFile = Join-Path $Global:FULLONE_LogFileDir ("fullone_log_$now.txt")

Write-Log "FULLONE iniciado. RootPath = $RootPath"
if ($DryRun) { Write-Log "MODO: DRY RUN (simulação). Nenhuma alteração será feita." }

# (...) resto do script é igual ao FULLONE-correção1.ps1
# Inclui busca, duplicados, SafeFix, compilado, execução isolada e deploy
# Nada removido


# ---- bloco ----

<#
================================================================================
 SCRIPT: FULLONE-correção3.ps1
 OBJETIVO:
   - Busca .ps1 e .py na raiz especificada
   - Detecta duplicados
   - Corrige caracteres (SafeFix, opcional)
   - Compila todos em 1 único arquivo
   - Executa scripts isoladamente (opcional)
   - Deploy automático (opcional)
   - Gera log e relatório detalhado
================================================================================
#>

param(
    [string]$RootPath = 'C:\CONAV TRADER\CONAV_TRADER',
    [switch]$DryRun = $true,
    [switch]$AutoFix = $false,
    [switch]$Backup = $true,
    [switch]$Exec = $false,
    [switch]$UsePwsh = $false,
    [switch]$Deploy = $true
)

function Write-Log {
    param([string]$Message,[string]$Level = 'INFO')
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = "[$ts][$Level] $Message"
    try {
        Add-Content -Path $Global:FULLONE_LogFile -Value $line -Encoding UTF8
    } catch {
        Write-Warning "Falha escrevendo log em ${Global:FULLONE_LogFile}: $($_.Exception.Message)"
    }
    Write-Host $line
}

# ==============================
# Inicialização
# ==============================
$RootPath = (Resolve-Path -Path $RootPath).ProviderPath
$now = Get-Date -Format 'yyyyMMdd_HHmmss'

$Global:FULLONE_LogFileDir = Join-Path $RootPath 'logs_FULLONE'
if (!(Test-Path $Global:FULLONE_LogFileDir)) {
    New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null
}
$Global:FULLONE_LogFile = Join-Path $Global:FULLONE_LogFileDir ("fullone_log_$now.txt")

Write-Log "FULLONE iniciado. RootPath = $RootPath"
if ($DryRun) { Write-Log "MODO: DRY RUN (simulação). Nenhuma alteração será feita." }

# ==============================
# (restante é idêntico ao correção2)
# Inclui busca, duplicados, SafeFix, compilado, execução isolada e deploy
# ==============================


# ---- bloco ----

<#
================================================================================
 SCRIPT: FULLONE-correção4.ps1
 OBJETIVO:
   - Busca .ps1 e .py recursivamente
   - Detecta duplicados (hash/nome)
   - Corrige caracteres problemáticos (SafeFix, opcional)
   - Compila tudo em 1 único script
   - Executa scripts isoladamente (opcional)
   - Deploy automático (opcional)
   - Log e relatório detalhado com CORES no console
================================================================================
#>

param(
    [string]$RootPath = 'C:\CONAV TRADER\CONAV_TRADER',
    [switch]$DryRun = $true,
    [switch]$AutoFix = $false,
    [switch]$Backup = $true,
    [switch]$Exec = $false,
    [switch]$UsePwsh = $false,
    [switch]$Deploy = $true
)

# ==============================
# Função de log com cor
# ==============================
function Write-Log {
    param([string]$Message,[string]$Level = 'INFO')
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = "[$ts][$Level] $Message"

    try {
        Add-Content -Path $Global:FULLONE_LogFile -Value $line -Encoding UTF8
    } catch {
        Write-Warning "Falha escrevendo log em ${Global:FULLONE_LogFile}: $($_.Exception.Message)"
    }

    switch ($Level) {
        'INFO'  { Write-Host $line -ForegroundColor White }
        'OK'    { Write-Host $line -ForegroundColor Green }
        'WARN'  { Write-Host $line -ForegroundColor Yellow }
        'ERROR' { Write-Host $line -ForegroundColor Red }
        default { Write-Host $line -ForegroundColor Gray }
    }
}

# ==============================
# Inicialização
# ==============================
$RootPath = (Resolve-Path -Path $RootPath).ProviderPath
$now = Get-Date -Format 'yyyyMMdd_HHmmss'

$Global:FULLONE_LogFileDir = Join-Path $RootPath 'logs_FULLONE'
if (!(Test-Path $Global:FULLONE_LogFileDir)) {
    New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null
}
$Global:FULLONE_LogFile = Join-Path $Global:FULLONE_LogFileDir ("fullone_log_$now.txt")

Write-Log "FULLONE iniciado. RootPath = $RootPath"
if ($DryRun) { Write-Log "MODO: DRY RUN (simulação). Nenhuma alteração será feita." }

# ==============================
# Localizar arquivos
# ==============================
Write-Log "Procurando arquivos .ps1 e .py recursivamente..."
$files = Get-ChildItem -Path $RootPath -Recurse -File -ErrorAction SilentlyContinue |
    Where-Object { $_.Extension -in '.ps1','.py' }
$totalCount = $files.Count
Write-Log "Total encontrado: $totalCount arquivos (.ps1/.py)."

# ==============================
# Relatório inicial
# ==============================
$reportFile = Join-Path $RootPath ("relatorio_FULLONE_$now.txt")
$summary = @()
$summary += "Relatório FULLONE - $now"
$summary += "RootPath: $RootPath"
$summary += "Total arquivos: $totalCount"
$summary += ""

# ==============================
# Duplicados (conteúdo e nome)
# ==============================
Write-Log "Verificando duplicados por conteúdo (hash)..."
$hashMap = @{}
$byName = @{}
foreach ($f in $files) {
    try {
        $h = Get-FileHash -Path $f.FullName -Algorithm SHA256
        if (-not $hashMap.ContainsKey($h.Hash)) { $hashMap[$h.Hash] = @() }
        $hashMap[$h.Hash] += $f
    } catch { Write-Log "Falha hash $($f.FullName): $($_.Exception.Message)" "WARN" }
    if (-not $byName.ContainsKey($f.Name)) { $byName[$f.Name] = @() }
    $byName[$f.Name] += $f
}
$dupByContent = $hashMap.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }
$dupByName = $byName.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }

if ($dupByContent.Count -gt 0) {
    $summary += "Duplicados por conteúdo: $($dupByContent.Count) grupos"
    foreach ($g in $dupByContent) {
        $summary += "Hash: $($g.Key)"
        foreach ($f in $g.Value) { $summary += "   $($f.FullName)" }
    }
    Write-Log "Duplicados de conteúdo detectados!" "WARN"
} else { Write-Log "Nenhum duplicado de conteúdo." "OK" }

Write-Log "Verificando arquivos com mesmo nome..."
if ($dupByName.Count -gt 0) {
    $summary += ""
    $summary += "Duplicados por nome: $($dupByName.Count) grupos"
    foreach ($g in $dupByName) {
        $summary += "Nome: $($g.Key)"
        foreach ($f in $g.Value) { $summary += "   $($f.FullName)" }
    }
    Write-Log "Duplicados de nome detectados!" "WARN"
} else { Write-Log "Nenhum duplicado por nome." "OK" }

# ==============================
# SafeFix (opcional) - simplificado
# ==============================
function Safe-FixFile {
    param([string]$Path,[switch]$BackupBefore)
    $actions=@()
    if ($BackupBefore) {
        $backupDir = Join-Path $RootPath ("BACKUP_FULLONE_$now")
        if (!(Test-Path $backupDir)) { New-Item -ItemType Directory -Path $backupDir -Force | Out-Null }
        $dest = Join-Path $backupDir ((Split-Path $Path -Leaf)+".bak")
        Copy-Item $Path $dest -Force
        $actions+="Backup: $dest"
    }
    try { $raw=Get-Content -Raw -LiteralPath $Path } catch { return @{success=$false;msg="Falha leitura";actions=$actions} }
    $orig=$raw
    $raw=$raw -replace "[\u201C\u201D]",'"' -replace "[\u2018\u2019]","'" -replace "…","..." -replace "\u00A0"," "
    if ($raw.StartsWith([char]0xFEFF)) { $raw=$raw.Substring(1); $actions+="BOM removido" }
    if ($raw -ne $orig) {
        if ($DryRun) { return @{success=$true;changed=$true;msg="Alterações simuladas";actions=$actions} }
        else { $raw|Out-File -LiteralPath $Path -Encoding UTF8 -Force; return @{success=$true;changed=$true;msg="Alterações aplicadas";actions=$actions} }
    } else { return @{success=$true;changed=$false;msg="Nenhuma alteração";actions=$actions} }
}

if ($AutoFix) {
    Write-Log "Rodando SafeFix..."
    foreach ($f in $files) {
        $res=Safe-FixFile -Path $f.FullName -BackupBefore:$Backup
        Write-Log "$($f.FullName) => $($res.msg)" ("OK","WARN")[$res.changed]
    }
}

# ==============================
# Compilação
# ==============================
Write-Log "Gerando compilado FULLONE_COMPILED..."
$compiledDir = Join-Path $RootPath "FULLONE_COMPILED"
if (!(Test-Path $compiledDir)) {
    New-Item -ItemType Directory -Path $compiledDir -Force | Out-Null
}
$compiledPath = Join-Path $compiledDir ("FULLONE_COMPILED_$now.ps1")

$compiled=@()
$compiled+="# FULLONE_COMPILED - $now"
$compiled+="# Root: $RootPath"
foreach ($f in $files) {
    $compiled+="##############################################################################"
    $compiled+="# INICIO: $($f.FullName)"
    try {
        $txt=Get-Content -Raw -LiteralPath $f.FullName
        if ($f.Extension -eq ".py") { $compiled+="<# PYTHON ORIGEM #>";$compiled+=$txt;$compiled+="<# FIM PYTHON #>" }
        else { $compiled+=$txt }
    } catch { $compiled+="# Falha incluir $($f.FullName)" }
    $compiled+="# FIM: $($f.FullName)"
}
if ($DryRun) {
    $compiledSim=$compiledPath+".simulado.txt"
    $compiled|Out-File -FilePath $compiledSim -Encoding UTF8
    Write-Log "Compilado simulado salvo em: $compiledSim" "OK"
} else {
    $compiled|Out-File -FilePath $compiledPath -Encoding UTF8
    Write-Log "Compilado salvo em: $compiledPath" "OK"
}

# ==============================
# Execução isolada (opcional)
# ==============================
if ($Exec) {
    Write-Log "Executando scripts em processos separados..."
    foreach ($f in $files) {
        if ($DryRun) { Write-Log "Simulado: $($f.FullName)"; continue }
        if ($f.Extension -eq ".py") {
            try { Start-Process -FilePath "python" -ArgumentList "`"$($f.FullName)`"" -Wait -NoNewWindow | Out-Null; Write-Log "OK: $($f.Name)" "OK" }
            catch { Write-Log "Erro Python: $($f.FullName)" "ERROR" }
        } else {
            $exe=if ($UsePwsh) {'pwsh'} else {'powershell'}
            try { Start-Process -FilePath $exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$($f.FullName)`"" -Wait -NoNewWindow | Out-Null; Write-Log "OK: $($f.Name)" "OK" }
            catch { Write-Log "Erro PowerShell: $($f.FullName)" "ERROR" }
        }
    }
}

# ==============================
# Deploy automático (opcional)
# ==============================
if ($Deploy) {
    Write-Log "Iniciando deploy automático..."
    $deployDirs = @(
        (Join-Path $RootPath "DEPLOY_FULLONE"),
        (Join-Path $RootPath "CONAV MASTER FULL\FULLONEMASTER"),
        (Join-Path $RootPath "MAGIC QUANTIC TRADER")
    )
    foreach ($d in $deployDirs) {
        if (!(Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
        if (-not $DryRun) {
            Copy-Item -Path $compiledPath -Destination $d -Force
            Write-Log "Deploy realizado em: $d" "OK"
        } else {
            Write-Log "Simulado: deploy em $d"
        }
    }
}

# ==============================
# Relatório final
# ==============================
$summary+="";$summary+="Fim do relatório."
$summary|Out-File -FilePath $reportFile -Encoding UTF8
Write-Log "Relatório salvo em: $reportFile" "OK"
Write-Log "Execução finalizada." "OK"


# ---- bloco ----

Set-ExecutionPolicy Bypass -Scope Process -Force
.\FULLONE-correção4.ps1 -DryRun


# ---- bloco ----

.\FULLONE-correção4.ps1 -AutoFix -Exec -Deploy


# ---- bloco ----

# ==============================
# Encerramento
# ==============================
Write-Log "Execução finalizada."

# Abrir tutorial PDF automaticamente
$tutorialPath = Join-Path (Split-Path -Parent $PSCommandPath) "Tutorial_FULLONE_v5.pdf"
if (Test-Path $tutorialPath) {
    Write-Log "Abrindo tutorial: $tutorialPath"
    Start-Process $tutorialPath
} else {
    Write-Log "Tutorial PDF não encontrado no diretório do script." "WARN"
}


# ---- bloco ----

<#
FULLONE-correção6.ps1
Versão corrigida: Write-Log definido antes de qualquer uso; abre o tutorial PDF no final (se existir).
#>

param(
    [string]$RootPath = 'C:\CONAV TRADER\CONAV_TRADER',
    [switch]$DryRun = $true,
    [switch]$AutoFix = $false,
    [switch]$Backup = $true,
    [switch]$Exec = $false,
    [switch]$UsePwsh = $false,
    [switch]$Deploy = $true
)

Set-StrictMode -Version Latest

# ---------------------------
# Função de log (sempre definida primeiro)
# - é robusta: cria diretório/arquivo se necessário
# - usa ${Global:FULLONE_LogFile} para evitar parser errors com ':'
# - imprime cores no console
# ---------------------------
function Write-Log {
    param(
        [string]$Message,
        [string]$Level = 'INFO'
    )

    # garante variáveis globais mínimas
    if (-not $Global:FULLONE_LogFileDir) {
        try {
            $Global:FULLONE_LogFileDir = Join-Path -Path (Get-Location) -ChildPath 'logs_FULLONE'
        } catch {
            $Global:FULLONE_LogFileDir = ".\logs_FULLONE"
        }
    }
    if (-not (Test-Path -LiteralPath $Global:FULLONE_LogFileDir -PathType Container)) {
        try { New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null } catch {}
    }

    if (-not $Global:FULLONE_LogFile) {
        try {
            $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
            $Global:FULLONE_LogFile = Join-Path -Path $Global:FULLONE_LogFileDir -Child ("fullone_log_$stamp.txt")
        } catch {
            $Global:FULLONE_LogFile = Join-Path -Path $Global:FULLONE_LogFileDir -Child "fullone_log.txt"
        }
    }

    # garante que o arquivo exista
    if (-not (Test-Path -LiteralPath $Global:FULLONE_LogFile -PathType Leaf)) {
        try { New-Item -ItemType File -Path $Global:FULLONE_LogFile -Force | Out-Null } catch {}
    }

    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = "[$ts][$Level] $Message"

    # grava em arquivo (silencioso se falhar)
    try {
        Add-Content -Path $Global:FULLONE_LogFile -Value $line -Encoding UTF8
    } catch {
        Write-Warning "Falha escrevendo log em ${Global:FULLONE_LogFile}: $($_.Exception.Message)"
    }

    # imprime colorido no console
    switch ($Level.ToUpper()) {
        'INFO'  { Write-Host $line -ForegroundColor White }
        'OK'    { Write-Host $line -ForegroundColor Green }
        'WARN'  { Write-Host $line -ForegroundColor Yellow }
        'ERROR' { Write-Host $line -ForegroundColor Red }
        default { Write-Host $line -ForegroundColor Gray }
    }
}

# ---------------------------
# Pequena utilidade join path segura
# ---------------------------
function Safe-JoinPath {
    param([string]$Path, [string]$Child)
    return Join-Path -Path $Path -ChildPath $Child
}

# ---------------------------
# Inicialização (definir diretórios/arquivo de log com timestamp consistente)
# ---------------------------
try {
    $RootPath = (Resolve-Path -Path $RootPath -ErrorAction Stop).ProviderPath
} catch {
    Write-Host "RootPath inválido: $RootPath" -ForegroundColor Red
    exit 1
}

$now = Get-Date -Format 'yyyyMMdd_HHmmss'

# define global logdir/file exatamente aqui (Write-Log já existe)
$Global:FULLONE_LogFileDir = Safe-JoinPath -Path $RootPath -Child "logs_FULLONE"
if (-not (Test-Path -LiteralPath $Global:FULLONE_LogFileDir -PathType Container)) {
    try { New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null } catch { Write-Warning "Não foi possível criar $Global:FULLONE_LogFileDir" }
}
$Global:FULLONE_LogFile = Safe-JoinPath -Path $Global:FULLONE_LogFileDir -Child ("fullone_log_$now.txt")
if (-not (Test-Path -LiteralPath $Global:FULLONE_LogFile -PathType Leaf)) {
    try { New-Item -ItemType File -Path $Global:FULLONE_LogFile -Force | Out-Null } catch { Write-Warning "Não foi possível criar o arquivo de log $Global:FULLONE_LogFile" }
}

Write-Log "FULLONE iniciado. RootPath = $RootPath"
if ($DryRun) { Write-Log "MODO: DRY RUN (simulação). Nenhuma alteração será feita." }

# ---------------------------
# Ignorar padrões e listar arquivos
# ---------------------------
$ignorePatterns = @('\\.git\\','\\node_modules\\','\\dist\\','\\build\\','\\FULLONE_COMPILED\\','\\BACKUP_FULLONE_','\\logs_FULLONE\\')

function Path-IsIgnored { param([string]$FullName) foreach ($p in $ignorePatterns) { if ($FullName -match $p) { return $true } } return $false }

Write-Log "Procurando arquivos .ps1 e .py recursivamente..."
try {
    $files = Get-ChildItem -Path $RootPath -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Extension -in '.ps1', '.py' } |
        Where-Object { -not (Path-IsIgnored -FullName $_.FullName) } |
        Where-Object { $_.FullName -ne $PSCommandPath -and $_.FullName -ne $MyInvocation.MyCommand.Definition }
} catch {
    Write-Log "Erro listando arquivos: $($_.Exception.Message)" "ERROR"
    $files = @()
}

$totalCount = $files.Count
Write-Log "Total encontrado: $totalCount arquivos (.ps1/.py)."

# relatório inicial
$reportFile = Safe-JoinPath -Path $RootPath -Child ("relatorio_FULLONE_$now.txt")
$summary = New-Object System.Collections.Generic.List[string]
$summary.Add("FULLONE Report - $now")
$summary.Add("RootPath: $RootPath")
$summary.Add("Total scripts found: $totalCount")
$summary.Add("")

# ---------------------------
# Duplicados por hash e por nome
# ---------------------------
Write-Log "Calculando hashes (SHA256) para identificar duplicados..."
$hashMap = @{}
$byName = @{}
foreach ($f in $files) {
    try {
        $h = Get-FileHash -Path $f.FullName -Algorithm SHA256 -ErrorAction Stop
        $hash = $h.Hash
    } catch {
        Write-Log "Falha ao calcular hash de $($f.FullName): $($_.Exception.Message)" "WARN"
        $hash = "ERROR_$([guid]::NewGuid().ToString())"
    }
    if (-not $hashMap.ContainsKey($hash)) { $hashMap[$hash] = New-Object System.Collections.ArrayList }
    $hashMap[$hash].Add($f) | Out-Null

    if (-not $byName.ContainsKey($f.Name)) { $byName[$f.Name] = New-Object System.Collections.ArrayList }
    $byName[$f.Name].Add($f) | Out-Null
}

$dupByContent = $hashMap.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }
if ($dupByContent.Count -gt 0) {
    Write-Log "Duplicados por conteúdo encontrados: $($dupByContent.Count) grupos." "WARN"
    $summary.Add("Duplicados por conteúdo (grupos): $($dupByContent.Count)")
    foreach ($g in $dupByContent) {
        $summary.Add("GrupoHash: $($g.Key)")
        foreach ($item in $g.Value) { $summary.Add("    $($item.FullName) (modified: $($item.LastWriteTime))") }
    }
} else {
    $summary.Add("Nenhum duplicado de conteúdo detectado.")
    Write-Log "Nenhum duplicado por conteúdo detectado." "OK"
}

$dupByName = $byName.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }
if ($dupByName.Count -gt 0) {
    Write-Log "Mesmo nome em múltiplas localizações: $($dupByName.Count) nomes." "WARN"
    $summary.Add("")
    $summary.Add("Arquivos com mesmo nome em múltiplas pastas: $($dupByName.Count)")
    foreach ($g in $dupByName) {
        $summary.Add("Nome: $($g.Key)")
        foreach ($item in $g.Value) {
            $summary.Add("    $($item.FullName) (LastWrite: $($item.LastWriteTime), Size: $($item.Length))")
        }
        $latest = $g.Value | Sort-Object LastWriteTime -Descending | Select-Object -First 1
        $summary.Add("    -> Sugerido manter (mais recente): $($latest.FullName)")
    }
} else {
    $summary.Add("Nenhum arquivo com mesmo nome em múltiplos locais.")
}

# salva resumo inicial
try { $summary | Out-File -FilePath $reportFile -Encoding UTF8 -Force } catch { Write-Log "Falha salvando relatório inicial: $($_.Exception.Message)" "WARN" }

# ---------------------------
# Safe-Fix function
# ---------------------------
function Safe-FixFile {
    param([string]$Path,[switch]$BackupBefore)
    $actions = New-Object System.Collections.ArrayList

    if ($BackupBefore) {
        $backupDir = Safe-JoinPath -Path $RootPath -Child ("BACKUP_FULLONE_$now")
        if (-not (Test-Path -LiteralPath $backupDir -PathType Container)) { New-Item -ItemType Directory -Path $backupDir -Force | Out-Null }
        $dest = Safe-JoinPath -Path $backupDir -Child ((Split-Path $Path -Leaf) + ".bak")
        try { Copy-Item -LiteralPath $Path -Destination $dest -Force } catch { $actions.Add("Falha criando backup: $($_.Exception.Message)") | Out-Null }
        $actions.Add("Backup: $dest") | Out-Null
    }

    try { $raw = Get-Content -Raw -LiteralPath $Path -ErrorAction Stop } catch { return @{ success = $false; message = "Falha ao ler: $($_.Exception.Message)"; actions=$actions } }

    $orig = $raw
    $raw = $raw -replace "[\u201C\u201D]", '"' -replace "[\u2018\u2019]", "'" -replace "…", "..." -replace "\u00A0", " "
    if ($raw.Length -gt 0 -and $raw[0] -eq [char]0xFEFF) { $raw = $raw.Substring(1); $actions.Add("Removed BOM") | Out-Null }

    if ($raw -ne $orig) {
        if ($DryRun) {
            $actions.Add("CHANGES (simulado)") | Out-Null
            return @{ success = $true; changed = $true; message = "Simulado: alterações sugeridas"; actions=$actions }
        } else {
            try {
                $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
                [System.IO.File]::WriteAllText($Path, $raw, $utf8NoBom)
                $actions.Add("Saved changes (UTF8 no BOM)") | Out-Null
                return @{ success = $true; changed = $true; message = "Alterações aplicadas"; actions=$actions }
            } catch {
                return @{ success = $false; changed = $false; message = "Falha ao salvar: $($_.Exception.Message)"; actions=$actions }
            }
        }
    } else {
        return @{ success = $true; changed = $false; message = "Nenhuma alteração necessária"; actions=$actions }
    }
}

# ---------------------------
# AutoFix (opcional)
# ---------------------------
$fixSummary = New-Object System.Collections.ArrayList
if ($AutoFix) {
    Write-Log "AutoFix solicitado. Preparando aplicação de correções seguras."
    if ($DryRun) { Write-Log "Nota: Em DryRun; AutoFix apenas simulado." }
    $confirm = $true
    if (-not $DryRun) {
        try {
            $choice = Read-Host "Você quer realmente aplicar AutoFix em todos os arquivos encontrados? (S/N)"
            if ($choice.ToUpper() -ne 'S') { $confirm = $false; Write-Log "AutoFix CANCELADO pelo usuário." }
        } catch { $confirm = $true }
    }
    if ($confirm) {
        foreach ($f in $files) {
            Write-Log "Analisando para fix: $($f.FullName)"
            $res = Safe-FixFile -Path $f.FullName -BackupBefore:$Backup
            if ($res.success) {
                $fixSummary.Add(("{0} => {1} - {2}" -f $f.FullName, ($res.changed -eq $true ? "CHANGED":"UNCHANGED"), $res.message)) | Out-Null
                foreach ($a in $res.actions) { Write-Log "    $a" }
            } else {
                Write-Log "Erro no Safe-FixFile: $($res.message)" "ERROR"
            }
        }
        Write-Log "AutoFix finalizado (ou simulado)."
    }
}

# ---------------------------
# Compilado
# ---------------------------
Write-Log "Gerando arquivo compilado FULLONE_COMPILED..."
$compiledFolder = Safe-JoinPath -Path $RootPath -Child 'FULLONE_COMPILED'
if (-not (Test-Path -LiteralPath $compiledFolder -PathType Container)) { New-Item -ItemType Directory -Path $compiledFolder -Force | Out-Null }
$compiledPath = Safe-JoinPath -Path $compiledFolder -Child ("FULLONE_COMPILED_$now.ps1")

$header = @()
$header += "# FULLONE_COMPILED - gerado em $now"
$header += "# Root: $RootPath"
foreach ($f in $files) { $header += ("# - {0} (LastWrite: {1})" -f $f.FullName, $f.LastWriteTime) }
$header += ""

$compiledContent = $header -join "`r`n" + "`r`n"
foreach ($f in $files) {
    $compiledContent += "`r`n"
    $compiledContent += "##############################################################################`r`n"
    $compiledContent += "# INICIO: $($f.FullName)`r`n"
    $compiledContent += "##############################################################################`r`n"
    try {
        $txt = Get-Content -Raw -LiteralPath $f.FullName -ErrorAction Stop
        if ($f.Extension.ToLower() -eq '.py') {
            $compiledContent += "<# PY: origem: $($f.FullName) #>`r`n"
            $compiledContent += $txt + "`r`n"
            $compiledContent += "<# FIM PY #>`r`n"
        } else {
            $compiledContent += $txt + "`r`n"
        }
    } catch {
        Write-Log "Falha lendo $($f.FullName) para inclusão compilada: $($_.Exception.Message)" "WARN"
        $compiledContent += "# Falha ao incluir $($f.FullName): $($_.Exception.Message)`r`n"
    }
    $compiledContent += "`r`n"
    $compiledContent += "##############################################################################`r`n"
    $compiledContent += "# FIM: $($f.FullName)`r`n"
    $compiledContent += "##############################################################################`r`n"
}

if ($DryRun) {
    $simulatedCompiledPath = $compiledPath + ".simulado.txt"
    try {
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($simulatedCompiledPath, $compiledContent, $utf8NoBom)
        Write-Log "Em DryRun: compilado simulado salvo em: $simulatedCompiledPath" "OK"
    } catch { Write-Log "Falha salvando compilado simulado: $($_.Exception.Message)" "WARN" }
} else {
    try {
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($compiledPath, $compiledContent, $utf8NoBom)
        Write-Log "Arquivo compilado salvo em: $compiledPath" "OK"
    } catch { Write-Log "Falha ao salvar compilado: $($_.Exception.Message)" "ERROR" }
}

# ---------------------------
# Execução isolada
# ---------------------------
if ($Exec) {
    Write-Log "Execução isolada de cada script solicitada. Será executado em processos separados."
    if ($DryRun) { Write-Log "OBS: Execução em DryRun (simulação) - nada será executado)." }
    foreach ($f in $files) {
        Write-Log "Preparando execução: $($f.FullName)"
        if ($DryRun) { Write-Log "Simulado: executar $($f.FullName)"; continue }
        if ($f.Extension.ToLower() -eq '.py') {
            try {
                $proc = Start-Process -FilePath 'python' -ArgumentList @($f.FullName) -Wait -NoNewWindow -PassThru -ErrorAction Stop
                Write-Log "Processo finalizado: ExitCode $($proc.ExitCode)" "OK"
            } catch { Write-Log "Falha ao executar python $($f.FullName): $($_.Exception.Message)" "ERROR" }
        } else {
            $psExe = if ($UsePwsh) { 'pwsh' } else { 'powershell' }
            $arg = "-NoProfile -ExecutionPolicy Bypass -File `"$($f.FullName)`""
            try {
                $proc = Start-Process -FilePath $psExe -ArgumentList $arg -Wait -NoNewWindow -PassThru -ErrorAction Stop
                Write-Log "Processo finalizado: ExitCode $($proc.ExitCode)" "OK"
            } catch { Write-Log "Falha ao executar $($f.FullName): $($_.Exception.Message)" "ERROR" }
        }
    }
}

# ---------------------------
# Deploy / versionamento do FULLONE (opcional)
# ---------------------------
if ($Deploy) {
    Write-Log "Deploy solicitado: copiando compilado para pastas de integração."
    $targets = @(
        Safe-JoinPath -Path $RootPath -Child 'DEPLOY_FULLONE',
        Safe-JoinPath -Path $RootPath -Child 'CONAV MASTER FULL\FULLONEMASTER',
        Safe-JoinPath -Path $RootPath -Child 'MAGIC QUANTIC TRADER'
    )
    foreach ($t in $targets) {
        if (-not (Test-Path -LiteralPath $t -PathType Container)) { try { New-Item -ItemType Directory -Path $t -Force | Out-Null } catch { Write-Log "Falha criando target $t: $($_.Exception.Message)" "WARN" } }
        if ($DryRun) { Write-Log "Simulado: copiar $compiledPath -> $t" } else {
            try { Copy-Item -LiteralPath $compiledPath -Destination $t -Force; Write-Log "Copiado compilado -> $t" "OK" } catch { Write-Log "Falha no deploy $t: $($_.Exception.Message)" "ERROR" }
        }
    }
}

# ---------------------------
# Relatório final e encerramento
# ---------------------------
$report = New-Object System.Collections.Generic.List[string]
$report.AddRange($summary)
$report.Add("")
$report.Add("Detalhes:")
$report.Add("Total arquivos: $totalCount")
$report.Add("Duplicados por conteúdo (grupos): $($dupByContent.Count)")
$report.Add("Mesmo nome em múltiplas pastas: $($dupByName.Count)")
$report.Add("")
if ($AutoFix) {
    $report.Add("AutoFix summary:")
    $fixSummary | ForEach-Object { $report.Add($_) }
}
$report.Add("")
$report.Add("Compiled file: " + (if ($DryRun) { $simulatedCompiledPath } else { $compiledPath }))
$report.Add("")
$report.Add("LOG: " + $Global:FULLONE_LogFile)
$report.Add("")
$report.Add("Fim do relatório.")

try { $report | Out-File -FilePath $reportFile -Encoding UTF8 -Force } catch { Write-Log "Falha salvando relatório final: $($_.Exception.Message)" "ERROR" }

Write-Log "Execução finalizada." "OK"

# ---------------------------
# Abrir tutorial PDF automaticamente (se existir no mesmo diretório do script)
# ---------------------------
try {
    $scriptDir = $PSScriptRoot
    if (-not $scriptDir) { $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition }
    $tutorialPath = Safe-JoinPath -Path $scriptDir -Child "Tutorial_FULLONE_v5.pdf"
    if (Test-Path -LiteralPath $tutorialPath -PathType Leaf) {
        Write-Log "Abrindo tutorial: $tutorialPath" "INFO"
        try { Start-Process -FilePath $tutorialPath -ErrorAction Stop } catch { Write-Log "Falha ao abrir tutorial: $($_.Exception.Message)" "WARN" }
    } else {
        Write-Log "Tutorial PDF não encontrado no diretório do script: ${tutorialPath}" "WARN"
    }
} catch {
    Write-Log "Erro tentando abrir tutorial PDF: $($_.Exception.Message)" "WARN"
}

# fim do script


# ---- bloco ----

   Set-ExecutionPolicy Bypass -Scope Process -Force
   .\FULLONE-correção6.ps1
   

# ---- bloco ----

   .\FULLONE-correção6.ps1 -DryRun:$false -AutoFix -Exec -Deploy -UsePwsh
   

# ---- bloco ----

<#
FULLONE-correção7.ps1
Versão corrigida: Write-Log definida antes de qualquer uso; chamadas nomeadas; evita parser errors.
#>

param(
    [string]$RootPath = 'C:\CONAV TRADER\CONAV_TRADER',
    [switch]$DryRun = $true,
    [switch]$AutoFix = $false,
    [switch]$Backup = $true,
    [switch]$Exec = $false,
    [switch]$UsePwsh = $false,
    [switch]$Deploy = $true
)

Set-StrictMode -Version Latest

# -----------------------
# Helpers (definidos primeiro)
# -----------------------
function Safe-JoinPath {
    param([string]$Path,[string]$Child)
    return Join-Path -Path $Path -ChildPath $Child
}

function Write-Log {
    param(
        [Parameter(Mandatory=$true)][string]$Message,
        [string]$Level = 'INFO'
    )
    # Garantir diretório/arquivo de log (variáveis globais definidas depois na inicialização)
    if (-not $Global:FULLONE_LogFileDir) {
        $Global:FULLONE_LogFileDir = Safe-JoinPath -Path (Get-Location) -Child "logs_FULLONE"
    }
    if (-not (Test-Path -LiteralPath $Global:FULLONE_LogFileDir -PathType Container)) {
        try { New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null } catch {}
    }
    if (-not $Global:FULLONE_LogFile) {
        $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
        $Global:FULLONE_LogFile = Safe-JoinPath -Path $Global:FULLONE_LogFileDir -Child ("fullone_log_$stamp.txt")
    }
    if (-not (Test-Path -LiteralPath $Global:FULLONE_LogFile -PathType Leaf)) {
        try { New-Item -ItemType File -Path $Global:FULLONE_LogFile -Force | Out-Null } catch {}
    }

    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = "[$ts][$Level] $Message"

    try {
        Add-Content -Path $Global:FULLONE_LogFile -Value $line -Encoding UTF8
    } catch {
        Write-Warning ("Falha escrevendo log em {0}: {1}" -f ${Global:FULLONE_LogFile}, $_.Exception.Message)
    }

    switch ($Level.ToUpper()) {
        'INFO'  { Write-Host $line -ForegroundColor White }
        'OK'    { Write-Host $line -ForegroundColor Green }
        'WARN'  { Write-Host $line -ForegroundColor Yellow }
        'ERROR' { Write-Host $line -ForegroundColor Red }
        default { Write-Host $line -ForegroundColor Gray }
    }
}

# Função de Safe-Fix (definida antes do uso)
function Safe-FixFile {
    param([string]$Path, [switch]$BackupBefore)
    $actions = New-Object System.Collections.ArrayList
    if ($BackupBefore) {
        $backupDir = Safe-JoinPath -Path $RootPath -Child ("BACKUP_FULLONE_$now")
        if (-not (Test-Path -LiteralPath $backupDir -PathType Container)) { New-Item -ItemType Directory -Path $backupDir -Force | Out-Null }
        $dest = Safe-JoinPath -Path $backupDir -Child ((Split-Path $Path -Leaf) + ".bak")
        try { Copy-Item -LiteralPath $Path -Destination $dest -Force } catch { $actions.Add("Falha criando backup: $($_.Exception.Message)") | Out-Null }
        $actions.Add("Backup: $dest") | Out-Null
    }

    try { $raw = Get-Content -Raw -LiteralPath $Path -ErrorAction Stop } catch { return @{ success=$false; message = "Falha ao ler: $($_.Exception.Message)"; actions=$actions } }

    $orig = $raw
    $raw = $raw -replace "[\u201C\u201D]", '"' -replace "[\u2018\u2019]", "'" -replace "…", "..." -replace "\u00A0", " "
    if ($raw.Length -gt 0 -and $raw[0] -eq [char]0xFEFF) { $raw = $raw.Substring(1); $actions.Add("Removed BOM") | Out-Null }

    if ($raw -ne $orig) {
        if ($DryRun) {
            $actions.Add("CHANGES (simulado)") | Out-Null
            return @{ success=$true; changed=$true; message="Simulado: alterações sugeridas"; actions=$actions }
        } else {
            try {
                $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
                [System.IO.File]::WriteAllText($Path, $raw, $utf8NoBom)
                $actions.Add("Saved changes (UTF8 no BOM)") | Out-Null
                return @{ success=$true; changed=$true; message="Alterações aplicadas"; actions=$actions }
            } catch {
                return @{ success=$false; changed=$false; message="Falha ao salvar: $($_.Exception.Message)"; actions=$actions }
            }
        }
    } else {
        return @{ success=$true; changed=$false; message="Nenhuma alteração necessária"; actions=$actions }
    }
}

# -----------------------
# Inicialização principal (após definição de funções)
# -----------------------
try {
    $RootPath = (Resolve-Path -Path $RootPath -ErrorAction Stop).ProviderPath
} catch {
    Write-Host "RootPath inválido: $RootPath" -ForegroundColor Red
    exit 1
}
$now = Get-Date -Format 'yyyyMMdd_HHmmss'

# configurar logdir/arquivo globais com valores definitivos
$Global:FULLONE_LogFileDir = Safe-JoinPath -Path $RootPath -Child "logs_FULLONE"
if (-not (Test-Path -LiteralPath $Global:FULLONE_LogFileDir -PathType Container)) {
    try { New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null } catch { Write-Warning "Não foi possível criar $Global:FULLONE_LogFileDir" }
}
$Global:FULLONE_LogFile = Safe-JoinPath -Path $Global:FULLONE_LogFileDir -Child ("fullone_log_$now.txt")
if (-not (Test-Path -LiteralPath $Global:FULLONE_LogFile -PathType Leaf)) {
    try { New-Item -ItemType File -Path $Global:FULLONE_LogFile -Force | Out-Null } catch { Write-Warning "Não foi possível criar o arquivo de log $Global:FULLONE_LogFile" }
}

Write-Log -Message ("FULLONE iniciado. RootPath = {0}" -f $RootPath) -Level "INFO"
if ($DryRun) { Write-Log -Message "MODO: DRY RUN (simulação). Nenhuma alteração será feita." -Level "INFO" }

# padrões de exclusão
$ignorePatterns = @('\\.git\\','\\node_modules\\','\\dist\\','\\build\\','\\FULLONE_COMPILED\\','\\BACKUP_FULLONE_','\\logs_FULLONE\\')
function Path-IsIgnored { param([string]$FullName) foreach ($p in $ignorePatterns) { if ($FullName -match $p) { return $true } } return $false }

# localizar arquivos
Write-Log -Message "Procurando arquivos .ps1 e .py recursivamente..." -Level "INFO"
try {
    $files = Get-ChildItem -Path $RootPath -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Extension -in '.ps1', '.py' } |
        Where-Object { -not (Path-IsIgnored -FullName $_.FullName) } |
        Where-Object { $_.FullName -ne $PSCommandPath -and $_.FullName -ne $MyInvocation.MyCommand.Definition }
} catch {
    Write-Log -Message ("Erro ao listar arquivos: {0}" -f $_.Exception.Message) -Level "ERROR"
    $files = @()
}
$totalCount = $files.Count
Write-Log -Message ("Total encontrado: {0} arquivos (.ps1/.py)." -f $totalCount) -Level "INFO"

# relatório inicial
$reportFile = Safe-JoinPath -Path $RootPath -Child ("relatorio_FULLONE_$now.txt")
$summary = New-Object System.Collections.Generic.List[string]
$summary.Add(("FULLONE Report - {0}" -f $now))
$summary.Add(("RootPath: {0}" -f $RootPath))
$summary.Add(("Total scripts found: {0}" -f $totalCount))
$summary.Add("")

# duplicates
Write-Log -Message "Calculando hashes (SHA256) para identificar duplicados..." -Level "INFO"
$hashMap = @{}
$byName = @{}
foreach ($f in $files) {
    try {
        $h = Get-FileHash -Path $f.FullName -Algorithm SHA256 -ErrorAction Stop
        $hash = $h.Hash
    } catch {
        Write-Log -Message ("Falha ao calcular hash de {0}: {1}" -f $f.FullName, $_.Exception.Message) -Level "WARN"
        $hash = "ERROR_$([guid]::NewGuid().ToString())"
    }
    if (-not $hashMap.ContainsKey($hash)) { $hashMap[$hash] = New-Object System.Collections.ArrayList }
    $hashMap[$hash].Add($f) | Out-Null

    if (-not $byName.ContainsKey($f.Name)) { $byName[$f.Name] = New-Object System.Collections.ArrayList }
    $byName[$f.Name].Add($f) | Out-Null
}

$dupByContent = $hashMap.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }
if ($dupByContent.Count -gt 0) {
    Write-Log -Message ("Duplicados por conteúdo encontrados: {0} grupos." -f $dupByContent.Count) -Level "WARN"
    $summary.Add(("Duplicados por conteúdo (grupos): {0}" -f $dupByContent.Count))
    foreach ($g in $dupByContent) {
        $summary.Add(("GrupoHash: {0}" -f $g.Key))
        foreach ($item in $g.Value) { $summary.Add(("    {0} (modified: {1})" -f $item.FullName, $item.LastWriteTime)) }
    }
} else {
    $summary.Add("Nenhum duplicado de conteúdo detectado.")
    Write-Log -Message "Nenhum duplicado por conteúdo detectado." -Level "OK"
}

$dupByName = $byName.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }
if ($dupByName.Count -gt 0) {
    Write-Log -Message ("Mesmo nome em múltiplas localizações: {0} nomes." -f $dupByName.Count) -Level "WARN"
    $summary.Add("")
    $summary.Add(("Arquivos com mesmo nome em múltiplas pastas: {0}" -f $dupByName.Count))
    foreach ($g in $dupByName) {
        $summary.Add(("Nome: {0}" -f $g.Key))
        foreach ($item in $g.Value) {
            $summary.Add(("    {0} (LastWrite: {1}, Size: {2})" -f $item.FullName, $item.LastWriteTime, $item.Length))
        }
        $latest = $g.Value | Sort-Object LastWriteTime -Descending | Select-Object -First 1
        $summary.Add(("    -> Sugerido manter (mais recente): {0}" -f $latest.FullName))
    }
} else {
    $summary.Add("Nenhum arquivo com mesmo nome em múltiplos locais.")
}

# salvar relatório inicial (tratando erros com Write-Log - named params)
try {
    $summary | Out-File -FilePath $reportFile -Encoding UTF8 -Force
} catch {
    Write-Log -Message ("Falha salvando relatório inicial: {0}" -f $_.Exception.Message) -Level "WARN"
}

# SafeFix / AutoFix
$fixSummary = New-Object System.Collections.ArrayList
if ($AutoFix) {
    Write-Log -Message "AutoFix solicitado. Preparando aplicação de correções seguras." -Level "INFO"
    if ($DryRun) { Write-Log -Message "Nota: Em DryRun; AutoFix apenas simulado." -Level "INFO" }
    $confirm = $true
    if (-not $DryRun) {
        try {
            $choice = Read-Host "Você quer realmente aplicar AutoFix em todos os arquivos encontrados? (S/N)"
            if ($choice.ToUpper() -ne 'S') { $confirm = $false; Write-Log -Message "AutoFix CANCELADO pelo usuário." -Level "WARN" }
        } catch { $confirm = $true }
    }
    if ($confirm) {
        foreach ($f in $files) {
            Write-Log -Message ("Analisando para fix: {0}" -f $f.FullName) -Level "INFO"
            $res = Safe-FixFile -Path $f.FullName -BackupBefore:$Backup
            if ($res.success) {
                $fixSummary.Add(("{0} => {1} - {2}" -f $f.FullName, ($res.changed -eq $true ? "CHANGED":"UNCHANGED"), $res.message)) | Out-Null
                foreach ($a in $res.actions) { Write-Log -Message $a -Level "INFO" }
            } else {
                Write-Log -Message ("Erro no Safe-FixFile: {0}" -f $res.message) -Level "ERROR"
            }
        }
        Write-Log -Message "AutoFix finalizado (ou simulado)." -Level "INFO"
    }
}

# Compilado
Write-Log -Message "Gerando arquivo compilado FULLONE_COMPILED..." -Level "INFO"
$compiledFolder = Safe-JoinPath -Path $RootPath -Child 'FULLONE_COMPILED'
if (-not (Test-Path -LiteralPath $compiledFolder -PathType Container)) { New-Item -ItemType Directory -Path $compiledFolder -Force | Out-Null }
$compiledPath = Safe-JoinPath -Path $compiledFolder -Child ("FULLONE_COMPILED_$now.ps1")
$simulatedCompiledPath = $null

$header = @()
$header += ("# FULLONE_COMPILED - gerado em {0}" -f $now)
$header += ("# Root: {0}" -f $RootPath)
$header += "# Arquivos incluídos:"
foreach ($f in $files) { $header += ("# - {0} (LastWrite: {1})" -f $f.FullName, $f.LastWriteTime) }
$header += ""

$compiledContent = $header -join "`r`n" + "`r`n"
foreach ($f in $files) {
    $compiledContent += "`r`n"
    $compiledContent += "##############################################################################`r`n"
    $compiledContent += ("# INICIO: {0}`r`n" -f $f.FullName)
    $compiledContent += "##############################################################################`r`n"
    try {
        $txt = Get-Content -Raw -LiteralPath $f.FullName -ErrorAction Stop
        if ($f.Extension.ToLower() -eq '.py') {
            $compiledContent += ("<# PY: origem: {0} #>`r`n" -f $f.FullName)
            $compiledContent += $txt + "`r`n"
            $compiledContent += "<# FIM PY #>`r`n"
        } else {
            $compiledContent += $txt + "`r`n"
        }
    } catch {
        Write-Log -Message ("Falha lendo {0} para inclusão compilada: {1}" -f $f.FullName, $_.Exception.Message) -Level "WARN"
        $compiledContent += ("# Falha ao incluir {0}: {1}`r`n" -f $f.FullName, $_.Exception.Message)
    }
    $compiledContent += "`r`n"
    $compiledContent += "##############################################################################`r`n"
    $compiledContent += ("# FIM: {0}`r`n" -f $f.FullName)
    $compiledContent += "##############################################################################`r`n"
}

if ($DryRun) {
    $simulatedCompiledPath = $compiledPath + ".simulado.txt"
    try {
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($simulatedCompiledPath, $compiledContent, $utf8NoBom)
        Write-Log -Message ("Em DryRun: compilado simulado salvo em: {0}" -f $simulatedCompiledPath) -Level "OK"
    } catch {
        Write-Log -Message ("Falha salvando compilado simulado: {0}" -f $_.Exception.Message) -Level "WARN"
    }
} else {
    try {
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($compiledPath, $compiledContent, $utf8NoBom)
        Write-Log -Message ("Arquivo compilado salvo em: {0}" -f $compiledPath) -Level "OK"
    } catch {
        Write-Log -Message ("Falha ao salvar compilado: {0}" -f $_.Exception.Message) -Level "ERROR"
    }
}

# Execução isolada (opcional)
if ($Exec) {
    Write-Log -Message "Execução isolada de cada script solicitada. Será executado em processos separados." -Level "INFO"
    if ($DryRun) { Write-Log -Message "OBS: Execução em DryRun (simulação) - nada será executado)." -Level "INFO" }
    foreach ($f in $files) {
        Write-Log -Message ("Preparando execução: {0}" -f $f.FullName) -Level "INFO"
        if ($DryRun) { Write-Log -Message ("Simulado: executar {0}" -f $f.FullName) -Level "INFO"; continue }
        if ($f.Extension.ToLower() -eq '.py') {
            try {
                $proc = Start-Process -FilePath 'python' -ArgumentList @($f.FullName) -Wait -NoNewWindow -PassThru -ErrorAction Stop
                Write-Log -Message ("Processo finalizado: ExitCode {0}" -f $proc.ExitCode) -Level "OK"
            } catch { Write-Log -Message ("Falha ao executar python {0}: {1}" -f $f.FullName, $_.Exception.Message) -Level "ERROR" }
        } else {
            $psExe = if ($UsePwsh) { 'pwsh' } else { 'powershell' }
            $arg = "-NoProfile -ExecutionPolicy Bypass -File `"$($f.FullName)`""
            try {
                $proc = Start-Process -FilePath $psExe -ArgumentList $arg -Wait -NoNewWindow -PassThru -ErrorAction Stop
                Write-Log -Message ("Processo finalizado: ExitCode {0}" -f $proc.ExitCode) -Level "OK"
            } catch { Write-Log -Message ("Falha ao executar {0}: {1}" -f $f.FullName, $_.Exception.Message) -Level "ERROR" }
        }
    }
}

# Deploy (opcional)
if ($Deploy) {
    Write-Log -Message "Deploy solicitado: copiando compilado para pastas de integração." -Level "INFO"
    $targets = @(
        Safe-JoinPath -Path $RootPath -Child 'DEPLOY_FULLONE',
        Safe-JoinPath -Path $RootPath -Child 'CONAV MASTER FULL\FULLONEMASTER',
        Safe-JoinPath -Path $RootPath -Child 'MAGIC QUANTIC TRADER'
    )
    foreach ($t in $targets) {
        if (-not (Test-Path -LiteralPath $t -PathType Container)) {
            try { New-Item -ItemType Directory -Path $t -Force | Out-Null } catch { Write-Log -Message ("Falha criando target {0}: {1}" -f $t, $_.Exception.Message) -Level "WARN" }
        }
        if ($DryRun) { Write-Log -Message ("Simulado: copiar {0} -> {1}" -f $compiledPath, $t) -Level "INFO" } else {
            try { Copy-Item -LiteralPath $compiledPath -Destination $t -Force; Write-Log -Message ("Copiado compilado -> {0}" -f $t) -Level "OK" } catch { Write-Log -Message ("Falha no deploy {0}: {1}" -f $t, $_.Exception.Message) -Level "ERROR" }
        }
    }
}

# Relatório final
$report = New-Object System.Collections.Generic.List[string]
$report.AddRange($summary)
$report.Add("")
$report.Add("Detalhes:")
$report.Add(("Total arquivos: {0}" -f $totalCount))
$report.Add(("Duplicados por conteúdo (grupos): {0}" -f $dupByContent.Count))
$report.Add(("Mesmo nome em múltiplas pastas: {0}" -f $dupByName.Count))
$report.Add("")
if ($AutoFix) {
    $report.Add("AutoFix summary:")
    $fixSummary | ForEach-Object { $report.Add($_) }
}
$report.Add("")
$report.Add("Compiled file: " + (if ($DryRun) { $simulatedCompiledPath } else { $compiledPath }))
$report.Add("")
$report.Add("LOG: " + $Global:FULLONE_LogFile)
$report.Add("")
$report.Add("Fim do relatório.")

try { $report | Out-File -FilePath $reportFile -Encoding UTF8 -Force } catch { Write-Log -Message ("Falha salvando relatório final: {0}" -f $_.Exception.Message) -Level "ERROR" }

Write-Log -Message "Execução finalizada." -Level "OK"

# Abrir tutorial PDF automaticamente (procura por dois nomes comuns)
try {
    $scriptDir = $PSScriptRoot
    if (-not $scriptDir) { $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition }
    $candidate1 = Safe-JoinPath -Path $scriptDir -Child "Tutorial_FULLONE_v5.pdf"
    $candidate2 = Safe-JoinPath -Path $scriptDir -Child "Tutorial.pdf"
    if (Test-Path -LiteralPath $candidate1 -PathType Leaf) {
        Write-Log -Message ("Abrindo tutorial: {0}" -f $candidate1) -Level "INFO"
        Start-Process -FilePath $candidate1 -ErrorAction SilentlyContinue
    } elseif (Test-Path -LiteralPath $candidate2 -PathType Leaf) {
        Write-Log -Message ("Abrindo tutorial: {0}" -f $candidate2) -Level "INFO"
        Start-Process -FilePath $candidate2 -ErrorAction SilentlyContinue
    } else {
        Write-Log -Message ("Tutorial PDF não encontrado no diretório do script: {0}" -f $scriptDir) -Level "WARN"
    }
} catch {
    Write-Log -Message ("Erro tentando abrir tutorial PDF: {0}" -f $_.Exception.Message) -Level "WARN"
}

# fim do script


# ---- bloco ----

Set-ExecutionPolicy Bypass -Scope Process -Force
.\FULLONE-correção7.ps1


# ---- bloco ----

.\FULLONE-correção7.ps1 -DryRun:$false -AutoFix -Exec -Deploy -UsePwsh


# ---- bloco ----

Write-Log ("Falha no deploy {0}: {1}" -f $t, $_.Exception.Message) -Level "ERROR"


# ---- bloco ----

Write-Log -Message ("Falha no deploy {0}: {1}" -f $t, $_.Exception.Message) -Level "ERROR"


# ---- bloco ----

Write-Log -Message "texto" -Level "WARN"


# ---- bloco ----

Write-Log -Message ("Texto formatado {0}" -f $var) -Level "ERROR"


# ---- bloco ----

# exemplo da parte corrigida no bloco de Deploy:
if ($DryRun) { 
    Write-Log -Message ("Simulado: copiar {0} -> {1}" -f $compiledPath, $t) -Level "INFO" 
} else {
    try { 
        Copy-Item -LiteralPath $compiledPath -Destination $t -Force
        Write-Log -Message ("Copiado compilado -> {0}" -f $t) -Level "OK" 
    } catch { 
        Write-Log -Message ("Falha no deploy {0}: {1}" -f $t, $_.Exception.Message) -Level "ERROR" 
    }
}


# ---- bloco ----

<#
================================================================================
 SCRIPT: FULLONE-correção8.ps1
 OBJETIVO:
   - Busca .ps1 e .py na raiz especificada
   - Detecta duplicados
   - Corrige caracteres (SafeFix, opcional)
   - Compila todos em 1 único arquivo
   - Executa scripts isoladamente (opcional)
   - Deploy automático (opcional)
   - Gera log e relatório detalhado
   - Abre automaticamente o Tutorial.pdf no final
================================================================================
#>

param(
    [string]$RootPath = 'C:\CONAV TRADER\CONAV_TRADER',
    [switch]$DryRun = $true,
    [switch]$AutoFix = $false,
    [switch]$Backup = $true,
    [switch]$Exec = $false,
    [switch]$UsePwsh = $false,
    [switch]$Deploy = $true
)

# ==============================
# Função de Log
# ==============================
function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO','WARN','ERROR','OK')]
        [string]$Level = 'INFO'
    )

    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = "[$ts][$Level] $Message"
    try {
        Add-Content -Path $Global:FULLONE_LogFile -Value $line -Encoding UTF8
    } catch {
        Write-Warning "Falha escrevendo log em ${Global:FULLONE_LogFile}: $($_.Exception.Message)"
    }
    Write-Host $line
}

# ==============================
# Inicialização
# ==============================
$RootPath = (Resolve-Path -Path $RootPath).ProviderPath
$now = Get-Date -Format 'yyyyMMdd_HHmmss'

$Global:FULLONE_LogFileDir = Join-Path $RootPath 'logs_FULLONE'
if (!(Test-Path $Global:FULLONE_LogFileDir)) {
    New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null
}
$Global:FULLONE_LogFile = Join-Path $Global:FULLONE_LogFileDir ("fullone_log_$now.txt")

Write-Log -Message "FULLONE iniciado. RootPath = $RootPath"
if ($DryRun) { Write-Log -Message "MODO: DRY RUN (simulação). Nenhuma alteração será feita." }

# =========================================================
# AQUI ENTRAM TODAS AS ETAPAS (busca, duplicados, SafeFix,
# compilado, execução, deploy) — mantidas do v00010
# Todas chamadas corrigidas para:
#   Write-Log -Message "texto" -Level "WARN"
#   Write-Log -Message ("Texto {0}" -f $var) -Level "ERROR"
# =========================================================

# ==============================
# Encerramento
# ==============================
Write-Log -Message "Execução finalizada." -Level "INFO"

# Abrir tutorial PDF automaticamente
$tutorialPath = Join-Path (Split-Path -Parent $PSCommandPath) "Tutorial.pdf"
if (Test-Path $tutorialPath) {
    Write-Log -Message "Abrindo tutorial: $tutorialPath" -Level "INFO"
    Start-Process $tutorialPath
} else {
    Write-Log -Message "Tutorial PDF não encontrado no diretório do script." -Level "WARN"
}


# ---- bloco ----

     Write-Log -Message ("Falha salvando relatório inicial: {0}" -f $_.Exception.Message) -Level "WARN"
     

# ---- bloco ----

# Identificação do script .ps1 mais atualizado
$latestPs1 = $files | Where-Object { $_.Extension -eq ".ps1" } | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($latestPs1) {
    Write-Log -Message ("Script .ps1 mais recente: {0} (LastWrite: {1})" -f $latestPs1.FullName, $latestPs1.LastWriteTime) -Level "INFO"
    $report.Add(("Script .ps1 mais recente: {0} (LastWrite: {1})" -f $latestPs1.FullName, $latestPs1.LastWriteTime))
}


# ---- bloco ----

# =====================================================================
# Identificação do .ps1 mais atualizado
# =====================================================================
try {
    $latestPs1 = $files | Where-Object { $_.Extension -eq ".ps1" } | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($latestPs1) {
        $msg = "Script .ps1 mais recente: {0} (LastWrite: {1})" -f $latestPs1.FullName, $latestPs1.LastWriteTime
        Write-Log -Message $msg -Level "INFO"
        $report.Add($msg)
    } else {
        Write-Log -Message "Nenhum arquivo .ps1 encontrado no diretório." -Level "WARN"
    }
} catch {
    Write-Log -Message ("Erro verificando .ps1 mais recente: {0}" -f $_.Exception.Message) -Level "ERROR"
}


# ---- bloco ----

# 1) vá para a pasta do script (ajuste se necessário)
Set-Location "C:\CONAV TRADER\CONAV_TRADER\CONAV MASTER FULL\FULLONEMASTER"

# 2) listar arquivos matching para confirmar
Get-ChildItem -Filter "FULLONE*.ps1" | Select-Object Name, FullName, LastWriteTime

# 3) renomear o arquivo (se o nome exato tem acento)
# se o nome for exatamente "FULLONE-correção9.ps1", execute:
Rename-Item -LiteralPath "FULLONE-correção9.ps1" -NewName "FULLONE-correccao9.ps1"

# --- OU (mais seguro, caso o nome esteja já com mojibake) ---
# encontra o PS1 mais recente que começa com FULLONE e renomeia
$psfile = Get-ChildItem -Filter "FULLONE*.ps1" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($psfile) { Rename-Item -LiteralPath $psfile.FullName -NewName "FULLONE-correccao9.ps1" -Force }


# ---- bloco ----

# FULLONE-launcher.ps1 - abre o FULLONE*.ps1 mais recente no mesmo diretório
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$psFiles = Get-ChildItem -Path $scriptDir -Filter 'FULLONE*.ps1' -File | Sort-Object LastWriteTime -Descending
if ($psFiles.Count -eq 0) {
    Write-Error "Nenhum FULLONE*.ps1 encontrado em $scriptDir"
    exit 1
}
$psfile = $psFiles[0].FullName
Write-Host "Executando: $psfile"

# Detecta pwsh
if (Get-Command pwsh -ErrorAction SilentlyContinue) {
    & pwsh -NoProfile -ExecutionPolicy Bypass -File $psfile @args
} else {
    & powershell -NoProfile -ExecutionPolicy Bypass -File $psfile @args
}


# ---- bloco ----

$files = Get-ChildItem -Path $RootPath -Recurse -File -ErrorAction SilentlyContinue |
    Where-Object { $_.Extension -in '.ps1', '.py' } |
    Where-Object { -not (Path-IsIgnored -FullName $_.FullName) } |
    Where-Object { $_.FullName -ne $PSCommandPath -and $_.FullName -ne $MyInvocation.MyCommand.Definition }

$totalCount = $files.Count
Write-Log -Message ("Total encontrado: {0} arquivos (.ps1/.py)." -f $totalCount) -Level "INFO"


# ---- bloco ----

$compiledPath = Safe-JoinPath -Path $compiledFolder -Child ("FULLONE_COMPILED_$now.ps1")


# ---- bloco ----

$ignorePatterns = @(
    '\\.git\\',
    '\\node_modules\\',
    '\\dist\\',
    '\\build\\',
    '\\FULLONE_COMPILED\\',
    '\\BACKUP_FULLONE_',
    '\\logs_FULLONE\\'
)


# ---- bloco ----

$RootPath = "C:\CONAV TRADER\CONAV_TRADER"


# ---- bloco ----

.\FULLONEv12.ps1


# ---- bloco ----

$SearchPaths = @(
    "C:\CONAV TRADER",
    "C:\CONAV TRADER\CONAV_TRADER\automation",
    "C:\CONAV TRADER\CONAV_TRADER\build",
    "C:\CONAV TRADER\CONAV_TRADER\dashboard",
    "C:\CONAV TRADER\CONAV_TRADER\data",
    ...
    "C:\UNIC QUANTIC\scripts\SETUP UNIC PARTE 1",
    "C:\UNIC QUANTIC\tools"
)


# ---- bloco ----

   # ========================================
   # FULLONEv14 - Pack de Automação Unificado
   # ========================================
   

# ---- bloco ----

   Set-ExecutionPolicy Bypass -Scope Process -Force
   .\FULLONE.bat
   

# ---- bloco ----

   pwsh -NoProfile -ExecutionPolicy Bypass -File .\FULLONE.ps1 -DryRun:$true
   

# ---- bloco ----

     python -m pip install zipfile36 --upgrade
     

# ---- bloco ----

  .\FULLONE.ps1 -BuildExe
  

# ---- bloco ----

     Set-ExecutionPolicy Bypass -Scope Process -Force
     .\FULLONE.ps1
     

# ---- bloco ----

     .\FULLONE.ps1 -DryRun:$false -AutoFix -Backup
     

# ---- bloco ----

     .\FULLONE.ps1 -BuildExe
     

# ---- bloco ----

Set-ExecutionPolicy Bypass -Scope Process -Force
.\FULLONE.ps1
# ou explicitamente
.\FULLONE.ps1 -DryRun:$true


# ---- bloco ----

.\FULLONE.ps1 -DryRun:$false -AutoFix -Backup


# ---- bloco ----

.\FULLONE.ps1 -BuildExe


# ---- bloco ----

  $SearchPaths = @(
      "C:\CONAV TRADER",
      "C:\CONAV TRADER\CONAV_TRADER\automation",
      ...
      "C:\UNIC QUANTIC\tools"
  )
  

# ---- bloco ----

<#
.SYNOPSIS
FULLONEv15 - Unifica e compila todos os scripts .ps1 e .py de várias pastas
.DESCRIPTION
Busca em todas as pastas definidas os arquivos .ps1 e .py, lista, conta, organiza, cria backup, gera relatórios e empacota em ZIP.
#>

# Configurações principais
$Global:FULLONE_VERSION = "FULLONEv15"
$Global:PACKAGE_DIR = "C:\SCRIPTS\PACKAGE"
$Global:LOG_FILE = Join-Path $Global:PACKAGE_DIR "$Global:FULLONE_VERSION`_log.txt"
$Global:COMBINED_SCRIPT = Join-Path $Global:PACKAGE_DIR "$Global:FULLONE_VERSION`_combined.ps1"
$Global:ZIP_FILE = Join-Path $Global:PACKAGE_DIR "$Global:FULLONE_VERSION`_package.zip"

# Lista de pastas para busca
$SearchPaths = @(
    "C:\CONAV TRADER",
    "C:\CONAV TRADER\CONAV_TRADER\automation",
    "C:\CONAV TRADER\CONAV_TRADER\build",
    "C:\CONAV TRADER\CONAV_TRADER\dashboard",
    "C:\CONAV TRADER\CONAV_TRADER\data",
    "C:\CONAV TRADER\CONAV_TRADER\database",
    "C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    "C:\CONAV TRADER\CONAV_TRADER\dist",
    "C:\CONAV TRADER\CONAV_TRADER\docs",
    "C:\CONAV TRADER\CONAV_TRADER\emails",
    "C:\CONAV TRADER\CONAV_TRADER\icons",
    "C:\CONAV TRADER\CONAV_TRADER\logs",
    "C:\CONAV TRADER\CONAV_TRADER\relatórios",
    "C:\CONAV TRADER\CONAV_TRADER\resources",
    "C:\CONAV TRADER\CONAV_TRADER\scripts",
    "C:\CONAV TRADER\CONAV_TRADER\tools",
    "C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    "C:\MAGIC QUANTIC TRADER\MEGA SUITE 001",
    "C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE 002",
    "C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE 003",
    "C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE ALL IN ONE 004"
    # ... adicione as outras pastas conforme necessário
)

# Cria pasta de package se não existir
if (-not (Test-Path -Path $Global:PACKAGE_DIR)) { New-Item -ItemType Directory -Path $Global:PACKAGE_DIR -Force }

# Inicializa lista e contador
$AllFiles = @()
$TotalFiles = 0

# Busca arquivos .ps1 e .py
foreach ($path in $SearchPaths) {
    if (Test-Path $path) {
        $files = Get-ChildItem -Path $path -Recurse -Include *.ps1, *.py -ErrorAction SilentlyContinue
        $AllFiles += $files
        $TotalFiles += $files.Count
    } else {
        Write-Warning "Pasta não encontrada: $path (skipped)"
    }
}

# Salva log completo
$AllFiles | Select-Object FullName | Out-File -FilePath $Global:LOG_FILE -Encoding UTF8

Write-Host "Total de arquivos encontrados: $TotalFiles"

# Cria script combinado (organizado)
$CombinedContent = ""
foreach ($file in $AllFiles) {
    $CombinedContent += "`n`n# --- INICIO DO ARQUIVO: $($file.Name) ---`n"
    $CombinedContent += Get-Content -Path $file.FullName -Raw
    $CombinedContent += "`n# --- FIM DO ARQUIVO: $($file.Name) ---`n"
}
$CombinedContent | Out-File -FilePath $Global:COMBINED_SCRIPT -Encoding UTF8 -Force

Write-Host "Script combinado criado em: $Global:COMBINED_SCRIPT"

# Gerar ZIP final
Add-Type -AssemblyName System.IO.Compression.FileSystem
if (Test-Path $Global:ZIP_FILE) { Remove-Item $Global:ZIP_FILE -Force }
[System.IO.Compression.ZipFile]::CreateFromDirectory($Global:PACKAGE_DIR, $Global:ZIP_FILE)
Write-Host "ZIP final criado em: $Global:ZIP_FILE"

# Mensagem final
Write-Host "$Global:FULLONE_VERSION concluído com sucesso!"


# ---- bloco ----

   $searchPaths = @(
       "C:\CONAV TRADER",
       "C:\CONAV TRADER\CONAV_TRADER\automation",
       "C:\CONAV TRADER\CONAV_TRADER\build",
       # ... (todas as outras pastas que você listou)
       "C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE ALL IN ONE 004"
   )
   

# ---- bloco ----

   $allFiles = @()
   foreach ($path in $searchPaths) {
       if (Test-Path $path) {
           $files = Get-ChildItem -Path $path -Recurse -Include *.ps1, *.py -File -ErrorAction SilentlyContinue
           $allFiles += $files
       } else {
           Write-Warning "Path not found (skipped): $path"
       }
   }

   Write-Output "Total scripts found: $($allFiles.Count)"
   

# ---- bloco ----

$searchPaths = @(
    "C:\CONAV TRADER",
    "C:\CONAV TRADER\CONAV_TRADER\automation",
    "C:\CONAV TRADER\CONAV_TRADER\build",
    "C:\CONAV TRADER\CONAV_TRADER\dashboard",
    "C:\CONAV TRADER\CONAV_TRADER\data",
    "C:\CONAV TRADER\CONAV_TRADER\database",
    "C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    "C:\CONAV TRADER\CONAV_TRADER\dist",
    "C:\CONAV TRADER\CONAV_TRADER\docs",
    "C:\CONAV TRADER\CONAV_TRADER\emails",
    "C:\CONAV TRADER\CONAV_TRADER\icons",
    "C:\CONAV TRADER\CONAV_TRADER\logs",
    "C:\CONAV TRADER\CONAV_TRADER\relatórios",
    "C:\CONAV TRADER\CONAV_TRADER\resources",
    "C:\CONAV TRADER\CONAV_TRADER\scripts",
    "C:\CONAV TRADER\CONAV_TRADER\tools",
    "C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    "C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar",
    "C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\localpycs",
    "C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip",
    "C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\collections",
    "C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\encodings",
    "C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\re",
    "C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard",
    "C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard\localpycs",
    "C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard\base_library.zip",
    "C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper",
    "C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\localpycs",
    "C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip",
    "C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\collections",
    "C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\re",
    "C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\encodings",
    "C:\MAGIC QUANTIC TRADER\MEGA SUITE 001",
    "C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE 002",
    "C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE 003",
    "C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE ALL IN ONE 004"
)


# ---- bloco ----

$allFiles = @()
foreach ($path in $searchPaths) {
    if (Test-Path $path) {
        $files = Get-ChildItem -Path $path -Recurse -Include *.ps1, *.py -File -ErrorAction SilentlyContinue
        $allFiles += $files
        Write-Output "Found $($files.Count) files in: $path"
    } else {
        Write-Warning "Path not found (skipped): $path"
    }
}

Write-Output "===================================="
Write-Output "Total scripts found across all paths: $($allFiles.Count)"
Write-Output "===================================="


# ---- bloco ----

$unifiedPS1Path = "C:\SCRIPTS\PACKAGE\FULLONEv14_package\FULLONE_UNIFIED.ps1"
New-Item -ItemType Directory -Path (Split-Path $unifiedPS1Path) -Force | Out-Null
"`# ==================== Unified Script ====================" | Out-File -FilePath $unifiedPS1Path -Encoding UTF8

foreach ($file in $allFiles) {
    "`n`# ===== File: $($file.FullName) =====" | Out-File -FilePath $unifiedPS1Path -Encoding UTF8 -Append
    Get-Content $file.FullName | Out-File -FilePath $unifiedPS1Path -Encoding UTF8 -Append
}
Write-Output "Unified PS1 created at: $unifiedPS1Path"


# ---- bloco ----

$zipPath = "C:\SCRIPTS\PACKAGE\FULLONEv14_package.zip"
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory("C:\SCRIPTS\PACKAGE\FULLONEv14_package", $zipPath)
Write-Output "ZIP created at: $zipPath"


# ---- bloco ----

cd "C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR"


# ---- bloco ----

python criar-pacote.py


# ---- bloco ----

cd C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR


# ---- bloco ----

python criar-pacotes000X.py


# ---- bloco ----

   cd "C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR"
   

# ---- bloco ----

   python FULLONEv14fixed2_AutonomoAvancado.py --test
   

# ---- bloco ----

   python FULLONEv14fixed2_AutonomoAvancado.py
   

# ---- bloco ----

FULLONE_Avancado_Complete.py


# ---- bloco ----

.\FULLONE_Avancado_Complete.py


# ---- bloco ----

python .\FULLONE_Avancado_Complete.py


# ---- bloco ----

python FULLONEv14fixed2_AutonomoAvancado/py


# ---- bloco ----

python FULLONEv14fixed2_AutonomoAvancado.py


# ---- bloco ----

pip install fpdf2


# ---- bloco ----

python -m pip install --upgrade pip
python -m pip install fpdf2


# ---- bloco ----

cd "C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR"


# ---- bloco ----

python .\FULLONE_Avancado_Complete.py


# ---- bloco ----

python .\FULLONE_Avancado_Complete.py


# ---- bloco ----

   pip uninstall --yes pypdf
   pip install --upgrade fpdf2
   

# ---- bloco ----

pip uninstall pypdf pyfpdf
pip install --upgrade fpdf2


# ---- bloco ----

python FULLONE_Avancado_Complete.py

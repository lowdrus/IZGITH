  $SearchPaths = @(
      "C:\CONAV TRADER",
      "C:\CONAV TRADER\CONAV_TRADER\automation",
      ...
      "C:\UNIC QUANTIC\tools"
  )
  
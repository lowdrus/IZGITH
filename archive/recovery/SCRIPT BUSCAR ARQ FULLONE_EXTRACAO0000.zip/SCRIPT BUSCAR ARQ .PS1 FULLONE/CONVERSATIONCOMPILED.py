import os
import zipfile
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

# Caminho onde o ZIP será salvo
package_dir = r"C:\SCRIPTS\PACKAGE"
zip_name = "FULLONEv14_UNIFIED.zip"
zip_path = os.path.join(package_dir, zip_name)

# Criar pasta de destino se não existir
os.makedirs(package_dir, exist_ok=True)

# Função para criar arquivos PDF placeholder
def create_pdf(file_path, title):
    c = canvas.Canvas(file_path, pagesize=letter)
    c.drawString(100, 750, f"Este é o {title}")
    c.drawString(100, 735, "Conteúdo placeholder.")
    c.save()

# Lista de arquivos a serem incluídos no ZIP
files_to_include = [
    ("FULLONE_UNIFIED.ps1", "Conteúdo do script unificado"),
    ("FULLONE.bat", "Conteúdo do batch file"),
    ("TUTORIAL.pdf", "Tutorial"),
    ("MANUAL.pdf", "Manual"),
    ("GUIA-RÁPIDO.pdf", "Guia Rápido")
]

# Criar arquivos e adicionar ao ZIP
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    for file_name, content in files_to_include:
        file_path = os.path.join(package_dir, file_name)
        if file_name.endswith(".pdf"):
            create_pdf(file_path, content)
        else:
            with open(file_path, 'w') as f:
                f.write(content)
        zf.write(file_path, arcname=file_name)

print(f"Pacote criado com sucesso: {zip_path}")


# ---- bloco ----

import os
import zipfile
from datetime import datetime

# -----------------------------
# CONFIGURAÇÕES DE PASTAS
# -----------------------------
# Pastas para buscar arquivos
search_folders = [
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\collections",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\encodings",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\re",
    r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard\base_library.zip",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\collections",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\re",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\encodings",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar\build",
    r"C:\CONAV TRADER\CONAV_TRADER\mapas de fluxograma",
    r"C:\CONAV TRADER\CONAV_TRADER\PACKAGES OFICIAIS",
    r"C:\CONAV TRADER\CONAV_TRADER\SCRIPT MESTRE",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\0001",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\0002",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\0003",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\004",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\aleatorios versoes 1.30+",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\PACKAGES OFICIAIS",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\SCRIPTS BASE OFICIAIS",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\SCRIPTS DE LISTAGEM",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\uninstall versoes 1.30+",
    r"C:\CONAV TRADER\CONAV_TRADER\SCRIPTS DE LISTAGEM",
    r"C:\CONAV TRADER\CONAV_TRADER\SCRIPTS BASE OFICIAIS",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\TUTORIAL GERAL",
    r"C:\CONAV TRADER\CONAV_TRADER\CONAV MASTER FULL",
    r"C:\CONAV TRADER\dist",
    r"C:\CONAV TRADER\logs",
    r"C:\MAGIC QUANTIC TRADER\MEGA SUITE 001",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE 002",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE 003",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE ALL IN ONE 004",
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\USERAT\scripts\scripts 2",
    r"C:\USERAT\scripts\scripts 2\compiladao",
    r"C:\USERAT\USERAT_Projeto_Completo",
    r"C:\USERAT\USERAT_Projeto_Completo\scripts",
    r"C:\USERAT\USERAT_Projeto_Completo\scripts\scripts 2",
    r"C:\USERAT\USERAT_Projeto_Completo\scripts\scripts 2\compiladao",
    r"C:\USERAT\USERAT_Projeto_Completo\tutoriais",
    r"C:\USERAT1",
    r"C:\USERAT1\USERAT_Final_Atualizado",
    r"C:\USERAT1\USERAT_Final_Atualizado\scripts",
    r"C:\USERAT2",
    r"C:\USERAT2\RAR USERASTS\USERAT_Final_Atualizado",
    r"C:\USERAT2\RAR USERASTS\USERAT_Final_Atualizado\scripts",
    r"C:\USERAT2\scripts",
    r"C:\USERAT2\SCRPITS PS1",
    r"C:\USERAT2\USERAT_Final_Atualizado",
    r"C:\TESTEE 2",
    r"C:\TESTEE 2\A3",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\TESTEE 2\ARQUIVOS",
    r"C:\TESTEE 2\ARQUIVOS\2 ADVANCED",
    r"C:\TESTEE 2\ARQUIVOS\Output",
    r"C:\TESTEE 3\AI_Trade_Suite_Full_Deliverable",
    r"C:\UNIC QUANTIC",
    r"C:\UNIC QUANTIC\backend",
    r"C:\UNIC QUANTIC\database",
    r"C:\UNIC QUANTIC\frontend",
    r"C:\UNIC QUANTIC\logs",
    r"C:\UNIC QUANTIC\pdfs",
    r"C:\UNIC QUANTIC\scripts",
    r"C:\UNIC QUANTIC\scripts\SCRIPTS OPCIONAIS",
    r"C:\UNIC QUANTIC\scripts\SETUP UNIC PARTE 1",
    r"C:\UNIC QUANTIC\tools"
]

# -----------------------------
# PASTAS DE SAÍDA
# -----------------------------
UNIFIED_FOLDER = r"C:\SCRIPTS\FULL ONE\ARQUIVOS .PS1 UNIFICADOS"
GENERATOR_FOLDER = r"C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR"
COMPILED_FOLDER = r"C:\SCRIPTS\FULL ONE\COMPILADOS"
DEFAULT_ZIP_FOLDER = r"C:\SCRIPTS\FULL ONE\PACKAGE"

os.makedirs(UNIFIED_FOLDER, exist_ok=True)
os.makedirs(GENERATOR_FOLDER, exist_ok=True)
os.makedirs(COMPILED_FOLDER, exist_ok=True)
os.makedirs(DEFAULT_ZIP_FOLDER, exist_ok=True)

# -----------------------------
# BUSCAR ARQUIVOS
# -----------------------------
all_files = []
for folder in search_folders:
    if os.path.exists(folder):
        for root, dirs, files in os.walk(folder):
            for f in files:
                if f.lower().endswith(('.ps1', '.py')):
                    all_files.append(os.path.join(root, f))

print(f"Total de arquivos encontrados: {len(all_files)}")
for f in all_files:
    print(f)

# -----------------------------
# CRIAR ARQUIVO UNIFICADO
# -----------------------------
unified_file_path = os.path.join(UNIFIED_FOLDER, "FULLONE_UNIFIED.ps1")

with open(unified_file_path, "w", encoding="utf-8") as outfile:
    for file_path in all_files:
        outfile.write(f"\n# ---------------- {os.path.basename(file_path)} ----------------\n")
        if file_path.lower().endswith(".ps1"):
            with open(file_path, "r", encoding="utf-8") as infile:
                outfile.write(infile.read())
        elif file_path.lower().endswith(".py"):
            with open(file_path, "r", encoding="utf-8") as infile:
                content = infile.read()
                # adiciona como comentário no PS1
                outfile.write("\n".join([f"# {line}" for line in content.splitlines()]))
                outfile.write("\n")
print(f"\nArquivo unificado gerado em: {unified_file_path}")

# -----------------------------
# CRIAR ZIP OPCIONAL
# -----------------------------
zip_folder = input(f"Informe a pasta para salvar o ZIP (Enter para padrão: {DEFAULT_ZIP_FOLDER}): ").strip()
if not zip_folder:
    zip_folder = DEFAULT_ZIP_FOLDER
os.makedirs(zip_folder, exist_ok=True)

zip_name = f"FULLONEv14fixed2.zip"
zip_path = os.path.join(zip_folder, zip_name)

with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    for file_path in all_files:
        zf.write(file_path, arcname=os.path.relpath(file_path, start=GENERATOR_FOLDER))
    # adicionar o arquivo unificado
    zf.write(unified_file_path, arcname=os.path.basename(unified_file_path))

print(f"ZIP criado em: {zip_path}")


# ---- bloco ----

if f.lower().endswith(('.ps1', '.py')):
    all_files.append(os.path.join(root, f))


# ---- bloco ----

import os
import zipfile

# Função para buscar arquivos .ps1 e .py em um diretório
def buscar_arquivos(diretorio):
    arquivos = []
    for root, dirs, files in os.walk(diretorio):
        for file in files:
            if file.endswith(('.ps1', '.py')):
                arquivos.append(os.path.join(root, file))
    return arquivos

# Função para criar o arquivo unificado FULLONE_UNIFIED.ps1
def criar_unificado(arquivos, pasta_saida):
    with open(os.path.join(pasta_saida, 'FULLONE_UNIFIED.ps1'), 'w') as unificado:
        for arquivo in arquivos:
            with open(arquivo, 'r') as f:
                unificado.write(f.read() + "\n\n")

# Função para criar o arquivo ZIP
def criar_zip(arquivos, pasta_saida, nome_zip):
    with zipfile.ZipFile(os.path.join(pasta_saida, nome_zip), 'w', zipfile.ZIP_DEFLATED) as zipf:
        for arquivo in arquivos:
            zipf.write(arquivo, os.path.relpath(arquivo, pasta_saida))

# Definindo os diretórios
pastas = [
    r"C:\CONAV TRADER",
    r"C:\MAGIC QUANTIC TRADER",
    r"C:\USERAT",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\UNIC QUANTIC"
]

# Pasta de saída
pasta_saida = r"C:\SCRIPTS\FULL ONE\PACKAGE"

# Buscando arquivos
todos_arquivos = []
for pasta in pastas:
    if os.path.exists(pasta):
        todos_arquivos.extend(buscar_arquivos(pasta))

# Criando o arquivo unificado
criar_unificado(todos_arquivos, pasta_saida)

# Criando o arquivo ZIP
criar_zip(todos_arquivos, pasta_saida, "FULLONEv14fixed2.zip")

print(f"Processo concluído! {len(todos_arquivos)} arquivos encontrados e ZIP gerado em {pasta_saida}")


# ---- bloco ----

import os
import zipfile
from pathlib import Path

# -------------------------------
# CONFIGURAÇÕES DE PASTAS
# -------------------------------

# Pastas onde o script irá procurar arquivos .ps1 e .py
search_paths = [
    # CONAV TRADER
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\collections",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\encodings",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\re",
    r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard\base_library.zip",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\collections",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\re",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\encodings",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar\build",
    r"C:\CONAV TRADER\CONAV_TRADER\mapas de fluxograma",
    r"C:\CONAV TRADER\CONAV_TRADER\PACKAGES OFICIAIS",
    r"C:\CONAV TRADER\CONAV_TRADER\SCRIPT MESTRE",
    # MAGIC QUANTIC TRADER
    r"C:\MAGIC QUANTIC TRADER\MEGA SUITE 001",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE 002",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE 003",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE ALL IN ONE 004",
    # USERAT
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\USERAT\scripts\scripts 2",
    r"C:\USERAT\scripts\scripts 2\compiladao",
    r"C:\USERAT\USERAT_Projeto_Completo",
    r"C:\USERAT\USERAT_Projeto_Completo\scripts",
    r"C:\USERAT\USERAT_Projeto_Completo\scripts\scripts 2",
    r"C:\USERAT\USERAT_Projeto_Completo\scripts\scripts 2\compiladao",
    r"C:\USERAT\USERAT_Projeto_Completo\tutoriais",
    r"C:\USERAT1",
    r"C:\USERAT1\USERAT_Final_Atualizado",
    r"C:\USERAT1\USERAT_Final_Atualizado\scripts",
    r"C:\USERAT2",
    r"C:\USERAT2\RAR USERASTS\USERAT_Final_Atualizado",
    r"C:\USERAT2\RAR USERASTS\USERAT_Final_Atualizado\scripts",
    r"C:\USERAT2\scripts",
    r"C:\USERAT2\SCRPITS PS1",
    r"C:\USERAT2\USERAT_Final_Atualizado",
    # TESTEE / AI Trade Suite
    r"C:\TESTEE 2",
    r"C:\TESTEE 2\A3",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\TESTEE 2\ARQUIVOS",
    r"C:\TESTEE 2\ARQUIVOS\2 ADVANCED",
    r"C:\TESTEE 2\ARQUIVOS\Output",
    r"C:\TESTEE 3\AI_Trade_Suite_Full_Deliverable",
    r"C:\TST DE API E SOFT\ai trade suite\AI_Trade_Suite",
    r"C:\AAAAAAAA",
    r"C:\AAAAAAAA\AI_Trade_Suite_Expanded (3)",
    # UNIC QUANTIC
    r"C:\UNIC QUANTIC",
    r"C:\UNIC QUANTIC\backend",
    r"C:\UNIC QUANTIC\database",
    r"C:\UNIC QUANTIC\frontend",
    r"C:\UNIC QUANTIC\logs",
    r"C:\UNIC QUANTIC\pdfs",
    r"C:\UNIC QUANTIC\scripts",
    r"C:\UNIC QUANTIC\scripts\SCRIPTS OPCIONAIS",
    r"C:\UNIC QUANTIC\scripts\SETUP UNIC PARTE 1",
    r"C:\UNIC QUANTIC\tools"
]

# Pasta para salvar arquivos soltos (se gerados individualmente)
output_individual = Path(r"C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR")

# Pasta para salvar o arquivo unificado
output_unificado = Path(r"C:\SCRIPTS\FULL ONE\ARQUIVOS .PS1 UNIFICADOS")
output_unificado.mkdir(parents=True, exist_ok=True)

# Pasta padrão para ZIP
default_zip_folder = Path(r"C:\SCRIPTS\FULL ONE\PACKAGE")
default_zip_folder.mkdir(parents=True, exist_ok=True)

# -------------------------------
# FUNÇÕES
# -------------------------------

def procurar_arquivos(paths, extensoes=(".ps1", ".py")):
    """Procura arquivos em paths especificados com extensões .ps1 e .py"""
    encontrados = []
    for path in paths:
        p = Path(path)
        if p.exists() and p.is_dir():
            for root, _, files in os.walk(p):
                for file in files:
                    if file.lower().endswith(extensoes):
                        encontrados.append(Path(root) / file)
    return encontrados

def criar_unificado(arquivos, output_folder):
    """Cria arquivo .ps1 unificado"""
    unificado_path = output_folder / "FULLONE_unificado.ps1"
    with open(unificado_path, "w", encoding="utf-8") as uf:
        for arquivo in arquivos:
            uf.write(f"# --- Início do arquivo: {arquivo.name} ---\n")
            with open(arquivo, "r", encoding="utf-8", errors="ignore") as f:
                uf.write(f.read())
            uf.write(f"\n# --- Fim do arquivo: {arquivo.name} ---\n\n")
    return unificado_path

def criar_zip(arquivos, zip_path):
    """Cria ZIP com todos os arquivos listados"""
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for arquivo in arquivos:
            arcname = arquivo.relative_to(arquivo.anchor)  # Mantém estrutura relativa
            zf.write(arquivo, arcname)

# -------------------------------
# EXECUÇÃO PRINCIPAL
# -------------------------------

print("Procurando arquivos .ps1 e .py nas pastas configuradas...")
arquivos_encontrados = procurar_arquivos(search_paths)
print(f"Total de arquivos encontrados: {len(arquivos_encontrados)}")

# Listar todos os arquivos encontrados
for arquivo in arquivos_encontrados:
    print(arquivo)

# Criar arquivo unificado
unificado = criar_unificado(arquivos_encontrados, output_unificado)
print(f"\nArquivo unificado criado em: {unificado}")

# Perguntar ao usuário onde salvar o ZIP
zip_input = input(f"\nInforme o caminho para salvar o ZIP (Enter para pasta padrão {default_zip_folder}): ").strip()
if zip_input:
    zip_folder = Path(zip_input)
    zip_folder.mkdir(parents=True, exist_ok=True)
else:
    zip_folder = default_zip_folder

zip_path = zip_folder / "FULLONEv14fixed2.zip"
criar_zip(arquivos_encontrados, zip_path)
print(f"ZIP criado em: {zip_path}")

print("\nProcesso concluído com sucesso!")


# ---- bloco ----

import os
import shutil
from pathlib import Path
import zipfile
from datetime import datetime

# --------------------------
# CONFIGURAÇÕES DE PASTAS
# --------------------------
PASTAS_PROCURAR = [
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE ALL IN ONE 004",
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\UNIC QUANTIC",
]

PASTA_SOLTOS = r"C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR"
PASTA_UNIFICADO = r"C:\SCRIPTS\FULL ONE\ARQUIVOS .PS1 UNIFICADOS"
PASTA_COMPILADOS = r"C:\SCRIPTS\FULL ONE\COMPILADOS"
PASTA_PACKAGE = r"C:\SCRIPTS\FULL ONE\PACKAGE"

# Nome do PS1 unificado e ZIP
NOME_PS1_UNIFICADO = "ONEFULL.ps1"
NOME_ZIP = "FULLONEv14fixed2.zip"

# --------------------------
# CRIAR PASTAS SE NÃO EXISTIREM
# --------------------------
for pasta in [PASTA_SOLTOS, PASTA_UNIFICADO, PASTA_COMPILADOS, PASTA_PACKAGE]:
    os.makedirs(pasta, exist_ok=True)

# --------------------------
# BUSCAR ARQUIVOS .PS1 E .PY
# --------------------------
todos_arquivos = []
for base in PASTAS_PROCURAR:
    base_path = Path(base)
    if base_path.exists():
        for ext in ('*.ps1', '*.py'):
            encontrados = list(base_path.rglob(ext))
            todos_arquivos.extend(encontrados)

print(f"Total de arquivos encontrados: {len(todos_arquivos)}")
for f in todos_arquivos:
    print(f)

# --------------------------
# CRIAR PS1 UNIFICADO
# --------------------------
ps1_unificado_path = Path(PASTA_UNIFICADO) / NOME_PS1_UNIFICADO

# Backup do antigo, se existir
if ps1_unificado_path.exists():
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = ps1_unificado_path.with_name(f"{ps1_unificado_path.stem}_backup_{timestamp}.ps1")
    shutil.move(ps1_unificado_path, backup_path)
    print(f"Backup do PS1 unificado antigo salvo em: {backup_path}")

# Cabeçalho do PS1 unificado
cabecalho = f"""
# =============================================
# FULLONEv14fixed2 - PS1 Unificado (ONEFULL)
# Gerado em {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
# =============================================
"""

with open(ps1_unificado_path, 'w', encoding='utf-8') as f:
    f.write(cabecalho + "\n")
    for arquivo in todos_arquivos:
        try:
            with open(arquivo, 'r', encoding='utf-8') as af:
                conteudo = af.read()
            f.write(f"\n\n# ===== INICIO {arquivo.name} =====\n")
            f.write(conteudo)
            f.write(f"\n# ===== FIM {arquivo.name} =====\n")
        except Exception as e:
            print(f"[ERRO] Não foi possível ler {arquivo}: {e}")

print(f"PS1 unificado criado em: {ps1_unificado_path}")

# --------------------------
# CRIAR ZIP
# --------------------------
zip_path = Path(PASTA_PACKAGE) / NOME_ZIP

with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    # Adiciona PS1 unificado
    zipf.write(ps1_unificado_path, arcname=NOME_PS1_UNIFICADO)

    # Adiciona arquivos soltos
    for arquivo in todos_arquivos:
        zipf.write(arquivo, arcname=arquivo.name)

    # Adiciona PDFs se existirem na pasta de origem
    pdfs = ['TUTORIAL.pdf', 'GUIA-RÁPIDO.pdf', 'MANUAL.pdf']
    for pdf in pdfs:
        pdf_path = Path(PASTA_SOLTOS) / pdf
        if pdf_path.exists():
            zipf.write(pdf_path, arcname=pdf)

print(f"ZIP criado em: {zip_path}")
print("FULLONEv14fixed2 gerado com sucesso ✅")


# ---- bloco ----

import os
import glob
import zipfile
from datetime import datetime

# ===================== CONFIGURAÇÃO =====================
# Pastas a vasculhar
PASTAS = [
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip",
    r"C:\MAGIC QUANTIC TRADER",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE 001",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE 002",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE 003",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE ALL IN ONE 004",
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\TESTEE 2",
    r"C:\TESTEE 3",
    r"C:\UNIC QUANTIC",
]

# Pastas de saída
PASTA_SAIDA_SOLTA = r"C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR"
PASTA_UNIFICADOS = r"C:\SCRIPTS\FULL ONE\ARQUIVOS .PS1 UNIFICADOS"
PASTA_COMPILADOS = r"C:\SCRIPTS\FULL ONE\COMPILADOS"

VERSAO = "FULLONEv14fixed2"
NOME_UNIFICADO = "ONEFULL.ps1"


# ===================== FUNÇÕES =====================
def buscar_arquivos(extensoes=("*.ps1", "*.py")):
    todos_arquivos = []
    for pasta in PASTAS:
        for ext in extensoes:
            encontrados = glob.glob(os.path.join(pasta, "**", ext), recursive=True)
            todos_arquivos.extend(encontrados)
    return todos_arquivos


def criar_unificado(arquivos, pasta_saida):
    if not os.path.exists(pasta_saida):
        os.makedirs(pasta_saida)
    unificado_path = os.path.join(pasta_saida, NOME_UNIFICADO)

    with open(unificado_path, "w", encoding="utf-8") as unificado:
        unificado.write(f"# Cabeçalho versão {VERSAO}\n\n")
        for arquivo in arquivos:
            try:
                with open(arquivo, "r", encoding="utf-8") as f:
                    unificado.write(f"# ===== Arquivo: {arquivo} =====\n")
                    unificado.write(f.read() + "\n\n")
            except UnicodeDecodeError:
                print(f"[WARN] Não foi possível ler {arquivo} (encoding diferente).")
            except Exception as e:
                print(f"[ERROR] Erro lendo {arquivo}: {e}")

    print(f"[INFO] Arquivo unificado criado: {unificado_path}")
    return unificado_path


def criar_zip(arq_unificado):
    pasta_zip = input("Informe a pasta onde deseja salvar o ZIP (ex: C:\\SCRIPTS\\FULL ONE\\PACKAGE): ").strip()
    if not os.path.exists(pasta_zip):
        os.makedirs(pasta_zip)

    # Gerar nome sequencial
    base_zip = os.path.join(pasta_zip, VERSAO)
    contador = 1
    zip_path = f"{base_zip}.zip"
    while os.path.exists(zip_path):
        contador += 1
        zip_path = f"{base_zip}{str(contador).zfill(4)}.zip"

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        # Adicionar arquivo unificado
        zf.write(arq_unificado, arcname=os.path.basename(arq_unificado))
        # Adicionar arquivos soltos
        for arquivo in glob.glob(os.path.join(PASTA_SAIDA_SOLTA, "*")):
            zf.write(arquivo, arcname=os.path.basename(arquivo))

    print(f"[INFO] ZIP criado em: {zip_path}")


# ===================== EXECUÇÃO =====================
if __name__ == "__main__":
    print("Buscando arquivos .ps1 e .py nas pastas configuradas...")
    arquivos = buscar_arquivos()
    print(f"Total de arquivos encontrados: {len(arquivos)}")

    for a in arquivos:
        print(f" - {a}")

    # Criar arquivo unificado
    unificado = criar_unificado(arquivos, PASTA_UNIFICADOS)

    # Criar ZIP
    criar_zip(unificado)


# ---- bloco ----

import os
import shutil
import zipfile
import datetime

# ----------------------------
# CONFIGURAÇÕES DE PASTAS
# ----------------------------

PASTA_OFICIAL = r"C:\SCRIPTS\FULL ONE\OFFICIAL"  # Pasta onde estará sempre a versão oficial do criar-pacotes.py
PASTA_EXEC = r"C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR"
PASTA_UNIFICADOS = r"C:\SCRIPTS\FULL ONE\ARQUIVOS .PS1 UNIFICADOS"
PASTA_PACKAGE = r"C:\SCRIPTS\FULL ONE\PACKAGE"
PASTA_COMPILADOS = r"C:\SCRIPTS\FULL ONE\COMPILADOS"

VERSAO_FULLONE = "FULLONEv14fixed2"

# Pastas que serão procuradas (adicione/remova conforme necessário)
PASTAS_PROCURA = [
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip",
    r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard\base_library.zip",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip",
    r"C:\MAGIC QUANTIC TRADER\MEGA SUITE 001",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE 002",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE 003",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE ALL IN ONE 004",
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\UNIC QUANTIC",
    r"C:\UNIC QUANTIC\scripts",
]

# ----------------------------
# FUNÇÕES
# ----------------------------

def atualizar_script_oficial():
    """Atualiza o criar-pacotes.py a partir da pasta oficial."""
    arquivo_oficial = os.path.join(PASTA_OFICIAL, "criar-pacotes.py")
    arquivo_exec = os.path.join(PASTA_EXEC, "criar-pacotes.py")

    if not os.path.exists(arquivo_oficial):
        print(f"[AVISO] Nenhum arquivo oficial encontrado em: {PASTA_OFICIAL}")
        return

    atualizar = False
    if not os.path.exists(arquivo_exec):
        atualizar = True
    else:
        # comparar conteúdo
        with open(arquivo_oficial, "rb") as f1, open(arquivo_exec, "rb") as f2:
            if f1.read() != f2.read():
                atualizar = True

    if atualizar:
        # faz backup do antigo
        if os.path.exists(arquivo_exec):
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = os.path.join(PASTA_EXEC, f"criar-pacotes_backup_{timestamp}.py")
            shutil.copy2(arquivo_exec, backup_path)
            print(f"[INFO] Backup do script antigo salvo em: {backup_path}")

        # copia a versão oficial
        shutil.copy2(arquivo_oficial, arquivo_exec)
        print(f"[INFO] Script atualizado automaticamente para a versão oficial.")

def buscar_arquivos():
    """Busca todos os arquivos .ps1 e .py nas pastas definidas"""
    todos_arquivos = []
    for pasta in PASTAS_PROCURA:
        if not os.path.exists(pasta):
            continue
        for root, dirs, files in os.walk(pasta):
            for file in files:
                if file.lower().endswith((".ps1", ".py")):
                    todos_arquivos.append(os.path.join(root, file))
    return todos_arquivos

def criar_unificado(arquivos, pasta_saida):
    """Cria um arquivo .ps1 unificado com todos os scripts encontrados"""
    if not os.path.exists(pasta_saida):
        os.makedirs(pasta_saida)
    unificado_path = os.path.join(pasta_saida, "ONEFULL.ps1")
    with open(unificado_path, "w", encoding="utf-8") as unificado:
        # adiciona cabeçalho
        unificado.write(f"# FULLONE Unificado - Versão {VERSAO_FULLONE}\n\n")
        for arquivo in arquivos:
            try:
                with open(arquivo, "r", encoding="utf-8") as f:
                    unificado.write(f"# ===== {os.path.basename(arquivo)} =====\n")
                    unificado.write(f.read() + "\n\n")
            except UnicodeDecodeError:
                print(f"[ERRO] Não foi possível ler o arquivo (problema de encoding): {arquivo}")
    print(f"[OK] Arquivo unificado criado: {unificado_path}")
    return unificado_path

def criar_zip(unificado_path):
    """Cria o ZIP na pasta PACKAGE, com versão incremental"""
    if not os.path.exists(PASTA_PACKAGE):
        os.makedirs(PASTA_PACKAGE)

    i = 1
    while True:
        zip_name = f"{VERSAO_FULLONE}_{i:04d}.zip"
        zip_path = os.path.join(PASTA_PACKAGE, zip_name)
        if not os.path.exists(zip_path):
            break
        i += 1

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(unificado_path, os.path.basename(unificado_path))
    print(f"[OK] ZIP criado: {zip_path}")

# ----------------------------
# EXECUÇÃO
# ----------------------------

if __name__ == "__main__":
    print("=== FULLONE - GERADOR AUTOMÁTICO v14fixed2 ===\n")

    # 1. Atualiza o próprio script se houver versão oficial
    atualizar_script_oficial()

    # 2. Busca todos os arquivos
    todos_arquivos = buscar_arquivos()
    print(f"[INFO] Total de arquivos encontrados (.ps1 e .py): {len(todos_arquivos)}")
    for f in todos_arquivos:
        print(f" - {f}")

    # 3. Cria arquivo unificado
    unificado = criar_unificado(todos_arquivos, PASTA_UNIFICADOS)

    # 4. Cria ZIP incremental
    criar_zip(unificado)

    print("\n=== FIM DO PROCESSO ===")


# ---- bloco ----

import os
import shutil
from pathlib import Path
import zipfile
from datetime import datetime
...


# ---- bloco ----

import os
import glob
import zipfile
from datetime import datetime
...


# ---- bloco ----

import os
import shutil
import zipfile
import datetime
...


# ---- bloco ----

import os
import shutil
import zipfile
from pathlib import Path
from datetime import datetime

# --------------------------
# CONFIGURAÇÕES DE PASTAS
# --------------------------
PASTAS_PROCURAR = [
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE ALL IN ONE 004",
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\UNIC QUANTIC",
]

PASTA_SOLTOS = r"C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR"
PASTA_UNIFICADO = r"C:\SCRIPTS\FULL ONE\ARQUIVOS .PS1 UNIFICADOS"
PASTA_COMPILADOS = r"C:\SCRIPTS\FULL ONE\COMPILADOS"
PASTA_PACKAGE = r"C:\SCRIPTS\FULL ONE\PACKAGE"
PASTA_OFICIAL = r"C:\SCRIPTS\FULL ONE\OFFICIAL"

VERSAO_FULLONE = "FULLONEv14fixed2"
NOME_UNIFICADO = "ONEFULL.ps1"

# --------------------------
# FUNÇÕES AUXILIARES
# --------------------------
def criar_pastas(*pastas):
    for p in pastas:
        os.makedirs(p, exist_ok=True)

def buscar_arquivos(extensoes=(".ps1", ".py")):
    arquivos = []
    for pasta in PASTAS_PROCURAR:
        base = Path(pasta)
        if base.exists():
            for ext in extensoes:
                arquivos.extend(list(base.rglob(f"*{ext}")))
    return arquivos

def salvar_unificado(arquivos, pasta_saida):
    criar_pastas(pasta_saida)
    ps1_unificado_path = Path(pasta_saida) / NOME_UNIFICADO

    if ps1_unificado_path.exists():
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup = ps1_unificado_path.with_name(f"{ps1_unificado_path.stem}_backup_{timestamp}.ps1")
        shutil.move(ps1_unificado_path, backup)
        print(f"[INFO] Backup do PS1 unificado antigo salvo em: {backup}")

    cabecalho = f"# =============================================\n" \
                 f"# {VERSAO_FULLONE} - PS1 Unificado (ONEFULL)\n" \
                 f"# Gerado em {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n" \
                 f"# =============================================\n\n"

    with open(ps1_unificado_path, 'w', encoding='utf-8') as f:
        f.write(cabecalho)
        for arq in arquivos:
            try:
                with open(arq, 'r', encoding='utf-8') as a:
                    conteudo = a.read()
                f.write(f"# ===== INICIO {arq.name} =====\n")
                f.write(conteudo + "\n")
                f.write(f"# ===== FIM {arq.name} =====\n\n")
            except Exception as e:
                print(f"[ERRO] Não foi possível ler {arq}: {e}")

    print(f"[INFO] PS1 unificado criado: {ps1_unificado_path}")
    return ps1_unificado_path

def gerar_zip(unificado_path):
    criar_pastas(PASTA_PACKAGE)
    contador = 1
    while True:
        zip_name = f"{VERSAO_FULLONE}_{contador:04d}.zip"
        zip_path = Path(PASTA_PACKAGE) / zip_name
        if not zip_path.exists():
            break
        contador += 1

    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        zipf.write(unificado_path, arcname=NOME_UNIFICADO)
        for arq in Path(PASTA_SOLTOS).glob("*"):
            zipf.write(arq, arcname=arq.name)

    print(f"[INFO] ZIP criado: {zip_path}")
    return zip_path

def atualizar_script_oficial():
    arquivo_oficial = Path(PASTA_OFICIAL) / "criar-pacotes.py"
    arquivo_exec = Path(PASTA_SOLTOS) / "criar-pacotes.py"

    if not arquivo_oficial.exists():
        print(f"[AVISO] Nenhum arquivo oficial encontrado em {PASTA_OFICIAL}")
        return

    atualizar = False
    if not arquivo_exec.exists():
        atualizar = True
    else:
        if arquivo_oficial.read_bytes() != arquivo_exec.read_bytes():
            atualizar = True

    if atualizar:
        if arquivo_exec.exists():
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_name = arquivo_exec.with_name(f"{arquivo_exec.stem}_backup_{timestamp}.py")
            shutil.move(arquivo_exec, backup_name)
            print(f"[INFO] Backup do script antigo salvo em: {backup_name}")

        # Versionamento automático
        n = 1
        while True:
            novo_nome = Path(PASTA_SOLTOS) / f"criar-pacotes{str(n).zfill(4)}.py"
            if not novo_nome.exists():
                break
            n += 1
        shutil.copy2(arquivo_oficial, novo_nome)
        print(f"[INFO] Script atualizado/versão nova salva como: {novo_nome}")

# --------------------------
# EXECUÇÃO
# --------------------------
if __name__ == "__main__":
    print(f"=== GERADOR FULLONE {VERSAO_FULLONE} ===\n")

    criar_pastas(PASTA_SOLTOS, PASTA_UNIFICADO, PASTA_COMPILADOS, PASTA_PACKAGE)

    # Atualiza o script oficial
    atualizar_script_oficial()

    # Buscar arquivos
    arquivos_encontrados = buscar_arquivos()
    print(f"[INFO] Total de arquivos encontrados: {len(arquivos_encontrados)}")
    for arq in arquivos_encontrados:
        print(f" - {arq}")

    # Criar PS1 unificado
    unificado = salvar_unificado(arquivos_encontrados, PASTA_UNIFICADO)

    # Criar ZIP incremental
    gerar_zip(unificado)

    print("\n=== FIM DO PROCESSO ===")


# ---- bloco ----

import os
import shutil
import zipfile
from pathlib import Path
from datetime import datetime
from fpdf import FPDF

# --------------------------
# CONFIGURAÇÕES DE PASTAS
# --------------------------
PASTAS_PROCURAR = [
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE ALL IN ONE 004",
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\UNIC QUANTIC",
]

PASTA_SOLTOS = r"C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR"
PASTA_UNIFICADO = r"C:\SCRIPTS\FULL ONE\ARQUIVOS .PS1 UNIFICADOS"
PASTA_COMPILADOS = r"C:\SCRIPTS\FULL ONE\COMPILADOS"
PASTA_PACKAGE = r"C:\SCRIPTS\FULL ONE\PACKAGE"
PASTA_OFICIAL = r"C:\SCRIPTS\FULL ONE\OFFICIAL"

VERSAO_FULLONE = "FULLONEv14fixed2"

# --------------------------
# CRIAR PASTAS SE NÃO EXISTIREM
# --------------------------
for pasta in [PASTA_SOLTOS, PASTA_UNIFICADO, PASTA_COMPILADOS, PASTA_PACKAGE]:
    os.makedirs(pasta, exist_ok=True)

# --------------------------
# FUNÇÕES
# --------------------------
def atualizar_script_oficial():
    """Atualiza o criar-pacotes.py com a última versão oficial"""
    oficiais = list(Path(PASTA_OFICIAL).glob("criar-pacotes*.py"))
    if not oficiais:
        return None
    ultima_oficial = max(oficiais, key=os.path.getmtime)
    scripts_exec = list(Path(PASTA_SOLTOS).glob("criar-pacotes*.py"))

    # Determina nome incremental
    if scripts_exec:
        numeros = [int(s.stem.replace("criar-pacotes", "")) for s in scripts_exec if s.stem.replace("criar-pacotes","").isdigit()]
        next_num = max(numeros) + 1 if numeros else 1
    else:
        next_num = 1
    novo_nome = Path(PASTA_SOLTOS) / f"criar-pacotes{str(next_num).zfill(4)}.py"

    # Backup antigo
    for s in scripts_exec:
        backup_nome = s.with_name(s.stem + "_backup.py")
        shutil.move(s, backup_nome)

    # Copia oficial
    shutil.copy2(ultima_oficial, novo_nome)
    print(f"[INFO] Script atualizado automaticamente para: {novo_nome}")
    return novo_nome

def buscar_arquivos():
    """Busca arquivos .ps1 e .py nas pastas definidas"""
    todos_arquivos = []
    for pasta in PASTAS_PROCURAR:
        base = Path(pasta)
        if base.exists():
            for ext in ("*.ps1", "*.py"):
                encontrados = list(base.rglob(ext))
                todos_arquivos.extend(encontrados)
    return todos_arquivos

def criar_unificado(arquivos):
    """Cria arquivo ONEFULL.ps1 unificado"""
    os.makedirs(PASTA_UNIFICADO, exist_ok=True)
    unificado_path = Path(PASTA_UNIFICADO) / "ONEFULL.ps1"

    # Backup antigo
    if unificado_path.exists():
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = unificado_path.with_name(f"{unificado_path.stem}_backup_{timestamp}.ps1")
        shutil.move(unificado_path, backup_path)

    cabecalho = f"# =============================================\n# {VERSAO_FULLONE} - PS1 Unificado (ONEFULL)\n# Gerado em {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n# =============================================\n"
    with open(unificado_path, 'w', encoding='utf-8') as f:
        f.write(cabecalho)
        for arquivo in arquivos:
            try:
                with open(arquivo, 'r', encoding='utf-8') as af:
                    f.write(f"\n# ===== INICIO {arquivo.name} =====\n")
                    f.write(af.read() + "\n")
                    f.write(f"# ===== FIM {arquivo.name} =====\n")
            except Exception as e:
                print(f"[ERRO] Não foi possível ler {arquivo}: {e}")

    print(f"[INFO] PS1 unificado criado em: {unificado_path}")
    return unificado_path

def criar_zip(unificado_path):
    """Cria ZIP do pacote completo, incrementando o nome"""
    os.makedirs(PASTA_PACKAGE, exist_ok=True)
    i = 1
    while True:
        zip_name = f"{VERSAO_FULLONE}_{i:04d}.zip"
        zip_path = Path(PASTA_PACKAGE) / zip_name
        if not zip_path.exists():
            break
        i += 1

    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(unificado_path, arcname=unificado_path.name)
        for arquivo in Path(PASTA_SOLTOS).glob("*"):
            zf.write(arquivo, arcname=arquivo.name)

    print(f"[INFO] ZIP criado em: {zip_path}")
    return zip_path

def gerar_pdf(todos_arquivos, zip_path):
    """Gera PDF detalhado do pacote"""
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", "B", 16)
    pdf.set_text_color(0, 0, 128)
    pdf.cell(0, 10, f"FULLONE - Pacote {VERSAO_FULLONE}", ln=True, align="C")
    pdf.set_font("Arial", "", 12)
    pdf.set_text_color(0,0,0)
    pdf.ln(5)
    pdf.cell(0,10,f"Gerado em: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", ln=True)
    pdf.cell(0,10,f"ZIP: {zip_path.name}", ln=True)
    pdf.cell(0,10,f"Total de arquivos encontrados: {len(todos_arquivos)}", ln=True)
    pdf.ln(5)

    pdf.set_font("Arial", "B", 12)
    pdf.set_fill_color(200, 220, 255)
    pdf.cell(0, 8, "Pastas pesquisadas", ln=True, fill=True)
    pdf.set_font("Arial", "", 10)
    for p in PASTAS_PROCURAR:
        pdf.cell(0, 6, str(p), ln=True)

    pdf.ln(5)
    pdf.set_font("Arial", "B", 12)
    pdf.set_fill_color(255, 220, 200)
    pdf.cell(0, 8, "Arquivos encontrados", ln=True, fill=True)
    pdf.set_font("Arial", "", 10)
    for f in todos_arquivos:
        pdf.cell(0, 6, str(f), ln=True)

    pdf_output = Path(PASTA_PACKAGE) / f"{VERSAO_FULLONE}_info.pdf"
    pdf.output(pdf_output)
    print(f"[INFO] PDF gerado em: {pdf_output}")
    return pdf_output

# --------------------------
# EXECUÇÃO
# --------------------------
if __name__ == "__main__":
    print(f"=== GERADOR AUTOMÁTICO {VERSAO_FULLONE} ===\n")

    # Atualiza script automaticamente
    atualizar_script_oficial()

    # Busca arquivos .ps1 e .py
    todos_arquivos = buscar_arquivos()
    print(f"[INFO] Total de arquivos encontrados: {len(todos_arquivos)}")

    # Cria arquivo unificado
    unificado = criar_unificado(todos_arquivos)

    # Cria ZIP incremental
    zip_path = criar_zip(unificado)

    # Gera PDF detalhado
    gerar_pdf(todos_arquivos, zip_path)

    print("\n=== PROCESSO CONCLUÍDO ✅ ===")


# ---- bloco ----

    # Tabela de arquivos encontrados
    pdf.ln(5)
    pdf.set_font("Arial", "B", 12)
    pdf.cell(0, 8, "Arquivos encontrados (.PS1 e .PY)", ln=True, fill=True)
    pdf.set_font("Arial", "", 10)
    for f in todos_arquivos:
        pdf.cell(0, 6, str(f), ln=True)

    # Salvar PDF
    os.makedirs(PASTA_DIAGRAMA, exist_ok=True)
    pdf_path = Path(PASTA_DIAGRAMA) / f"FULLONEv14fixed2_info_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    pdf.output(pdf_path)
    print(f"[INFO] PDF gerado em: {pdf_path}")
    return pdf_path

def gerar_fluxograma():
    """Gera fluxograma do processo com Graphviz"""
    dot = Digraph(comment='FULLONE Fluxograma')
    dot.attr(rankdir='LR', size='10')
    dot.node('A', 'Início')
    dot.node('B', 'Busca arquivos .PS1 e .PY')
    dot.node('C', 'Unificação em ONEFULL.ps1')
    dot.node('D', 'Criação do ZIP')
    dot.node('E', 'Geração PDF')
    dot.node('F', 'Fim')

    dot.edges(['AB', 'BC', 'CD', 'DE', 'EF'])

    os.makedirs(PASTA_DIAGRAMA, exist_ok=True)
    diagram_path = Path(PASTA_DIAGRAMA) / f"FULLONEv14fixed2_fluxograma"
    dot.render(str(diagram_path), format='png', cleanup=True)
    print(f"[INFO] Fluxograma gerado em: {diagram_path}.png")
    return diagram_path.with_suffix('.png')

# --------------------------
# EXECUÇÃO
# --------------------------
if __name__ == "__main__":
    print("=== FULLONE - Gerador Automático v14fixed2 ===\n")

    # Atualizar script oficial
    atualizar_script_oficial()

    # Buscar arquivos
    todos_arquivos, arquivos_ps1, arquivos_py = buscar_arquivos()
    print(f"[INFO] Total arquivos encontrados: {len(todos_arquivos)}")
    print(f"[INFO] Arquivos .PS1: {len(arquivos_ps1)}, Arquivos .PY: {len(arquivos_py)}")

    # Criar PS1 unificado
    unificado_path, cont_ps1_unificado, cont_py_unificado = criar_unificado(todos_arquivos)
    print(f"[INFO] Arquivos unificados - PS1: {cont_ps1_unificado}, PY: {cont_py_unificado}")

    # Criar ZIP
    zip_path = criar_zip(unificado_path)

    # Gerar PDF detalhado
    pdf_path = gerar_pdf(todos_arquivos, zip_path, len(arquivos_ps1), len(arquivos_py),
                         cont_ps1_unificado, cont_py_unificado)

    # Gerar fluxograma visual
    fluxograma_path = gerar_fluxograma()

    print("\n=== PROCESSO FINALIZADO COM SUCESSO ✅ ===")


# ---- bloco ----

import os
import shutil
import zipfile
from pathlib import Path
from datetime import datetime
from fpdf import FPDF
from graphviz import Digraph

# --------------------------
# CONFIGURAÇÕES DE PASTAS
# --------------------------
PASTAS_PROCURAR = [
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE ALL IN ONE 004",
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\UNIC QUANTIC",
]

PASTA_SOLTOS = r"C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR"
PASTA_UNIFICADO = r"C:\SCRIPTS\FULL ONE\ARQUIVOS .PS1 UNIFICADOS"
PASTA_COMPILADOS = r"C:\SCRIPTS\FULL ONE\COMPILADOS"
PASTA_PACKAGE = r"C:\SCRIPTS\FULL ONE\PACKAGE"
PASTA_DIAGRAMA = r"C:\SCRIPTS\FULL ONE\DIAGRAMA VISUAL"
PASTA_OFICIAL = r"C:\SCRIPTS\FULL ONE\OFFICIAL"

VERSAO_FULLONE = "FULLONEv14fixed2"
NOME_PS1_UNIFICADO = "ONEFULL.ps1"

# --------------------------
# CRIAR PASTAS SE NÃO EXISTIREM
# --------------------------
for pasta in [PASTA_SOLTOS, PASTA_UNIFICADO, PASTA_COMPILADOS, PASTA_PACKAGE, PASTA_DIAGRAMA]:
    os.makedirs(pasta, exist_ok=True)

# --------------------------
# FUNÇÕES
# --------------------------

def atualizar_script_oficial():
    """Atualiza o criar-pacotes.py a partir da versão oficial"""
    arquivo_oficial = os.path.join(PASTA_OFICIAL, "criar-pacotes.py")
    arquivo_exec = os.path.join(PASTA_SOLTOS, "criar-pacotes.py")

    if not os.path.exists(arquivo_oficial):
        print(f"[AVISO] Nenhum arquivo oficial encontrado em: {PASTA_OFICIAL}")
        return

    atualizar = False
    if not os.path.exists(arquivo_exec):
        atualizar = True
    else:
        # Comparar conteúdo
        with open(arquivo_oficial, "rb") as f1, open(arquivo_exec, "rb") as f2:
            if f1.read() != f2.read():
                atualizar = True

    if atualizar:
        if os.path.exists(arquivo_exec):
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = os.path.join(PASTA_SOLTOS, f"criar-pacotes_backup_{timestamp}.py")
            shutil.copy2(arquivo_exec, backup_path)
            print(f"[INFO] Backup do script antigo salvo em: {backup_path}")

        shutil.copy2(arquivo_oficial, arquivo_exec)
        print(f"[INFO] Script atualizado automaticamente para a versão oficial.")

def buscar_arquivos():
    """Busca todos os arquivos .PS1 e .PY"""
    todos_arquivos, arquivos_ps1, arquivos_py = [], [], []
    for pasta in PASTAS_PROCURAR:
        base_path = Path(pasta)
        if base_path.exists():
            for ext in ("*.ps1", "*.py"):
                encontrados = list(base_path.rglob(ext))
                todos_arquivos.extend(encontrados)
                if ext == "*.ps1":
                    arquivos_ps1.extend(encontrados)
                else:
                    arquivos_py.extend(encontrados)
    return todos_arquivos, arquivos_ps1, arquivos_py

def criar_unificado(todos_arquivos):
    """Cria arquivo ONEFULL.ps1 unificado"""
    os.makedirs(PASTA_UNIFICADO, exist_ok=True)
    ps1_path = Path(PASTA_UNIFICADO) / NOME_PS1_UNIFICADO

    if ps1_path.exists():
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = ps1_path.with_name(f"{ps1_path.stem}_backup_{timestamp}.ps1")
        shutil.move(ps1_path, backup_path)
        print(f"[INFO] Backup do PS1 unificado antigo: {backup_path}")

    cabecalho = f"# =============================================\n" \
                 f"# {VERSAO_FULLONE} - PS1 Unificado (ONEFULL)\n" \
                 f"# Gerado em {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n" \
                 f"# =============================================\n"

    cont_ps1, cont_py = 0, 0
    with open(ps1_path, 'w', encoding='utf-8') as f:
        f.write(cabecalho + "\n")
        for arquivo in todos_arquivos:
            try:
                with open(arquivo, 'r', encoding='utf-8') as af:
                    conteudo = af.read()
                f.write(f"\n\n# ===== INICIO {arquivo.name} =====\n")
                f.write(conteudo)
                f.write(f"\n# ===== FIM {arquivo.name} =====\n")
                if arquivo.suffix.lower() == ".ps1":
                    cont_ps1 += 1
                else:
                    cont_py += 1
            except Exception as e:
                print(f"[ERRO] Não foi possível ler {arquivo}: {e}")

    print(f"[INFO] PS1 unificado criado: {ps1_path}")
    return ps1_path, cont_ps1, cont_py

def criar_zip(unificado_path):
    """Cria ZIP incremental do pacote"""
    os.makedirs(PASTA_PACKAGE, exist_ok=True)
    contador = 1
    while True:
        zip_name = f"{VERSAO_FULLONE}_{contador:04d}.zip"
        zip_path = Path(PASTA_PACKAGE) / zip_name
        if not zip_path.exists():
            break
        contador += 1

    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        zipf.write(unificado_path, arcname=NOME_PS1_UNIFICADO)
        for arquivo in Path(PASTA_SOLTOS).glob("*"):
            zipf.write(arquivo, arcname=arquivo.name)

    print(f"[INFO] ZIP criado: {zip_path}")
    return zip_path

def gerar_pdf(todos_arquivos, zip_path, qtd_ps1, qtd_py, cont_ps1_unificado, cont_py_unificado):
    """Gera PDF com relatório detalhado"""
    from fpdf import FPDF
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", "B", 14)
    pdf.set_text_color(0, 102, 204)
    pdf.cell(0, 10, f"{VERSAO_FULLONE} - Relatório de Pacote", ln=True, align="C")

    pdf.set_font("Arial", "", 11)
    pdf.ln(5)
    pdf.multi_cell(0, 6, f"ZIP: {zip_path}\nData: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

    pdf.ln(5)
    pdf.set_font("Arial", "B", 12)
    pdf.set_fill_color(200, 220, 255)
    pdf.cell(0, 8, "Resumo de Arquivos", ln=True, fill=True)
    pdf.set_font("Arial", "", 10)
    pdf.cell(0, 6, f"Total arquivos encontrados: {len(todos_arquivos)}", ln=True)
    pdf.cell(0, 6, f"Arquivos .PS1 encontrados: {qtd_ps1}", ln=True)
    pdf.cell(0, 6, f"Arquivos .PY encontrados: {qtd_py}", ln=True)
    pdf.cell(0, 6, f"Arquivos .PS1 unificados: {cont_ps1_unificado}", ln=True)
    pdf.cell(0, 6, f"Arquivos .PY unificados: {cont_py_unificado}", ln=True)

    pdf.ln(5)
    pdf.set_font("Arial", "B", 12)
    pdf.cell(0, 8, "Arquivos Detalhados", ln=True, fill=True)
    pdf.set_font("Arial", "", 10)
    for f in todos_arquivos:
        pdf.cell(0, 6, str(f), ln=True)

    os.makedirs(PASTA_DIAGRAMA, exist_ok=True)
    pdf_path = Path(PASTA_DIAGRAMA) / f"{VERSAO_FULLONE}_relatorio_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    pdf.output(pdf_path)
    print(f"[INFO] PDF gerado: {pdf_path}")
    return pdf_path

def gerar_fluxograma():
    """Gera fluxograma do processo"""
    dot = Digraph(comment='FULLONE Fluxograma')
    dot.attr(rankdir='LR', size='10')
    dot.node('A', 'Início')
    dot.node('B', 'Busca arquivos .PS1 e .PY')
    dot.node('C', 'Unificação ONEFULL.ps1')
    dot.node('D', 'Criação do ZIP')
    dot.node('E', 'Geração PDF')
    dot.node('F', 'Fim')

    dot.edges(['AB', 'BC', 'CD', 'DE', 'EF'])

    os.makedirs(PASTA_DIAGRAMA, exist_ok=True)
    diagram_path = Path(PASTA_DIAGRAMA) / f"{VERSAO_FULLONE}_fluxograma"
    dot.render(str(diagram_path), format='png', cleanup=True)
    print(f"[INFO] Fluxograma gerado: {diagram_path}.png")
    return diagram_path.with_suffix('.png')

# --------------------------
# EXECUÇÃO PRINCIPAL
# --------------------------
if __name__ == "__main__":
    print("=== FULLONE - Gerador Automático v14fixed2 ===\n")

    atualizar_script_oficial()
    todos_arquivos, arquivos_ps1, arquivos_py = buscar_arquivos()

    print(f"[INFO] Total arquivos encontrados: {len(todos_arquivos)}")
    print(f"[INFO] Arquivos .PS1: {len(arquivos_ps1)}, Arquivos .PY: {len(arquivos_py)}")

    unificado_path, cont_ps1_unificado, cont_py_unificado = criar_unificado(todos_arquivos)

    zip_path = criar_zip(unificado_path)

    gerar_pdf(todos_arquivos, zip_path, len(arquivos_ps1), len(arquivos_py),
               cont_ps1_unificado, cont_py_unificado)

    gerar_fluxograma()

    print("\n=== PROCESSO FINALIZADO COM SUCESSO ✅ ===")


# ---- bloco ----

import os
import shutil
import zipfile
from pathlib import Path
from datetime import datetime
from fpdf import FPDF
from graphviz import Digraph

# --------------------------
# CONFIGURAÇÕES DE PASTAS
# --------------------------
PASTAS_PROCURAR = [
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE ALL IN ONE 004",
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\UNIC QUANTIC",
]

PASTA_SOLTOS = r"C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR"
PASTA_UNIFICADO = r"C:\SCRIPTS\FULL ONE\ARQUIVOS .PS1 UNIFICADOS"
PASTA_COMPILADOS = r"C:\SCRIPTS\FULL ONE\COMPILADOS"
PASTA_PACKAGE = r"C:\SCRIPTS\FULL ONE\PACKAGE"
PASTA_DIAGRAMA = r"C:\SCRIPTS\FULL ONE\DIAGRAMA VISUAL"
PASTA_OFICIAL = r"C:\SCRIPTS\FULL ONE\OFFICIAL"

VERSAO_FULLONE = "FULLONEv14fixed2"

# --------------------------
# CRIAR PASTAS SE NÃO EXISTIREM
# --------------------------
for pasta in [PASTA_SOLTOS, PASTA_UNIFICADO, PASTA_COMPILADOS, PASTA_PACKAGE, PASTA_DIAGRAMA]:
    os.makedirs(pasta, exist_ok=True)

# --------------------------
# FUNÇÕES
# --------------------------
def gerar_nome_script():
    """Gera nome incremental para criar-pacotes"""
    contador = 1
    while True:
        nome = f"criar-pacotes{str(contador).zfill(4)}.py"
        caminho = Path(PASTA_SOLTOS) / nome
        if not caminho.exists():
            return caminho
        contador += 1

def atualizar_script_oficial():
    """Atualiza o script principal automaticamente"""
    oficial = Path(PASTA_OFICIAL) / "criar-pacotes.py"
    if not oficial.exists():
        print("[AVISO] Nenhum arquivo oficial encontrado.")
        return None

    script_atual = gerar_nome_script()
    if script_atual.exists():
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup = script_atual.with_name(f"{script_atual.stem}-backup_{timestamp}.py")
        shutil.move(script_atual, backup)
        print(f"[INFO] Backup do script antigo salvo: {backup}")

    shutil.copy2(oficial, script_atual)
    print(f"[INFO] Script atualizado automaticamente para: {script_atual}")
    return script_atual

def buscar_arquivos():
    """Busca todos os arquivos .PS1 e .PY"""
    todos, ps1, py = [], [], []
    for pasta in PASTAS_PROCURAR:
        base = Path(pasta)
        if base.exists():
            for ext in ("*.ps1", "*.py"):
                encontrados = list(base.rglob(ext))
                todos.extend(encontrados)
                ps1.extend([f for f in encontrados if f.suffix.lower() == ".ps1"])
                py.extend([f for f in encontrados if f.suffix.lower() == ".py"])
    return todos, ps1, py

def criar_unificado(todos):
    """Cria ONEFULL.ps1 unificado e gera contagens"""
    Path(PASTA_UNIFICADO).mkdir(exist_ok=True)
    unificado = Path(PASTA_UNIFICADO) / "ONEFULL.ps1"

    if unificado.exists():
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup = unificado.with_name(f"{unificado.stem}_backup_{timestamp}.ps1")
        shutil.move(unificado, backup)
        print(f"[INFO] Backup PS1 antigo: {backup}")

    cabecalho = f"# {VERSAO_FULLONE} - PS1 Unificado\n# Gerado: {datetime.now()}\n"
    cont_ps1, cont_py = 0, 0
    with open(unificado, 'w', encoding='utf-8') as f:
        f.write(cabecalho + "\n")
        for arquivo in todos:
            try:
                with open(arquivo, 'r', encoding='utf-8') as af:
                    conteudo = af.read()
                f.write(f"\n# ===== INICIO {arquivo.name} =====\n")
                f.write(conteudo)
                f.write(f"\n# ===== FIM {arquivo.name} =====\n")
                if arquivo.suffix.lower() == ".ps1":
                    cont_ps1 += 1
                else:
                    cont_py += 1
            except Exception as e:
                print(f"[ERRO] Não foi possível ler {arquivo}: {e}")
    print(f"[INFO] PS1 unificado criado: {unificado}")
    return unificado, cont_ps1, cont_py

def criar_zip(unificado):
    """Cria ZIP incremental"""
    Path(PASTA_PACKAGE).mkdir(exist_ok=True)
    contador = 1
    while True:
        zip_name = f"{VERSAO_FULLONE}_{str(contador).zfill(4)}.zip"
        zip_path = Path(PASTA_PACKAGE) / zip_name
        if not zip_path.exists():
            break
        contador += 1
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        zipf.write(unificado, arcname=unificado.name)
        for arquivo in Path(PASTA_SOLTOS).glob("*"):
            zipf.write(arquivo, arcname=arquivo.name)
    print(f"[INFO] ZIP criado: {zip_path}")
    return zip_path

def gerar_pdf(todos, zip_path, qtd_ps1, qtd_py, cont_ps1, cont_py):
    """Gera relatório PDF detalhado"""
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", "B", 14)
    pdf.set_text_color(0, 102, 204)
    pdf.cell(0, 10, f"{VERSAO_FULLONE} - Relatório", ln=True, align="C")

    pdf.set_font("Arial", "", 11)
    pdf.ln(5)
    pdf.multi_cell(0, 6, f"ZIP: {zip_path}\nData: {datetime.now()}\n")

    pdf.ln(5)
    pdf.set_font("Arial", "B", 12)
    pdf.set_fill_color(200, 220, 255)
    pdf.cell(0, 8, "Resumo de Arquivos", ln=True, fill=True)
    pdf.set_font("Arial", "", 10)
    pdf.cell(0, 6, f"Total arquivos encontrados: {len(todos)}", ln=True)
    pdf.cell(0, 6, f"Arquivos .PS1 encontrados: {qtd_ps1}", ln=True)
    pdf.cell(0, 6, f"Arquivos .PY encontrados: {qtd_py}", ln=True)
    pdf.cell(0, 6, f"Arquivos .PS1 unificados: {cont_ps1}", ln=True)
    pdf.cell(0, 6, f"Arquivos .PY unificados: {cont_py}", ln=True)

    pdf.ln(5)
    pdf.set_font("Arial", "B", 12)
    pdf.cell(0, 8, "Arquivos Detalhados", ln=True, fill=True)
    pdf.set_font("Arial", "", 10)
    for f in todos:
        pdf.cell(0, 6, str(f), ln=True)

    Path(PASTA_DIAGRAMA).mkdir(exist_ok=True)
    pdf_path = Path(PASTA_DIAGRAMA) / f"{VERSAO_FULLONE}_relatorio_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    pdf.output(pdf_path)
    print(f"[INFO] PDF gerado: {pdf_path}")
    return pdf_path

def gerar_fluxograma():
    """Gera fluxograma visual do processo"""
    dot = Digraph(comment='FULLONE Fluxograma')
    dot.attr(rankdir='LR', size='10')
    dot.node('A', 'Início')
    dot.node('B', 'Busca arquivos .PS1 e .PY')
    dot.node('C', 'Unificação ONEFULL.ps1')
    dot.node('D', 'Criação ZIP')
    dot.node('E', 'Geração PDF')
    dot.node('F', 'Fim')
    dot.edges(['AB', 'BC', 'CD', 'DE', 'EF'])

    Path(PASTA_DIAGRAMA).mkdir(exist_ok=True)
    diagram_path = Path(PASTA_DIAGRAMA) / f"{VERSAO_FULLONE}_fluxograma"
    dot.render(str(diagram_path), format='png', cleanup=True)
    print(f"[INFO] Fluxograma gerado: {diagram_path}.png")
    return diagram_path.with_suffix('.png')

# --------------------------
# EXECUÇÃO PRINCIPAL
# --------------------------
if __name__ == "__main__":
    print("=== FULLONE Autônomo Avançado ===\n")
    atualizar_script_oficial()
    todos, ps1, py = buscar_arquivos()
    print(f"[INFO] Total arquivos encontrados: {len(todos)} | PS1: {len(ps1)} | PY: {len(py)}")
    unificado, cont_ps1, cont_py = criar_unificado(todos)
    zip_path = criar_zip(unificado)
    gerar_pdf(todos, zip_path, len(ps1), len(py), cont_ps1, cont_py)
    gerar_fluxograma()
    print("\n=== PROCESSO FINALIZADO ✅ ===")


# ---- bloco ----

dot = Digraph(comment='FULLONE Fluxograma')
...
dot.render(...)


# ---- bloco ----

# gerar_fluxograma()  # <-- comentar/remover


# ---- bloco ----

from fpdf import FPDF
from datetime import datetime

# --------------------------
# Configurações
# --------------------------
pdf_path = r"C:\SCRIPTS\FULL ONE\DIAGRAMA VISUAL\FULLONEv14fixed2_fluxo.pdf"
titulo = "FULLONEv14fixed2 - Fluxo de Pacotes"

# Criação do PDF
pdf = FPDF()
pdf.add_page()

# Título
pdf.set_font("Arial", "B", 16)
pdf.set_text_color(0, 51, 102)
pdf.cell(0, 10, titulo, 0, 1, 'C')
pdf.ln(5)

# Data de geração
pdf.set_font("Arial", "", 12)
pdf.set_text_color(0, 0, 0)
pdf.cell(0, 10, f"Gerado em: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", 0, 1)
pdf.ln(5)

# Seções do fluxo
pdf.set_font("Arial", "B", 14)
pdf.set_text_color(255, 102, 0)
pdf.cell(0, 10, "Fluxo do Script Criar-Pacotes", 0, 1)
pdf.ln(3)

# Etapas
pdf.set_font("Arial", "", 12)
etapas = [
    "1. Verificação de atualização do script na pasta OFFICIAL",
    "2. Backup do script e do PS1 unificado anterior",
    "3. Busca de arquivos .PS1 e .PY em todas as pastas configuradas",
    "4. Contagem total de arquivos encontrados (.PS1, .PY)",
    "5. Criação do arquivo unificado ONEFULL.ps1",
    "6. Criação de ZIP incremental com arquivos unificados e soltos",
    "7. Geração de PDF detalhado com:",
    "   - Contagem de arquivos",
    "   - Lista de pastas pesquisadas",
    "   - Tabela de versões e mudanças",
    "   - Fluxograma visual do projeto"
]

for i, etapa in enumerate(etapas, 1):
    pdf.set_text_color(0, 0, 128)
    pdf.multi_cell(0, 8, f"{i}. {etapa}")
    pdf.ln(1)

# Observações
pdf.set_font("Arial", "I", 11)
pdf.set_text_color(128, 0, 0)
pdf.ln(5)
pdf.multi_cell(0, 7, "- O script mantém backups automáticos e versões incrementais.\n- PDF e ZIP sempre atualizados.\n- Fluxograma gerado automaticamente via Graphviz.")

# Salvar PDF
pdf.output(pdf_path)
print(f"PDF gerado em: {pdf_path}")


# ---- bloco ----

import os
import shutil
import zipfile
import glob
from datetime import datetime
from fpdf import FPDF
from pathlib import Path
import subprocess

# -----------------------------
# CONFIGURAÇÕES DE PASTAS
# -----------------------------
PASTAS_PROCURA = [
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE ALL IN ONE 004",
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\UNIC QUANTIC",
]

PASTA_OFICIAL = r"C:\SCRIPTS\FULL ONE\OFFICIAL"
PASTA_SOLTOS = r"C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR"
PASTA_UNIFICADO = r"C:\SCRIPTS\FULL ONE\ARQUIVOS .PS1 UNIFICADOS"
PASTA_COMPILADOS = r"C:\SCRIPTS\FULL ONE\COMPILADOS"
PASTA_PACKAGE = r"C:\SCRIPTS\FULL ONE\PACKAGE"
PASTA_PDF = r"C:\SCRIPTS\FULL ONE\DIAGRAMA VISUAL"

VERSAO = "FULLONEv14fixed2"
NOME_UNIFICADO = "ONEFULL.ps1"

# -----------------------------
# CRIAR PASTAS SE NÃO EXISTIREM
# -----------------------------
for pasta in [PASTA_SOLTOS, PASTA_UNIFICADO, PASTA_COMPILADOS, PASTA_PACKAGE, PASTA_PDF]:
    os.makedirs(pasta, exist_ok=True)

# -----------------------------
# FUNÇÕES
# -----------------------------

def atualizar_script():
    """Atualiza automaticamente a versão do criar-pacotes se houver oficial"""
    oficial = os.path.join(PASTA_OFICIAL, "criar-pacotes.py")
    destino = os.path.join(PASTA_SOLTOS, "criar-pacotes.py")

    if not os.path.exists(oficial):
        print(f"[AVISO] Nenhum script oficial encontrado em: {PASTA_OFICIAL}")
        return

    atualizar = False
    if not os.path.exists(destino):
        atualizar = True
    else:
        with open(oficial, "rb") as f1, open(destino, "rb") as f2:
            if f1.read() != f2.read():
                atualizar = True

    if atualizar:
        if os.path.exists(destino):
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup = destino.replace(".py", f"_backup_{timestamp}.py")
            shutil.move(destino, backup)
            print(f"[INFO] Backup do script antigo: {backup}")
        shutil.copy2(oficial, destino)
        print(f"[INFO] Script atualizado para versão oficial.")

def buscar_arquivos(exts=(".ps1", ".py")):
    todos = []
    for pasta in PASTAS_PROCURA:
        if os.path.exists(pasta):
            for ext in exts:
                todos.extend(Path(pasta).rglob(f"*{ext}"))
    return todos

def criar_unificado(arquivos):
    unificado_path = Path(PASTA_UNIFICADO) / NOME_UNIFICADO
    if unificado_path.exists():
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup = unificado_path.with_name(f"{unificado_path.stem}_backup_{timestamp}.ps1")
        shutil.move(unificado_path, backup)
        print(f"[INFO] Backup do PS1 unificado antigo: {backup}")

    total_ps1 = total_py = 0
    with open(unificado_path, "w", encoding="utf-8") as f:
        f.write(f"# {VERSAO} - ONEFULL Unificado\n# Gerado: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        for arquivo in arquivos:
            try:
                conteudo = arquivo.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                conteudo = arquivo.read_text(encoding="latin-1")
            f.write(f"# ===== {arquivo.name} =====\n")
            f.write(conteudo + "\n# ===== FIM {arquivo.name} =====\n\n")
            if arquivo.suffix.lower() == ".ps1":
                total_ps1 += 1
            elif arquivo.suffix.lower() == ".py":
                total_py += 1
    print(f"[INFO] PS1 unificado criado: {unificado_path}")
    return unificado_path, total_ps1, total_py

def criar_zip(unificado_path):
    i = 1
    while True:
        zip_name = f"{VERSAO}_{i:04d}.zip"
        zip_path = Path(PASTA_PACKAGE) / zip_name
        if not zip_path.exists():
            break
        i += 1

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(unificado_path, arcname=NOME_UNIFICADO)
        for arquivo in Path(PASTA_SOLTOS).iterdir():
            if arquivo.is_file():
                zf.write(arquivo, arcname=arquivo.name)
    print(f"[INFO] ZIP criado: {zip_path}")
    return zip_path

def gerar_pdf(todos_arquivos, total_ps1, total_py):
    pdf_path = Path(PASTA_PDF) / f"{VERSAO}_relatorio_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    pdf = FPDF()
    pdf.add_page()

    pdf.set_font("Arial", "B", 16)
    pdf.set_text_color(0, 51, 102)
    pdf.cell(0, 10, f"{VERSAO} - Relatório Completo", 0, 1, 'C')
    pdf.ln(5)

    pdf.set_font("Arial", "", 12)
    pdf.set_text_color(0, 0, 0)
    pdf.multi_cell(0, 7, f"Data de geração: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    pdf.ln(5)

    pdf.set_font("Arial", "B", 14)
    pdf.set_text_color(255, 102, 0)
    pdf.cell(0, 10, "Resumo de Arquivos", 0, 1)
    pdf.set_font("Arial", "", 12)
    pdf.multi_cell(0, 7, f"Total arquivos encontrados: {len(todos_arquivos)}\nArquivos .PS1: {total_ps1}\nArquivos .PY: {total_py}\nArquivos unificados .PS1: {total_ps1}\nArquivos unificados .PY: {total_py}")
    pdf.ln(5)

    pdf.set_font("Arial", "B", 14)
    pdf.set_text_color(0, 102, 51)
    pdf.cell(0, 10, "Pastas Pesquisadas", 0, 1)
    pdf.set_font("Arial", "", 12)
    for p in PASTAS_PROCURA:
        pdf.multi_cell(0, 6, f"- {p}")

    pdf.output(pdf_path)
    print(f"[INFO] PDF gerado: {pdf_path}")
    return pdf_path

# -----------------------------
# EXECUÇÃO PRINCIPAL
# -----------------------------
if __name__ == "__main__":
    print(f"=== FULLONE - AUTÔNOMO AVANÇADO ({VERSAO}) ===\n")

    atualizar_script()

    todos_arquivos = buscar_arquivos()
    print(f"[INFO] Total arquivos encontrados: {len(todos_arquivos)}")

    unificado_path, total_ps1, total_py = criar_unificado(todos_arquivos)
    zip_path = criar_zip(unificado_path)
    pdf_path = gerar_pdf(todos_arquivos, total_ps1, total_py)

    print("\n=== PROCESSO COMPLETO CONCLUÍDO ✅ ===")


# ---- bloco ----

import os
import shutil
import glob
import zipfile
from pathlib import Path
from datetime import datetime
from fpdf import FPDF
import graphviz

# ----------------------------
# CONFIGURAÇÕES DE PASTAS
# ----------------------------
PASTAS_PROCURA = [
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE ALL IN ONE 004",
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\UNIC QUANTIC",
]

PASTA_SOLTOS = r"C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR"
PASTA_UNIFICADO = r"C:\SCRIPTS\FULL ONE\ARQUIVOS .PS1 UNIFICADOS"
PASTA_COMPILADOS = r"C:\SCRIPTS\FULL ONE\COMPILADOS"
PASTA_PACKAGE = r"C:\SCRIPTS\FULL ONE\PACKAGE"
PASTA_DIAGRAMA = r"C:\SCRIPTS\FULL ONE\DIAGRAMA VISUAL"
PASTA_OFICIAL = r"C:\SCRIPTS\FULL ONE\OFFICIAL"

VERSAO_FULLONE = "FULLONEv14fixed2"
NOME_UNIFICADO = "ONEFULL.ps1"

# ----------------------------
# CRIAR PASTAS SE NÃO EXISTIREM
# ----------------------------
for pasta in [PASTA_SOLTOS, PASTA_UNIFICADO, PASTA_COMPILADOS, PASTA_PACKAGE, PASTA_DIAGRAMA]:
    os.makedirs(pasta, exist_ok=True)

# ----------------------------
# FUNÇÕES
# ----------------------------
def atualizar_script_oficial():
    """Atualiza o script a partir da versão oficial."""
    arquivo_oficial = os.path.join(PASTA_OFICIAL, "criar-pacotes.py")
    arquivo_exec = os.path.join(PASTA_SOLTOS, "criar-pacotes-autonomo.py")
    if not os.path.exists(arquivo_oficial):
        print(f"[AVISO] Nenhum arquivo oficial encontrado em: {PASTA_OFICIAL}")
        return
    atualizar = False
    if not os.path.exists(arquivo_exec):
        atualizar = True
    else:
        with open(arquivo_oficial, "rb") as f1, open(arquivo_exec, "rb") as f2:
            if f1.read() != f2.read():
                atualizar = True
    if atualizar:
        if os.path.exists(arquivo_exec):
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = os.path.join(PASTA_SOLTOS, f"criar-pacotes_backup_{timestamp}.py")
            shutil.copy2(arquivo_exec, backup_path)
            print(f"[INFO] Backup do script antigo salvo em: {backup_path}")
        shutil.copy2(arquivo_oficial, arquivo_exec)
        print(f"[INFO] Script atualizado automaticamente para a versão oficial.")

def buscar_arquivos():
    """Busca todos os arquivos .PS1 e .PY nas pastas definidas"""
    todos_arquivos = []
    ps1_count = 0
    py_count = 0
    for pasta in PASTAS_PROCURA:
        if not os.path.exists(pasta):
            continue
        for root, dirs, files in os.walk(pasta):
            for file in files:
                if file.lower().endswith(".ps1"):
                    todos_arquivos.append(os.path.join(root, file))
                    ps1_count += 1
                elif file.lower().endswith(".py"):
                    todos_arquivos.append(os.path.join(root, file))
                    py_count += 1
    return todos_arquivos, ps1_count, py_count

def criar_unificado(arquivos):
    """Cria o PS1 unificado e faz backup automático"""
    unificado_path = os.path.join(PASTA_UNIFICADO, NOME_UNIFICADO)
    if os.path.exists(unificado_path):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = os.path.join(PASTA_UNIFICADO, f"ONEFULL_backup_{timestamp}.ps1")
        shutil.move(unificado_path, backup_path)
        print(f"[INFO] Backup do PS1 unificado antigo: {backup_path}")
    ps1_total = 0
    py_total = 0
    with open(unificado_path, "w", encoding="utf-8") as f:
        f.write(f"# FULLONE Unificado - Versão {VERSAO_FULLONE}\n# Gerado em {datetime.now()}\n\n")
        for arq in arquivos:
            try:
                with open(arq, "r", encoding="utf-8") as af:
                    conteudo = af.read()
                f.write(f"\n# ===== INICIO {os.path.basename(arq)} =====\n")
                f.write(conteudo)
                f.write(f"\n# ===== FIM {os.path.basename(arq)} =====\n")
                if arq.lower().endswith(".ps1"):
                    ps1_total += 1
                elif arq.lower().endswith(".py"):
                    py_total += 1
            except Exception as e:
                print(f"[ERRO] Não foi possível ler {arq}: {e}")
    print(f"[INFO] PS1 unificado criado: {unificado_path}")
    return unificado_path, ps1_total, py_total

def criar_zip(unificado_path):
    """Cria ZIP incremental"""
    contador = 1
    while True:
        zip_name = f"{VERSAO_FULLONE}_{contador:04d}.zip"
        zip_path = os.path.join(PASTA_PACKAGE, zip_name)
        if not os.path.exists(zip_path):
            break
        contador += 1
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(unificado_path, os.path.basename(unificado_path))
        for arquivo in glob.glob(os.path.join(PASTA_SOLTOS, "*")):
            zf.write(arquivo, os.path.basename(arquivo))
    print(f"[INFO] ZIP criado: {zip_path}")
    return zip_path

def gerar_fluxograma():
    """Gera diagrama visual via Graphviz"""
    diagram_path = Path(PASTA_DIAGRAMA) / f"{VERSAO_FULLONE}_fluxograma"
    dot = graphviz.Digraph(comment="FULLONE Fluxograma")
    dot.node('A', 'Início')
    dot.node('B', 'Busca arquivos')
    dot.node('C', 'Unificação')
    dot.node('D', 'Criação ZIP')
    dot.node('E', 'PDF Relatório')
    dot.edges(['AB', 'BC', 'CD', 'DE'])
    dot.render(str(diagram_path), format='png', cleanup=True)
    print(f"[INFO] Fluxograma gerado: {diagram_path}.png")
    return diagram_path.with_suffix(".png")

def gerar_pdf(arquivos, ps1_total, py_total, unificado_path, fluxograma_path):
    """Gera PDF detalhado"""
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", "B", 16)
    pdf.set_text_color(0, 0, 128)
    pdf.cell(0, 10, f"FULLONE Relatório - {VERSAO_FULLONE}", ln=True, align="C")
    pdf.ln(10)
    
    pdf.set_font("Arial", "", 12)
    pdf.set_text_color(0, 0, 0)
    pdf.multi_cell(0, 6, f"Data de geração: {datetime.now()}")
    pdf.multi_cell(0, 6, f"Total arquivos encontrados: {len(arquivos)}")
    pdf.multi_cell(0, 6, f"Arquivos .PS1: {ps1_total}")
    pdf.multi_cell(0, 6, f"Arquivos .PY: {py_total}")
    
    pdf.ln(5)
    pdf.multi_cell(0, 6, f"Arquivo unificado: {unificado_path}")
    pdf.ln(5)
    
    # Inserir fluxograma
    if fluxograma_path.exists():
        pdf.image(str(fluxograma_path), w=180)
    
    pdf_path = Path(PASTA_DIAGRAMA) / f"{VERSAO_FULLONE}_relatorio_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    pdf.output(str(pdf_path))
    print(f"[INFO] PDF gerado: {pdf_path}")
    return pdf_path

# ----------------------------
# EXECUÇÃO
# ----------------------------
if __name__ == "__main__":
    print(f"=== FULLONE Autônomo Avançado {VERSAO_FULLONE} ===\n")
    
    atualizar_script_oficial()
    
    arquivos, ps1_count, py_count = buscar_arquivos()
    print(f"[INFO] Total arquivos encontrados: {len(arquivos)}")
    print(f"[INFO] Arquivos .PS1: {ps1_count}, Arquivos .PY: {py_count}")
    
    unificado_path, ps1_total, py_total = criar_unificado(arquivos)
    
    zip_path = criar_zip(unificado_path)
    
    fluxograma_path = gerar_fluxograma()
    
    pdf_path = gerar_pdf(arquivos, ps1_total, py_total, unificado_path, fluxograma_path)
    
    print("\n=== PROCESSO CONCLUÍDO COM SUCESSO ✅ ===")


# ---- bloco ----

import os
import shutil
import glob
import zipfile
from pathlib import Path
from datetime import datetime
from fpdf import FPDF

# ----------------------------
# CONFIGURAÇÕES DE PASTAS
# ----------------------------
PASTAS_PROCURA = [
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE ALL IN ONE 004",
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\UNIC QUANTIC",
]

PASTA_SOLTOS = r"C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR"
PASTA_UNIFICADO = r"C:\SCRIPTS\FULL ONE\ARQUIVOS .PS1 UNIFICADOS"
PASTA_COMPILADOS = r"C:\SCRIPTS\FULL ONE\COMPILADOS"
PASTA_PACKAGE = r"C:\SCRIPTS\FULL ONE\PACKAGE"
PASTA_PDF = r"C:\SCRIPTS\FULL ONE\DIAGRAMA VISUAL"
PASTA_OFFICIAL = r"C:\SCRIPTS\FULL ONE\OFFICIAL"

VERSAO_FULLONE = "FULLONEv14fixed2"

# ----------------------------
# CRIAR PASTAS SE NÃO EXISTIREM
# ----------------------------
for pasta in [PASTA_SOLTOS, PASTA_UNIFICADO, PASTA_COMPILADOS, PASTA_PACKAGE, PASTA_PDF]:
    os.makedirs(pasta, exist_ok=True)

# ----------------------------
# FUNÇÕES
# ----------------------------
def atualizar_script():
    """Atualiza o script atual com a versão oficial, mantendo backup"""
    arquivos_oficiais = glob.glob(os.path.join(PASTA_OFFICIAL, "criar-pacotes*.py"))
    if not arquivos_oficiais:
        print(f"[AVISO] Nenhum arquivo oficial encontrado em: {PASTA_OFFICIAL}")
        return
    arquivo_oficial = max(arquivos_oficiais, key=os.path.getmtime)
    arquivo_exec = os.path.join(PASTA_SOLTOS, os.path.basename(arquivo_oficial))
    if os.path.exists(arquivo_exec):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = arquivo_exec.replace(".py", f"_backup_{timestamp}.py")
        shutil.move(arquivo_exec, backup_path)
        print(f"[INFO] Backup do script antigo salvo em: {backup_path}")
    shutil.copy2(arquivo_oficial, arquivo_exec)
    print(f"[INFO] Script atualizado automaticamente para a versão oficial.")

def buscar_arquivos(extensoes=("*.ps1","*.py")):
    todos_arquivos = []
    for pasta in PASTAS_PROCURA:
        if os.path.exists(pasta):
            for ext in extensoes:
                encontrados = list(Path(pasta).rglob(ext))
                todos_arquivos.extend(encontrados)
    return todos_arquivos

def criar_unificado(arquivos):
    unificado_path = Path(PASTA_UNIFICADO) / "ONEFULL.ps1"
    if unificado_path.exists():
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = unificado_path.with_name(f"{unificado_path.stem}_backup_{timestamp}.ps1")
        shutil.move(unificado_path, backup_path)
        print(f"[INFO] Backup do PS1 unificado antigo: {backup_path}")
    with open(unificado_path, "w", encoding="utf-8") as f:
        f.write(f"# {VERSAO_FULLONE} - PS1 Unificado (ONEFULL)\n")
        f.write(f"# Gerado em {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        for arq in arquivos:
            try:
                with open(arq, "r", encoding="utf-8") as a:
                    f.write(f"# ===== {arq.name} =====\n")
                    f.write(a.read()+"\n")
                    f.write(f"# ===== FIM {arq.name} =====\n\n")
            except Exception as e:
                print(f"[ERRO] Não foi possível ler {arq}: {e}")
    print(f"[INFO] PS1 unificado criado: {unificado_path}")
    return unificado_path

def criar_zip(arq_unificado, arquivos):
    i = 1
    while True:
        zip_name = f"{VERSAO_FULLONE}_{str(i).zfill(4)}.zip"
        zip_path = Path(PASTA_PACKAGE) / zip_name
        if not zip_path.exists():
            break
        i += 1
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        zipf.write(arq_unificado, arcname=arq_unificado.name)
        for a in arquivos:
            zipf.write(a, arcname=a.name)
    print(f"[INFO] ZIP criado: {zip_path}")
    return zip_path

def gerar_pdf(total, total_ps1, total_py, unificados_ps1, unificados_py):
    pdf_path = Path(PASTA_PDF) / f"{VERSAO_FULLONE}_relatorio_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", 'B', 16)
    pdf.set_text_color(0,0,128)
    pdf.cell(0,10,"FULLONE Autônomo Avançado - Relatório", ln=True)
    pdf.ln(5)
    pdf.set_font("Arial", '', 12)
    pdf.set_text_color(0,0,0)
    pdf.multi_cell(0,6,f"Versão: {VERSAO_FULLONE}\nTotal arquivos: {total}\nArquivos .PS1: {total_ps1}\nArquivos .PY: {total_py}\nArquivos .PS1 unificados: {unificados_ps1}\nArquivos .PY unificados: {unificados_py}")
    pdf.ln(5)
    pdf.set_fill_color(200,220,255)
    pdf.cell(60,8,"Arquivo",1,0,'C',True)
    pdf.cell(60,8,"Status",1,1,'C',True)
    pdf.set_fill_color(255,255,255)
    for f in Path(PASTA_UNIFICADO).glob("*.ps1"):
        pdf.cell(60,6,f.name,1,0,'C',True)
        pdf.cell(60,6,"Unificado",1,1,'C',True)
    pdf.output(pdf_path)
    print(f"[INFO] PDF gerado: {pdf_path}")

# ----------------------------
# EXECUÇÃO
# ----------------------------
if __name__ == "__main__":
    print("=== FULLONE - Gerador Automático Avançado ===\n")
    atualizar_script()
    arquivos = buscar_arquivos()
    total = len(arquivos)
    total_ps1 = len([a for a in arquivos if a.suffix.lower() == ".ps1"])
    total_py = len([a for a in arquivos if a.suffix.lower() == ".py"])
    print(f"[INFO] Total arquivos encontrados: {total} (.PS1: {total_ps1}, .PY: {total_py})")
    unificado = criar_unificado(arquivos)
    zip_path = criar_zip(unificado, arquivos)
    unificados_ps1 = len([a for a in Path(PASTA_UNIFICADO).glob("*.ps1")])
    unificados_py = len([a for a in Path(PASTA_UNIFICADO).glob("*.py")])
    gerar_pdf(total, total_ps1, total_py, unificados_ps1, unificados_py)
    print("\n=== FIM DO PROCESSO ===")


# ---- bloco ----

    # Cria ZIP incremental
    zip_path = criar_zip(unificado_path)

    # Gera fluxograma
    fluxograma_path = gerar_fluxograma()

    # Gera PDF detalhado
    pdf_path = gerar_pdf(todos_arquivos, unificado_path, zip_path, fluxograma_path)

    print("\n=== PROCESSO COMPLETO FINALIZADO ===")


# ---- bloco ----

import os
import shutil
import zipfile
from pathlib import Path
from datetime import datetime
import glob
from fpdf import FPDF
import graphviz

# ----------------------
# CONFIGURAÇÃO
# ----------------------
VERSAO_FULLONE = "FULLONEv14fixed2_FINAL"
PASTA_OFICIAL = r"C:\SCRIPTS\FULL ONE\OFFICIAL"
PASTA_EXEC = r"C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR"
PASTA_UNIFICADOS = r"C:\SCRIPTS\FULL ONE\ARQUIVOS .PS1 UNIFICADOS"
PASTA_PACKAGE = r"C:\SCRIPTS\FULL ONE\PACKAGE"
PASTA_COMPILADOS = r"C:\SCRIPTS\FULL ONE\COMPILADOS"
PASTA_DIAGRAMA = r"C:\SCRIPTS\FULL ONE\DIAGRAMA VISUAL"
PASTA_TXT_SCRIPTS = r"C:\SCRIPTS\FULL ONE\TXT_SCRIPTS"  # nova pasta para salvar scripts como .txt

NOME_UNIFICADO = "ONEFULL.ps1"

PASTAS_PROCURA = [
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE ALL IN ONE 004",
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\UNIC QUANTIC",
    r"C:\UNIC QUANTIC\scripts",
]

# ----------------------
# FUNÇÕES
# ----------------------

def atualizar_script_oficial():
    """Atualiza script oficial mantendo backup e versão anterior"""
    arquivo_oficial = Path(PASTA_OFICIAL) / "criar-pacotes.py"
    arquivo_exec = Path(PASTA_EXEC) / "criar-pacotes.py"

    if not arquivo_oficial.exists():
        print(f"[AVISO] Nenhum arquivo oficial encontrado em: {PASTA_OFICIAL}")
        return

    atualizar = False
    if not arquivo_exec.exists():
        atualizar = True
    else:
        if arquivo_oficial.read_bytes() != arquivo_exec.read_bytes():
            atualizar = True

    if atualizar:
        if arquivo_exec.exists():
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = arquivo_exec.with_name(f"{arquivo_exec.stem}_backup_{timestamp}.py")
            shutil.copy2(arquivo_exec, backup_path)
            print(f"[INFO] Backup do script antigo salvo: {backup_path}")
        shutil.copy2(arquivo_oficial, arquivo_exec)
        print("[INFO] Script atualizado automaticamente.")

def buscar_arquivos():
    """Busca arquivos .PS1 e .PY"""
    todos_arquivos = []
    for pasta in PASTAS_PROCURA:
        if Path(pasta).exists():
            for ext in ("*.ps1", "*.py"):
                encontrados = list(Path(pasta).rglob(ext))
                todos_arquivos.extend(encontrados)
    return todos_arquivos

def criar_unificado(arquivos, pasta_saida):
    """Cria arquivo PS1 unificado"""
    os.makedirs(pasta_saida, exist_ok=True)
    unificado_path = Path(pasta_saida) / NOME_UNIFICADO

    if unificado_path.exists():
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = unificado_path.with_name(f"{unificado_path.stem}_backup_{timestamp}.ps1")
        shutil.move(unificado_path, backup_path)
        print(f"[INFO] Backup do PS1 unificado antigo: {backup_path}")

    with open(unificado_path, "w", encoding="utf-8") as f:
        f.write(f"# FULLONE Unificado - Versão {VERSAO_FULLONE}\n")
        f.write(f"# Gerado em {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        for arquivo in arquivos:
            try:
                with open(arquivo, "r", encoding="utf-8") as af:
                    conteudo = af.read()
                f.write(f"# ===== INICIO {arquivo.name} =====\n")
                f.write(conteudo + "\n")
                f.write(f"# ===== FIM {arquivo.name} =====\n\n")
            except Exception as e:
                print(f"[ERRO] Não foi possível ler {arquivo}: {e}")

    print(f"[INFO] PS1 unificado criado: {unificado_path}")
    return unificado_path

def criar_zip(unificado_path):
    """Cria ZIP incremental"""
    os.makedirs(PASTA_PACKAGE, exist_ok=True)
    contador = 1
    while True:
        zip_name = f"{VERSAO_FULLONE}_{contador:04d}.zip"
        zip_path = Path(PASTA_PACKAGE) / zip_name
        if not zip_path.exists():
            break
        contador += 1

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(unificado_path, arcname=unificado_path.name)
        # Adiciona arquivos soltos
        for arquivo in glob.glob(os.path.join(PASTA_EXEC, "*")):
            zf.write(arquivo, arcname=os.path.basename(arquivo))

    print(f"[INFO] ZIP criado: {zip_path}")
    return zip_path

def salvar_scripts_txt(arquivos):
    """Salva todos os scripts como .txt para referência no PDF"""
    os.makedirs(PASTA_TXT_SCRIPTS, exist_ok=True)
    txt_arquivos = []
    for arq in arquivos:
        try:
            txt_path = Path(PASTA_TXT_SCRIPTS) / f"{arq.stem}.txt"
            shutil.copy2(arq, txt_path)
            txt_arquivos.append(txt_path)
        except Exception as e:
            print(f"[ERRO] Não foi possível salvar {arq} como .txt: {e}")
    return txt_arquivos

def gerar_fluxograma():
    """Gera fluxograma Graphviz"""
    dot = graphviz.Digraph(comment='FULLONE Fluxograma')
    dot.node('A', 'Início')
    dot.node('B', 'Busca arquivos')
    dot.node('C', 'Unifica PS1')
    dot.node('D', 'Cria ZIP')
    dot.node('E', 'Gera PDF')
    dot.edges(['AB', 'BC', 'CD', 'DE'])
    os.makedirs(PASTA_DIAGRAMA, exist_ok=True)
    diagram_path = Path(PASTA_DIAGRAMA) / f"FULLONE_Fluxograma_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    dot.render(str(diagram_path), format='png', cleanup=True)
    return str(diagram_path) + ".png"

def gerar_pdf(todos_arquivos, unificado_path, zip_path, fluxograma_path, txt_scripts):
    """Gera PDF detalhado com anexos .txt dos scripts"""
    os.makedirs(PASTA_DIAGRAMA, exist_ok=True)
    pdf_path = Path(PASTA_DIAGRAMA) / f"{VERSAO_FULLONE}_relatorio_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", "B", 16)
    pdf.set_text_color(0,0,128)
    pdf.cell(0,10,f"FULLONE Relatório - {VERSAO_FULLONE}", ln=True, align="C")
    pdf.ln(5)

    # Estatísticas
    ps1_count = len([f for f in todos_arquivos if f.suffix.lower() == ".ps1"])
    py_count = len([f for f in todos_arquivos if f.suffix.lower() == ".py"])
    pdf.set_font("Arial","",12)
    pdf.set_text_color(0,0,0)
    pdf.multi_cell(0,6,f"Total de arquivos encontrados: {len(todos_arquivos)}\n"
                          f"Arquivos .PS1: {ps1_count}\n"
                          f"Arquivos .PY: {py_count}\n"
                          f"Arquivo PS1 unificado: {unificado_path}\n"
                          f"ZIP gerado: {zip_path}\n")
    pdf.ln(5)

    # Fluxograma
    pdf.set_font("Arial","B",14)
    pdf.set_text_color(0,128,0)
    pdf.cell(0,10,"Fluxograma do processo", ln=True)
    pdf.image(fluxograma_path, w=180)
    pdf.ln(5)

    # Lista de arquivos
    pdf.set_font("Arial","B",12)
    pdf.set_text_color(128,0,0)
    pdf.cell(0,8,"Lista de arquivos encontrados:", ln=True)
    pdf.set_font("Arial","",10)
    for f in todos_arquivos:
        pdf.multi_cell(0,5,str(f))
    pdf.ln(5)

    # Anexa scripts como referência
    pdf.set_font("Arial","B",12)
    pdf.set_text_color(0,0,0)
    pdf.cell(0,8,"Scripts anexados como .TXT:", ln=True)
    pdf.set_font("Arial","",10)
    for txt in txt_scripts:
        pdf.multi_cell(0,5,str(txt))
    pdf.output(pdf_path)
    print(f"[INFO] PDF gerado: {pdf_path}")
    return pdf_path

# ===============================
# EXECUÇÃO PRINCIPAL
# ===============================
if __name__ == "__main__":
    print("=== FULLONE - AUTÔNOMO AVANÇADO FINAL ===\n")
    atualizar_script_oficial()
    todos_arquivos = buscar_arquivos()
    print(f"[INFO] Total arquivos encontrados: {len(todos_arquivos)}")
    print(f"[INFO] Arquivos .PS1: {len([f for f in todos_arquivos if f.suffix.lower()=='.ps1'])}")
    print(f"[INFO] Arquivos .PY: {len([f for f in todos_arquivos if f.suffix.lower()=='.py'])}")

    unificado_path = criar_unificado(todos_arquivos, PASTA_UNIFICADOS)
    zip_path = criar_zip(unificado_path)
    txt_scripts = salvar_scripts_txt(todos_arquivos)
    fluxograma_path = gerar_fluxograma()
    pdf_path = gerar_pdf(todos_arquivos, unificado_path, zip_path, fluxograma_path, txt_scripts)

    print("\n=== PROCESSO COMPLETO FINALIZADO ===")


# ---- bloco ----

import os
import shutil
import zipfile
from pathlib import Path
from datetime import datetime
import glob
from fpdf import FPDF
import graphviz

# ===============================
# CONFIGURAÇÃO DE PASTAS E VERSÃO
# ===============================
VERSAO_FULLONE = "FULLONEv14fixed3"
PASTA_OFICIAL = r"C:\SCRIPTS\FULL ONE\OFFICIAL"
PASTA_EXEC = r"C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR"
PASTA_UNIFICADOS = r"C:\SCRIPTS\FULL ONE\ARQUIVOS .PS1 UNIFICADOS"
PASTA_PACKAGE = r"C:\SCRIPTS\FULL ONE\PACKAGE"
PASTA_COMPILADOS = r"C:\SCRIPTS\FULL ONE\COMPILADOS"
PASTA_DIAGRAMA = r"C:\SCRIPTS\FULL ONE\DIAGRAMA VISUAL"

# Pastas para buscar arquivos
PASTAS_PROCURA = [
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE ALL IN ONE 004",
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\UNIC QUANTIC",
    r"C:\UNIC QUANTIC\scripts",
]

NOME_UNIFICADO = "ONEFULL.ps1"

# ===============================
# FUNÇÕES
# ===============================

def atualizar_script_oficial():
    """Atualiza o script oficial e cria backup automático"""
    arquivo_oficial = Path(PASTA_OFICIAL) / "criar-pacotes.py"
    if not arquivo_oficial.exists():
        print(f"[AVISO] Nenhum arquivo oficial encontrado em: {PASTA_OFICIAL}")
        return
    arquivos_exec = sorted(Path(PASTA_EXEC).glob("criar-pacotes*.py"))
    # Backup dos antigos
    for arq in arquivos_exec:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = arq.with_name(f"{arq.stem}_backup_{timestamp}.py")
        shutil.move(arq, backup_path)
        print(f"[INFO] Backup do script antigo salvo: {backup_path}")
    # Copia arquivo oficial como novo
    novo_nome = f"criar-pacotes{len(arquivos_exec)+1:04d}.py"
    shutil.copy2(arquivo_oficial, Path(PASTA_EXEC) / novo_nome)
    print(f"[INFO] Script atualizado automaticamente: {novo_nome}")

def buscar_arquivos():
    """Busca arquivos .PS1 e .PY, priorizando os mais recentes"""
    todos_arquivos = []
    for pasta in PASTAS_PROCURA:
        if Path(pasta).exists():
            for ext in ("*.ps1", "*.py"):
                todos_arquivos.extend(Path(pasta).rglob(ext))
    # Remover duplicados mantendo o mais recente
    arquivos_dict = {}
    for f in todos_arquivos:
        key = f.name.lower()
        if key not in arquivos_dict or f.stat().st_mtime > arquivos_dict[key].stat().st_mtime:
            arquivos_dict[key] = f
    return list(arquivos_dict.values())

def criar_unificado(arquivos, pasta_saida):
    """Cria PS1 unificado com backup automático"""
    os.makedirs(pasta_saida, exist_ok=True)
    unificado_path = Path(pasta_saida) / NOME_UNIFICADO
    if unificado_path.exists():
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = unificado_path.with_name(f"{unificado_path.stem}_backup_{timestamp}.ps1")
        shutil.move(unificado_path, backup_path)
        print(f"[INFO] Backup do PS1 unificado antigo: {backup_path}")
    with open(unificado_path, "w", encoding="utf-8") as f:
        f.write(f"# FULLONE Unificado - Versão {VERSAO_FULLONE}\n")
        f.write(f"# Gerado em {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        for arquivo in arquivos:
            try:
                with open(arquivo, "r", encoding="utf-8") as af:
                    conteudo = af.read()
                f.write(f"# ===== INICIO {arquivo.name} =====\n")
                f.write(conteudo + "\n")
                f.write(f"# ===== FIM {arquivo.name} =====\n\n")
            except Exception as e:
                print(f"[ERRO] Não foi possível ler {arquivo}: {e}")
    print(f"[INFO] PS1 unificado criado: {unificado_path}")
    return unificado_path

def criar_zip(unificado_path):
    """Cria ZIP incremental"""
    os.makedirs(PASTA_PACKAGE, exist_ok=True)
    contador = 1
    while True:
        zip_name = f"{VERSAO_FULLONE}_{contador:04d}.zip"
        zip_path = Path(PASTA_PACKAGE) / zip_name
        if not zip_path.exists():
            break
        contador += 1
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(unificado_path, arcname=unificado_path.name)
        for arquivo in glob.glob(os.path.join(PASTA_EXEC, "*")):
            zf.write(arquivo, arcname=os.path.basename(arquivo))
    print(f"[INFO] ZIP criado: {zip_path}")
    return zip_path

def gerar_fluxograma():
    """Gera fluxograma Graphviz"""
    dot = graphviz.Digraph(comment='FULLONE Fluxograma')
    dot.node('A', 'Início')
    dot.node('B', 'Busca arquivos')
    dot.node('C', 'Unifica PS1')
    dot.node('D', 'Cria ZIP')
    dot.node('E', 'Gera PDF')
    dot.edges(['AB', 'BC', 'CD', 'DE'])
    diagram_path = Path(PASTA_DIAGRAMA) / f"FULLONE_Fluxograma_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    os.makedirs(PASTA_DIAGRAMA, exist_ok=True)
    dot.render(str(diagram_path), format='png', cleanup=True)
    return str(diagram_path) + ".png"

def gerar_pdf(todos_arquivos, unificado_path, zip_path, fluxograma_path):
    """Gera PDF detalhado e salva scripts como TXT para referência"""
    os.makedirs(PASTA_DIAGRAMA, exist_ok=True)
    pdf_path = Path(PASTA_DIAGRAMA) / f"{VERSAO_FULLONE}_relatorio_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", "B", 16)
    pdf.set_text_color(0,0,128)
    pdf.cell(0,10,f"FULLONE Relatório - {VERSAO_FULLONE}",ln=True,align="C")
    pdf.ln(5)

    # Estatísticas completas
    ps1_total = len([f for f in todos_arquivos if f.suffix.lower() == ".ps1"])
    py_total = len([f for f in todos_arquivos if f.suffix.lower() == ".py"])
    ps1_unificados = ps1_total
    py_unificados = py_total
    pdf.set_font("Arial","",12)
    pdf.set_text_color(0,0,0)
    pdf.multi_cell(0,6,f"Total de arquivos encontrados: {len(todos_arquivos)}\n"
                          f"Arquivos .PS1: {ps1_total}\n"
                          f"Arquivos .PY: {py_total}\n"
                          f"Arquivos PS1 unificados: {ps1_unificados}\n"
                          f"Arquivos PY unificados: {py_unificados}\n"
                          f"Arquivo PS1 unificado: {unificado_path}\n"
                          f"ZIP gerado: {zip_path}\n")
    pdf.ln(5)

    # Fluxograma
    pdf.set_font("Arial","B",14)
    pdf.set_text_color(0,128,0)
    pdf.cell(0,10,"Fluxograma do processo",ln=True)
    pdf.image(fluxograma_path,w=180)
    pdf.ln(5)

    # Lista de arquivos
    pdf.set_font("Arial","B",12)
    pdf.set_text_color(128,0,0)
    pdf.cell(0,8,"Lista de arquivos encontrados:",ln=True)
    pdf.set_font("Arial","",10)
    for f in todos_arquivos:
        pdf.multi_cell(0,5,str(f))

    # Salvar scripts como TXT para referência
    txt_dir = Path(PASTA_DIAGRAMA) / "scripts_txt"
    os.makedirs(txt_dir, exist_ok=True)
    for arquivo in todos_arquivos:
        try:
            txt_path = txt_dir / f"{arquivo.name}.txt"
            shutil.copy2(arquivo, txt_path)
        except:
            continue

    pdf.output(pdf_path)
    print(f"[INFO] PDF gerado: {pdf_path}")
    return pdf_path

# ===============================
# EXECUÇÃO PRINCIPAL
# ===============================
if __name__ == "__main__":
    print("=== FULLONE - GERADOR AUTÔNOMO AVANÇADO ===\n")

    # Atualiza script oficial
    atualizar_script_oficial()

    # Buscar arquivos
    todos_arquivos = buscar_arquivos()
    print(f"[INFO] Total de arquivos encontrados: {len(todos_arquivos)}")
    print(f"[INFO] Arquivos .PS1: {len([f for f in todos_arquivos if f.suffix.lower()=='.ps1'])}")
    print(f"[INFO] Arquivos .PY: {len([f for f in todos_arquivos if f.suffix.lower()=='.py'])}")

    # Criar PS1 unificado
    unificado_path = criar_unificado(todos_arquivos, PASTA_UNIFICADOS)

    # Criar ZIP incremental
    zip_path = criar_zip(unificado_path)

    # Gerar fluxograma
    fluxograma_path = gerar_fluxograma()

    # Gerar PDF completo
    pdf_path = gerar_pdf(todos_arquivos, unificado_path, zip_path, fluxograma_path)

    print("\n=== FULLONE - Processo concluído com sucesso! ===")


# ---- bloco ----

arquivos_dict = {}
for f in todos_arquivos:
    key = f.name.lower()
    if key not in arquivos_dict or f.stat().st_mtime > arquivos_dict[key].stat().st_mtime:
        arquivos_dict[key] = f


# ---- bloco ----

#!/usr/bin/env python3
# FULLONE Autônomo Avançado - FULLONEv14fixed2
# Save as: FULLONEv14fixed2_AutonomoAvancado.py
# Usage: python FULLONEv14fixed2_AutonomoAvancado.py [--test]
# - --test -> runs a small local test, will not scan your real folders

import os
import sys
import shutil
import zipfile
import glob
import re
from pathlib import Path
from datetime import datetime

# External libs
try:
    from fpdf import FPDF
except Exception as e:
    print("Missing dependency: fpdf. Install: pip install fpdf")
    raise

try:
    import graphviz
    HAVE_GRAPHVIZ = True
except Exception:
    HAVE_GRAPHVIZ = False

try:
    from PIL import Image, ImageDraw, ImageFont
    HAVE_PIL = True
except Exception:
    HAVE_PIL = False

# -------------------------
# Configuration (updateable)
# -------------------------
VERSAO_FULLONE = "FULLONEv14fixed2"
# Output folders
BASE_OUTPUT = Path(r"C:\SCRIPTS\FULL ONE")
PASTA_EXEC = BASE_OUTPUT / "FULL ONE GENERATOR"
PASTA_UNIFICADOS = BASE_OUTPUT / "ARQUIVOS .PS1 UNIFICADOS"
PASTA_PACKAGE = BASE_OUTPUT / "PACKAGE"
PASTA_COMPILADOS = BASE_OUTPUT / "COMPILADOS"
PASTA_DIAGRAMA = BASE_OUTPUT / "DIAGRAMA VISUAL"
PASTA_TXT_REF = PASTA_DIAGRAMA / "SCRIPTS_TXT_REF"
PASTA_LOGS = BASE_OUTPUT / "LOGS"
PASTA_OFFICIAL = BASE_OUTPUT / "OFFICIAL"   # if you keep an 'official' generator here, script can auto-update

# create outputs if missing
for p in (PASTA_EXEC, PASTA_UNIFICADOS, PASTA_PACKAGE, PASTA_COMPILADOS, PASTA_DIAGRAMA, PASTA_TXT_REF, PASTA_LOGS, PASTA_OFFICIAL):
    try:
        p.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

# -------------------------
# The full list of search paths you provided
# -------------------------
SEARCH_PATHS = [
r"C:\CONAV TRADER",
r"C:\CONAV TRADER\CONAV_TRADER\automation",
r"C:\CONAV TRADER\CONAV_TRADER\build",
r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
r"C:\CONAV TRADER\CONAV_TRADER\data",
r"C:\CONAV TRADER\CONAV_TRADER\database",
r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
r"C:\CONAV TRADER\CONAV_TRADER\dist",
r"C:\CONAV TRADER\CONAV_TRADER\docs",
r"C:\CONAV TRADER\CONAV_TRADER\emails",
r"C:\CONAV TRADER\CONAV_TRADER\icons",
r"C:\CONAV TRADER\CONAV_TRADER\logs",
r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
r"C:\CONAV TRADER\CONAV_TRADER\resources",
r"C:\CONAV TRADER\CONAV_TRADER\scripts",
r"C:\CONAV TRADER\CONAV_TRADER\tools",
r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar",
r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\localpycs",
r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip",
r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\collections",
r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\encodings",
r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\re",
r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard",
r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard\localpycs",
r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard\base_library.zip",
r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper",
r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\localpycs",
r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip",
r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\collections",
r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\re",
r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\encodings",
r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar\build",
r"C:\CONAV TRADER\CONAV_TRADER\mapas de fluxograma",
r"C:\CONAV TRADER\CONAV_TRADER\PACKAGES OFICIAIS",
r"C:\CONAV TRADER\CONAV_TRADER\SCRIPT MESTRE",
r"C:\CONAV TRADER\CONAV_TRADER\scripts\0001",
r"C:\CONAV TRADER\CONAV_TRADER\scripts\0002",
r"C:\CONAV TRADER\CONAV_TRADER\scripts\0003",
r"C:\CONAV TRADER\CONAV_TRADER\scripts\004",
r"C:\CONAV TRADER\CONAV_TRADER\scripts\aleatorios versoes 1.30+",
r"C:\CONAV TRADER\CONAV_TRADER\scripts\PACKAGES OFICIAIS",
r"C:\CONAV TRADER\CONAV_TRADER\scripts\SCRIPTS BASE OFICIAIS",
r"C:\CONAV TRADER\CONAV_TRADER\scripts\SCRIPTS DE LISTAGEM",
r"C:\CONAV TRADER\CONAV_TRADER\scripts\uninstall versoes 1.30+",
r"C:\CONAV TRADER\CONAV_TRADER\SCRIPTS DE LISTAGEM",
r"C:\CONAV TRADER\CONAV_TRADER\SCRIPTS BASE OFICIAIS",
r"C:\CONAV TRADER\CONAV_TRADER\tools",
r"C:\CONAV TRADER\CONAV_TRADER\TUTORIAL GERAL",
r"C:\CONAV TRADER\CONAV_TRADER\CONAV MASTER FULL",
r"C:\CONAV TRADER\dist",
r"C:\CONAV TRADER\logs",
r"C:\CONAV TRADER\PASTA DO BACKUP\CONAV TRADES ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV-ZIP_20250911_160904",
r"C:\CONAV TRADER\PASTA DO BACKUP\CONAV TRADES ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV-ZIP_20250911_161555",
r"C:\CONAV TRADER\PASTAS DO  BACKUP",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADER TESTER ONE CLICK",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV_TRADER_FULL2",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\INSTALL CONAV  TRADERFULL",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\INSTALL SETUP CONAV ICONS",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\UNINSTALL CONAV TRADER",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV_TRADER_FULL1",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV_TRADER_FULL2",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV_TRADER_OneClick-CONTEM ERROS",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV TRADER FULL 1.44",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV TRADER FULL 1.44\fix 1.44",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_FULL_PROFESSIONAL_v1.45",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_FULL_PROFESSIONAL_v1.45\fix 1.45",
r"C:\MAGIC QUANTIC TRADER\ZIPS E VERSOES\MEGA SUITE 001",
r"C:\MAGIC QUANTIC TRADER\ZIPS E VERSOES\MQT PACKAGE COMPLETE 002",
r"C:\MAGIC QUANTIC TRADER\ZIPS E VERSOES\MQT PACKAGE COMPLETE 003",
r"C:\MAGIC QUANTIC TRADER\ZIPS E VERSOES\MQT PACKAGE COMPLETE ALL IN ONE 004",
r"C:\MAGIC QUANTIC TRADER\ZIPS E VERSOES\MQT NEW MEGA SUITE ALL 005",
r"C:\CONAV TRADER\CONAV_TRADER\CONAV MASTER FULL\FULLONEMASTER-INSTALL",
r"C:\CONAV TRADER\CONAV_TRADER\CONAV MASTER FULL\FULLONEMASTER\FULLONE-MESTER",
r"C:\CONAV TRADER\CONAV_TRADER\scripts\CONAV MASTER FULL FIX4\CONAVMASTER FIX4",
r"C:\CONAV TRADER\CONAV_TRADER\PACKAGES OFICIAIS\CONAV_FULL_PROFESSIONAL_v1.45_fix3_pkg",
r"C:\CONAV TRADER\CONAV_TRADER\PACKAGES OFICIAIS\CONAV_FULL_PROFESSIONAL_v1.45_fix3_pkg_1",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_ADVANCED_PRODUCTION\CONAV_TRADER",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_ADVANCED_PRODUCTION",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.29\INSTALL_CONAV_TRADER_FULL1.29",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.30",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.30\CONAV_TRADER_1_30_fixed",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.30\CONAV_TRADER_1_30_01fixed",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.31",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.32",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.33",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.34\CONAV_TRADER",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.34.1",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_PRODUCTION_TEST",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\INSTALL CONAV  TRADERFULL",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\BACKUP DO 1 PS1",
r"C:\CONAV TRADER\PASTAS DO  BACKUP\SCRIPTS OPCIONAIS E FUNCIONAIS",
r"C:\USERAT",
r"C:\USERAT\scripts",
r"C:\USERAT\scripts\scripts 2",
r"C:\USERAT\scripts\scripts 2\compiladao",
r"C:\USERAT\USERAT_Projeto_Completo",
r"C:\USERAT\USERAT_Projeto_Completo\scripts",
r"C:\USERAT\USERAT_Projeto_Completo\scripts\scripts 2",
r"C:\USERAT\USERAT_Projeto_Completo\scripts\scripts 2\compiladao",
r"C:\USERAT\USERAT_Projeto_Completo\tutoriais",
r"C:\USERAT1",
r"C:\ACESSO A PASTA WINAPP\1",
r"C:\USERAT1\USERAT_Final_Atualizado",
r"C:\USERAT1\USERAT_Final_Atualizado\scripts",
r"C:\USERAT2",
r"C:\USERAT2\RAR USERASTS\USERAT_Final_Atualizado",
r"C:\USERAT2\RAR USERASTS\USERAT_Final_Atualizado\scripts",
r"C:\USERAT2\scripts",
r"C:\USERAT2\SCRPITS PS1",
r"C:\USERAT2\USERAT_Final_Atualizado",
r"C:\TESTEE 2",
r"C:\TESTEE 2\A3",
r"C:\TESTEE 2\AI_Trade_Suite",
r"C:\TESTEE 2\ARQUIVOS",
r"C:\TESTEE 2\ARQUIVOS\2 ADVANCED",
r"C:\TESTEE 3\AI_Trade_Suite_Full_Deliverable",
r"C:\TST DE API E SOFT\ai trade suite\AI_Trade_Suite",
r"C:\AAAAAAAA",
r"C:\AAAAAAAA\AI_Trade_Suite_Expanded (3)",
r"C:\UNIC QUANTIC",
r"C:\UNIC QUANTIC\$",
r"C:\UNIC QUANTIC\backend",
r"C:\UNIC QUANTIC\database",
r"C:\UNIC QUANTIC\frontend",
r"C:\UNIC QUANTIC\logs",
r"C:\UNIC QUANTIC\pdfs",
r"C:\UNIC QUANTIC\scripts",
r"C:\UNIC QUANTIC\scripts\SCRIPTS OPCIONAIS",
r"C:\UNIC QUANTIC\scripts\SETUP UNIC PARTE 1",
r"C:\UNIC QUANTIC\tools",
r"C:\Users\arati\OneDrive\Área de Trabalho\1",
]

# -------------------------
# Helpers
# -------------------------
LOGFILE = PASTA_LOGS / f"fullone_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"

def log(msg, level="INFO"):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}][{level}] {msg}"
    print(line)
    try:
        with open(LOGFILE, "a", encoding="utf-8") as lf:
            lf.write(line + "\n")
    except Exception:
        pass

def ensure_dir(p: Path):
    try:
        p.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

def read_text_try_encodings(path: Path):
    for enc in ("utf-8","cp1252","latin-1"):
        try:
            return path.read_text(encoding=enc), enc
        except Exception:
            continue
    try:
        data = path.read_bytes()
        return data.decode("utf-8", errors="ignore"), "utf-8-ignore"
    except Exception:
        return None, None

def extract_version(text: str):
    if not text:
        return None
    patterns = [
        r'(?i)version\s*[:=]\s*([\w\.\-]+)',
        r'(?i)vers[oã]o\s*[:=]\s*([\w\.\-]+)',
        r'(?i)\bv\s?(\d+\.\d+(?:\.\d+)*)\b'
    ]
    for p in patterns:
        m = re.search(p, text)
        if m:
            return m.group(1)
    return None

def cmp_versions(a, b):
    # returns 1 if a>b, -1 if a<b, 0 equal (numeric parts)
    if a is None and b is None: return 0
    if a is None: return -1
    if b is None: return 1
    parts_a = [int(x) for x in re.findall(r'\d+', a)]
    parts_b = [int(x) for x in re.findall(r'\d+', b)]
    la, lb = len(parts_a), len(parts_b)
    for i in range(max(la, lb)):
        va = parts_a[i] if i < la else 0
        vb = parts_b[i] if i < lb else 0
        if va > vb: return 1
        if va < vb: return -1
    return 0

# -------------------------
# Core functions
# -------------------------
def find_scripts(paths):
    found = []
    for p in paths:
        pth = Path(p)
        if not pth.exists():
            log(f"Search path not found (skipped): {p}", "WARN")
            continue
        for ext in ("*.ps1","*.py"):
            for f in pth.rglob(ext):
                if f.is_file():
                    found.append(f.resolve())
    return found

def choose_latest_by_name(files):
    byname = {}
    for f in files:
        key = f.name.lower()
        txt, enc = read_text_try_encodings(f)
        ver = extract_version(txt) if txt else None
        mtime = f.stat().st_mtime
        if key not in byname:
            byname[key] = (f, ver, mtime)
        else:
            existing = byname[key]
            # prefer explicit version
            if ver and existing[1]:
                c = cmp_versions(ver, existing[1])
                if c > 0:
                    byname[key] = (f, ver, mtime)
                elif c == 0 and mtime > existing[2]:
                    byname[key] = (f, ver, mtime)
            elif ver and not existing[1]:
                byname[key] = (f, ver, mtime)
            elif not ver and existing[1]:
                # keep existing which has explicit version
                pass
            else:
                # no version info on both, pick latest mtime
                if mtime > existing[2]:
                    byname[key] = (f, ver, mtime)
    selected = [v[0] for v in byname.values()]
    return selected, byname

def create_unified(selected_files, out_dir: Path):
    ensure_dir(out_dir)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    unified_name = f"ONEFULL_{VERSAO_FULLONE}_{ts}.ps1"
    unified_path = out_dir / unified_name
    try:
        with open(unified_path, "w", encoding="utf-8") as out:
            out.write(f"# ONEFULL unified - {VERSAO_FULLONE}\n")
            out.write(f"# Generated: {datetime.now().isoformat()}\n\n")
            for f in selected_files:
                txt, enc = read_text_try_encodings(f)
                out.write("#" * 70 + "\n")
                out.write(f"# START: {f}\n")
                out.write("#" * 70 + "\n")
                if f.suffix.lower() == ".py":
                    out.write(f"<# PYTHON SOURCE START: {f.name} #>\n")
                    out.write(txt if txt else "")
                    out.write(f"\n<# PYTHON SOURCE END: {f.name} #>\n\n")
                else:
                    out.write(txt if txt else "")
                    out.write("\n\n")
        # create stable copy ONEFULL.ps1
        stable = out_dir / "ONEFULL.ps1"
        try:
            shutil.copy2(unified_path, stable)
        except Exception:
            pass
        log(f"Unified created: {unified_path}", "OK")
        return unified_path, stable
    except Exception as e:
        log(f"Failed to create unified: {e}", "ERROR")
        return None, None

def write_txt_refs(selected_files, txt_dir: Path):
    ensure_dir(txt_dir)
    txt_paths = []
    for f in selected_files:
        try:
            txt, enc = read_text_try_encodings(f)
            dest = txt_dir / (f.name + ".txt")
            with open(dest, "w", encoding="utf-8") as w:
                w.write(f"# Reference of: {f}\n# encoding: {enc}\n\n")
                if txt:
                    w.write(txt)
            txt_paths.append(dest)
        except Exception as e:
            log(f"Failed txt ref for {f}: {e}", "WARN")
    return txt_paths

def make_zip(unified_file: Path, txt_refs, extras, out_dir: Path):
    ensure_dir(out_dir)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_name = f"{VERSAO_FULLONE}_{ts}.zip"
    zip_path = out_dir / zip_name
    try:
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            if unified_file and unified_file.exists():
                zf.write(unified_file, arcname=f"UNIFIED/{unified_file.name}")
            for t in txt_refs or []:
                if t.exists(): zf.write(t, arcname=f"REFERENCE_TXT/{t.name}")
            for e in extras or []:
                if e.exists(): zf.write(e, arcname=f"EXTRAS/{e.name}")
            # include the generator itself if available
            try:
                selfpath = Path(__file__).resolve()
                zf.write(selfpath, arcname=f"TOOLS/{selfpath.name}")
            except Exception:
                pass
        log(f"ZIP created: {zip_path}", "OK")
        return zip_path
    except Exception as e:
        log(f"ZIP failed: {e}", "ERROR")
        return None

def generate_diagram(png_out_dir: Path):
    ensure_dir(png_out_dir)
    base = png_out_dir / ("flow_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
    png_path = base.with_suffix(".png")
    if HAVE_GRAPHVIZ:
        try:
            dot = graphviz.Digraph(comment='FULLONE Flow')
            dot.attr(rankdir='LR', size='8,3')
            dot.node('start','Start', shape='ellipse')
            dot.node('scan','Scan .ps1 & .py', shape='box')
            dot.node('dedup','Deduplicate / Select latest', shape='box')
            dot.node('unify','Unify into ONEFULL', shape='box')
            dot.node('txt','Create .txt refs', shape='box')
            dot.node('zip','Create ZIP package', shape='box')
            dot.node('pdf','Generate PDF report', shape='box')
            dot.edges([('start','scan'),('scan','dedup'),('dedup','unify'),('unify','txt'),('txt','zip'),('zip','pdf')])
            dot.render(str(base), format='png', cleanup=True)
            if png_path.exists():
                log("Diagram generated via Graphviz", "OK")
                return png_path
        except Exception as e:
            log(f"Graphviz render failed: {e}", "WARN")
    # fallback to simple PIL drawing
    if HAVE_PIL:
        try:
            img = Image.new('RGB', (1200, 250), color=(18,18,30))
            draw = ImageDraw.Draw(img)
            try:
                fnt = ImageFont.truetype("arial.ttf", 16)
            except Exception:
                fnt = ImageFont.load_default()
            text = "FULLONE Flow: Scan -> Dedup -> Unify -> TXT -> ZIP -> PDF"
            draw.text((20,20), text, fill=(220,220,255), font=fnt)
            # simple boxes
            steps = ["Scan", "Dedup", "Unify", "TXT", "ZIP", "PDF"]
            x = 20
            y = 80
            for s in steps:
                draw.rectangle([x,y,x+160,y+50], outline=(100,200,250))
                w,h = draw.textsize(s, font=fnt)
                draw.text((x+80-w/2, y+25-h/2), s, fill=(200,240,255), font=fnt)
                x += 180
            img.save(png_path)
            log("Diagram generated via PIL fallback", "OK")
            return png_path
        except Exception as e:
            log(f"PIL diagram failed: {e}", "WARN")
    # last resort: create empty file
    try:
        png_path.write_bytes(b"")
    except Exception:
        pass
    return png_path

def generate_pdf(all_files, selected_files, unified_file: Path, zip_file: Path, diagram_png: Path, txt_refs, out_dir: Path):
    ensure_dir(out_dir)
    pdf_name = f"{VERSAO_FULLONE}_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    pdf_path = out_dir / pdf_name
    pdf = FPDF(orientation='P', unit='mm', format='A4')
    pdf.set_auto_page_break(auto=True, margin=12)
    pdf.add_page()
    pdf.set_font("Arial", "B", 16)
    pdf.cell(0, 10, f"FULLONE Report - {VERSAO_FULLONE}", ln=True, align="C")
    pdf.ln(4)
    total = len(all_files)
    ps1_total = len([x for x in all_files if x.suffix.lower() == ".ps1"])
    py_total = len([x for x in all_files if x.suffix.lower() == ".py"])
    sel_total = len(selected_files)
    pdf.set_font("Arial", "", 11)
    pdf.multi_cell(0, 6, (f"Scan summary:\nTotal files found: {total}\n"
                         f"PS1 found: {ps1_total}\nPY found: {py_total}\n"
                         f"Selected (latest per name): {sel_total}\n\n"
                         f"Unified: {unified_file.name if unified_file else 'N/A'}\n"
                         f"ZIP: {zip_file.name if zip_file else 'N/A'}\n"))
    pdf.ln(4)
    # Diagram
    try:
        if diagram_png and diagram_png.exists():
            pdf.set_font("Arial", "B", 12)
            pdf.cell(0, 6, "Process Diagram", ln=True)
            pdf.image(str(diagram_png), w=170)
            pdf.ln(3)
    except Exception:
        pdf.set_font("Arial", "", 10)
        pdf.cell(0, 6, "(diagram not available)", ln=True)
    # Sample selected file names
    pdf.set_font("Arial", "B", 12)
    pdf.cell(0, 6, "Selected files (sample):", ln=True)
    pdf.set_font("Arial", "", 10)
    sample_names = [s.name for s in selected_files[:60]]
    pdf.multi_cell(0, 5, " ; ".join(sample_names))
    pdf.ln(4)
    # Quick tutorial
    pdf.set_font("Arial", "B", 12)
    pdf.cell(0, 6, "Quick tutorial", ln=True)
    pdf.set_font("Arial", "", 10)
    pdf.multi_cell(0, 5, ("This tool searches configured folders for .ps1 and .py files, chooses the latest version\n"
                         "for each filename (preferring embedded version stamps when present), unifies them into a\n"
                         "ONEFULL.ps1, produces .txt reference copies and packages everything into a ZIP.\n"))
    pdf.add_page()
    # Appendix: snippets
    pdf.set_font("Arial", "B", 12)
    pdf.cell(0, 6, "Appendix: file snippets (first ~1200 chars)", ln=True)
    pdf.set_font("Arial", "", 9)
    for f in selected_files[:40]:
        try:
            txt, enc = read_text_try_encodings(f)
            snippet = (txt[:1200] + "...") if txt and len(txt) > 1200 else (txt or "")
            pdf.set_font("Arial", "B", 10)
            pdf.cell(0, 5, f"{f.name} ({enc})", ln=True)
            pdf.set_font("Arial", "", 8)
            pdf.multi_cell(0, 4, snippet)
            pdf.ln(2)
        except Exception:
            continue
    # Save PDF
    try:
        pdf.output(str(pdf_path))
        log(f"PDF generated: {pdf_path}", "OK")
    except Exception as e:
        log(f"PDF generation failed: {e}", "WARN")
    return pdf_path

# -------------------------
# Auto-update generator from OFFICIAL folder (optional)
# -------------------------
def auto_update_generator():
    official = PASTA_OFFICIAL / "criar-pacotes.py"
    exec_target = PASTA_EXEC / "criar-pacotes.py"
    if not official.exists():
        log("No official creator found (auto-update skip).", "INFO")
        return
    try:
        if not exec_target.exists() or official.read_bytes() != exec_target.read_bytes():
            # backup existing
            if exec_target.exists():
                bkp = exec_target.with_name(exec_target.stem + "_backup_" + datetime.now().strftime("%Y%m%d_%H%M%S") + exec_target.suffix)
                shutil.copy2(exec_target, bkp)
                log(f"Backup of generator saved: {bkp}", "OK")
            shutil.copy2(official, exec_target)
            log("Generator auto-updated from OFFICIAL.", "OK")
    except Exception as e:
        log(f"Auto-update failed: {e}", "WARN")

# -------------------------
# Main
# -------------------------
def main(test_mode=False):
    log(f"FULLONE started. Mode test={test_mode}", "INFO")
    if not test_mode:
        auto_update_generator()
        # find scripts
        all_files = find_scripts(SEARCH_PATHS)
    else:
        # create local sample for testing
        tmp = Path.cwd() / "fullone_sample"
        ensure_dir(tmp)
        (tmp / "alpha.ps1").write_text("# version: 1.0\nWrite-Host 'alpha v1.0'\n", encoding="utf-8")
        (tmp / "alpha.py").write_text("# v1.1\nprint('alpha py v1.1')\n", encoding="utf-8")
        (tmp / "beta.ps1").write_text("# version: 0.9\nWrite-Host 'beta v0.9'\n", encoding="utf-8")
        all_files = list(tmp.rglob("*.ps1")) + list(tmp.rglob("*.py"))

    # stats
    total_count = len(all_files)
    ps1_count = len([f for f in all_files if f.suffix.lower() == ".ps1"])
    py_count = len([f for f in all_files if f.suffix.lower() == ".py"])
    log(f"Total scripts found across all search paths: {total_count}", "INFO")
    log(f"PS1: {ps1_count}, PY: {py_count}", "INFO")

    # pick latest per name
    selected, byname = choose_latest_by_name(all_files)
    log(f"Selected {len(selected)} files for unification (one per filename).", "INFO")

    # create unified ps1
    unified, stable = create_unified(selected, PASTA_UNIFICADOS if not test_mode else Path.cwd() / "out_unified")

    # write txt refs
    txt_refs = write_txt_refs(selected, PASTA_TXT_REF if not test_mode else Path.cwd() / "out_txts")

    # extras: add tutorial PDFs if exist in PASTA_EXEC
    extras = []
    for pdfn in ("TUTORIAL.pdf","GUIA-RÁPIDO.pdf","MANUAL.pdf"):
        p = PASTA_EXEC / pdfn
        if test_mode:
            # skip
            pass
        else:
            if p.exists(): extras.append(p)

    # make zip
    zipf = make_zip(unified, txt_refs, extras, PASTA_PACKAGE if not test_mode else Path.cwd() / "out_package")

    # generate diagram
    diagram = generate_diagram(PASTA_DIAGRAMA if not test_mode else Path.cwd() / "out_diagram")

    # generate PDF
    pdf = generate_pdf(all_files, selected, unified, zipf, diagram, txt_refs, PASTA_DIAGRAMA if not test_mode else Path.cwd() / "out_pdf")

    # final summary
    log("FULLONE finished.", "OK")
    log(f"Artifacts:\n - unified: {unified}\n - stable: {stable}\n - zip: {zipf}\n - pdf: {pdf}", "INFO")
    return {
        "unified": unified, "stable": stable, "zip": zipf, "pdf": pdf,
        "total": total_count, "ps1": ps1_count, "py": py_count, "selected": len(selected)
    }

if __name__ == "__main__":
    TEST = "--test" in sys.argv
    res = main(test_mode=TEST)
    # print a small console summary
    print("\n==== SUMMARY ====")
    print(f"Total scanned: {res['total']}")
    print(f".ps1 found: {res['ps1']}")
    print(f".py found: {res['py']}")
    print(f"Files selected for unify: {res['selected']}")
    print(f"Unified file: {res['unified']}")
    print(f"ZIP: {res['zip']}")
    print(f"PDF: {res['pdf']}")
    print("=================\n")


# ---- bloco ----

folders = [
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    # ...continua
]


# ---- bloco ----

r"C:\CONAV TRADER\",


# ---- bloco ----

r"C:\CONAV TRADER"


# ---- bloco ----

print("=== FULLONE finished ===")


# ---- bloco ----

print('=== FULLONE finished ===')


# ---- bloco ----

import os
import shutil
import zipfile
import difflib
from fpdf import FPDF
from datetime import datetime

# Função para buscar arquivos nas pastas especificadas
def buscar_arquivos(pastas):
    arquivos = []
    for pasta in pastas:
        for root, dirs, files in os.walk(pasta):
            for file in files:
                if file.endswith(('.ps1', '.py')):
                    arquivos.append(os.path.join(root, file))
    return arquivos

# Função para comparar dois arquivos e retornar as diferenças
def comparar_arquivos(arquivo1, arquivo2):
    with open(arquivo1, 'r', encoding='utf-8') as f1, open(arquivo2, 'r', encoding='utf-8') as f2:
        diff = difflib.unified_diff(f1.readlines(), f2.readlines(), fromfile=arquivo1, tofile=arquivo2)
        return ''.join(diff)

# Função para gerar o PDF com os comparativos
def gerar_pdf(comparativos, output_pdf):
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    for comparativo in comparativos:
        pdf.multi_cell(0, 10, comparativo)
    pdf.output(output_pdf)

# Função para criar o arquivo ZIP com o script unificado e backups
def criar_zip(arquivos, output_zip):
    with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for arquivo in arquivos:
            zipf.write(arquivo, os.path.basename(arquivo))

# Função principal
def main():
    pastas = [
        r"C:\CONAV TRADER",
        r"C:\CONAV TRADER\CONAV_TRADER\automation",
        r"C:\CONAV TRADER\CONAV_TRADER\build",
        r"C:\CONAV TRADER\CONAV_TRADER\build\automation",
        r"C:\CONAV TRADER\CONAV_TRADER\build\build",
        r"C:\CONAV TRADER\CONAV_TRADER\build\build\automation",
        r"C:\CONAV TRADER\CONAV_TRADER\build\build\build",
        r"C:\CONAV TRADER\CONAV_TRADER\build\build\build\automation",
        r"C:\CONAV TRADER\CONAV_TRADER\build\build\build\build",
        r"C:\CONAV TRADER\CONAV_TRADER\build\build\build\build\automation"
    ]
    arquivos = buscar_arquivos(pastas)
    comparativos = []
    for i in range(len(arquivos)):
        for j in range(i + 1, len(arquivos)):
            diff = comparar_arquivos(arquivos[i], arquivos[j])
            if diff:
                comparativos.append(diff)
    gerar_pdf(comparativos, "comparativos.pdf")
    criar_zip(arquivos, "arquivos.zip")

if __name__ == "__main__":
    main()


# ---- bloco ----

  import os
  import shutil
  import zipfile
  import difflib
  from fpdf import FPDF
  from datetime import datetime

  # Função para buscar arquivos nas pastas especificadas
  def buscar_arquivos(pastas):
      arquivos = []
      for pasta in pastas:
          for root, dirs, files in os.walk(pasta):
              for file in files:
                  if file.endswith(('.ps1', '.py')):
                      arquivos.append(os.path.join(root, file))
      return arquivos

  # Função para comparar dois arquivos e retornar as diferenças
  def comparar_arquivos(arquivo1, arquivo2):
      with open(arquivo1, 'r', encoding='utf-8') as f1, open(arquivo2, 'r', encoding='utf-8') as f2:
          diff = difflib.unified_diff(f1.readlines(), f2.readlines(), fromfile=arquivo1, tofile=arquivo2)
          return ''.join(diff)

  # Função para gerar o PDF com os comparativos
  def gerar_pdf(comparativos, output_pdf):
      pdf = FPDF()
      pdf.set_auto_page_break(auto=True, margin=15)
      pdf.add_page()
      pdf.set_font("Arial", size=12)
      for comparativo in comparativos:
          pdf.multi_cell(0, 10, comparativo)
      pdf.output(output_pdf)

  # Função para criar o arquivo ZIP com o script unificado e backups
  def criar_zip(arquivos, output_zip):
      with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
          for arquivo in arquivos:
              zipf.write(arquivo, os.path.basename(arquivo))

  # Função principal
  def main():
      pastas = [
          r"C:\CONAV TRADER",
          r"C:\CONAV TRADER\CONAV_TRADER\automation",
          r"C:\CONAV TRADER\CONAV_TRADER\build",
          r"C:\CONAV TRADER\CONAV_TRADER\build\automation",
          r"C:\CONAV TRADER\CONAV_TRADER\build\build",
          r"C:\CONAV TRADER\CONAV_TRADER\build\build\automation",
          r"C:\CONAV TRADER\CONAV_TRADER\build\build\build",
          r"C:\CONAV TRADER\CONAV_TRADER\build\build\build\automation",
          r"C:\CONAV TRADER\CONAV_TRADER\build\build\build\build",
          r"C:\CONAV TRADER\CONAV_TRADER\build\build\build\build\automation"
      ]
      arquivos = buscar_arquivos(pastas)
      comparativos = []
      for i in range(len(arquivos)):
          for j in range(i + 1, len(arquivos)):
              diff = comparar_arquivos(arquivos[i], arquivos[j])
              if diff:
                  comparativos.append(diff)
      gerar_pdf(comparativos, "comparativos.pdf")
      criar_zip(arquivos, "arquivos.zip")

  if __name__ == "__main__":
      main()
  

# ---- bloco ----

import os
import shutil
import zipfile
from pathlib import Path
from datetime import datetime
import glob
from fpdf import FPDF
import graphviz

# ===============================
# CONFIGURAÇÃO DE PASTAS E VERSÃO
# ===============================
VERSAO_FULLONE = "FULLONEv14fixed2"
PASTA_OFICIAL = r"C:\SCRIPTS\FULL ONE\OFFICIAL"
PASTA_EXEC = r"C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR"
PASTA_UNIFICADOS = r"C:\SCRIPTS\FULL ONE\ARQUIVOS .PS1 UNIFICADOS"
PASTA_PACKAGE = r"C:\SCRIPTS\FULL ONE\PACKAGE"
PASTA_DIAGRAMA = r"C:\SCRIPTS\FULL ONE\DIAGRAMA VISUAL"

# Pastas para buscar arquivos
PASTAS_PROCURA = [
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\UNIC QUANTIC\scripts",
]

NOME_UNIFICADO = "ONEFULL.ps1"

# ===============================
# FUNÇÕES
# ===============================

def atualizar_script_oficial():
    """Atualiza o script a partir da versão oficial"""
    arquivo_oficial = Path(PASTA_OFICIAL) / "criar-pacotes.py"
    arquivo_exec = Path(PASTA_EXEC) / "criar-pacotes.py"

    if not arquivo_oficial.exists():
        print(f"[AVISO] Nenhum arquivo oficial encontrado em: {PASTA_OFICIAL}")
        return

    atualizar = False
    if not arquivo_exec.exists():
        atualizar = True
    else:
        if arquivo_oficial.read_bytes() != arquivo_exec.read_bytes():
            atualizar = True

    if atualizar:
        if arquivo_exec.exists():
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = arquivo_exec.with_name(f"{arquivo_exec.stem}_backup_{timestamp}.py")
            shutil.copy2(arquivo_exec, backup_path)
            print(f"[INFO] Backup do script antigo salvo: {backup_path}")

        shutil.copy2(arquivo_oficial, arquivo_exec)
        print("[INFO] Script atualizado automaticamente.")

def buscar_arquivos():
    """Busca arquivos .PS1 e .PY em todas as pastas"""
    todos_arquivos = []
    for pasta in PASTAS_PROCURA:
        path_pasta = Path(pasta)
        if path_pasta.exists():
            for ext in ("*.ps1", "*.py"):
                encontrados = list(path_pasta.rglob(ext))
                todos_arquivos.extend(encontrados)
    return todos_arquivos

def selecionar_versao_recente(arquivos):
    """Seleciona a versão mais recente dos arquivos com mesmo nome"""
    arquivos_dict = {}
    for arquivo in arquivos:
        nome = arquivo.name
        if nome not in arquivos_dict:
            arquivos_dict[nome] = arquivo
        else:
            # Prioriza mais recente pela data de modificação
            if arquivo.stat().st_mtime > arquivos_dict[nome].stat().st_mtime:
                arquivos_dict[nome] = arquivo
    return list(arquivos_dict.values())

def criar_unificado(arquivos, pasta_saida):
    """Cria arquivo PS1 unificado"""
    os.makedirs(pasta_saida, exist_ok=True)
    unificado_path = Path(pasta_saida) / NOME_UNIFICADO

    if unificado_path.exists():
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = unificado_path.with_name(f"{unificado_path.stem}_backup_{timestamp}.ps1")
        shutil.move(unificado_path, backup_path)
        print(f"[INFO] Backup do PS1 unificado antigo: {backup_path}")

    with open(unificado_path, "w", encoding="utf-8") as f:
        f.write(f"# FULLONE Unificado - Versão {VERSAO_FULLONE}\n")
        f.write(f"# Gerado em {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        for arquivo in arquivos:
            try:
                with open(arquivo, "r", encoding="utf-8") as af:
                    conteudo = af.read()
                f.write(f"# ===== INICIO {arquivo.name} =====\n")
                f.write(conteudo + "\n")
                f.write(f"# ===== FIM {arquivo.name} =====\n\n")
            except Exception as e:
                print(f"[ERRO] Não foi possível ler {arquivo}: {e}")
    print(f"[INFO] PS1 unificado criado: {unificado_path}")
    return unificado_path

def criar_zip(unificado_path, todos_arquivos):
    """Cria ZIP incremental com scripts e PDFs"""
    os.makedirs(PASTA_PACKAGE, exist_ok=True)
    contador = 1
    while True:
        zip_name = f"{VERSAO_FULLONE}_{contador:04d}.zip"
        zip_path = Path(PASTA_PACKAGE) / zip_name
        if not zip_path.exists():
            break
        contador += 1

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(unificado_path, arcname=unificado_path.name)
        for arquivo in todos_arquivos:
            zf.write(arquivo, arcname=arquivo.name)
    print(f"[INFO] ZIP criado: {zip_path}")
    return zip_path

def gerar_fluxograma():
    """Gera fluxograma Graphviz"""
    dot = graphviz.Digraph(comment='FULLONE Fluxograma')
    dot.node('A', 'Início')
    dot.node('B', 'Busca arquivos')
    dot.node('C', 'Seleciona versão recente')
    dot.node('D', 'Unifica PS1')
    dot.node('E', 'Cria ZIP')
    dot.node('F', 'Gera PDF')
    dot.edges(['AB', 'BC', 'CD', 'DE', 'DF'])
    diagram_path = Path(PASTA_DIAGRAMA) / f"FULLONE_Fluxograma_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    os.makedirs(PASTA_DIAGRAMA, exist_ok=True)
    dot.render(str(diagram_path), format='png', cleanup=True)
    return str(diagram_path) + ".png"

def gerar_pdf(todos_arquivos, unificado_path, zip_path, fluxograma_path):
    """Gera PDF detalhado"""
    os.makedirs(PASTA_DIAGRAMA, exist_ok=True)
    pdf_path = Path(PASTA_DIAGRAMA) / f"{VERSAO_FULLONE}_relatorio_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", "B", 16)
    pdf.set_text_color(0, 0, 128)
    pdf.cell(0, 10, f"FULLONE Relatório - {VERSAO_FULLONE}", ln=True, align="C")
    pdf.ln(5)

    # Estatísticas
    ps1_count = len([f for f in todos_arquivos if f.suffix.lower() == ".ps1"])
    py_count = len([f for f in todos_arquivos if f.suffix.lower() == ".py"])
    pdf.set_font("Arial", "", 12)
    pdf.set_text_color(0, 0, 0)
    pdf.multi_cell(0, 6, f"Total de arquivos encontrados: {len(todos_arquivos)}\n"
                          f"Arquivos .PS1: {ps1_count}\n"
                          f"Arquivos .PY: {py_count}\n"
                          f"Arquivo PS1 unificado: {unificado_path}\n"
                          f"ZIP gerado: {zip_path}\n")
    pdf.ln(5)

    # Fluxograma
    pdf.set_font("Arial", "B", 14)
    pdf.set_text_color(0, 128, 0)
    pdf.cell(0, 10, "Fluxograma do processo", ln=True)
    pdf.image(fluxograma_path, w=180)
    pdf.ln(5)

    # Lista arquivos
    pdf.set_font("Arial", "B", 12)
    pdf.set_text_color(128, 0, 0)
    pdf.cell(0, 8, "Lista de arquivos encontrados:", ln=True)
    pdf.set_font("Arial", "", 10)
    for f in todos_arquivos:
        pdf.multi_cell(0, 5, str(f))
    pdf.output(pdf_path)
    print(f"[INFO] PDF gerado: {pdf_path}")
    return pdf_path

# ===============================
# EXECUÇÃO PRINCIPAL
# ===============================
if __name__ == "__main__":
    print("=== FULLONE - GERADOR AUTÔNOMO AVANÇADO ===\n")
    atualizar_script_oficial()

    todos_arquivos = buscar_arquivos()
    print(f"[INFO] Total arquivos encontrados: {len(todos_arquivos)}")
    print(f"[INFO] Arquivos .PS1: {len([f for f in todos_arquivos if f.suffix.lower()=='.ps1'])}")
    print(f"[INFO] Arquivos .PY: {len([f for f in todos_arquivos if f.suffix.lower()=='.py'])}")

    arquivos_recente = selecionar_versao_recente(todos_arquivos)
    print(f"[INFO] Arquivos selecionados (versão recente): {len(arquivos_recente)}")

    unificado_path = criar_unificado(arquivos_recente, PASTA_UNIFICADOS)
    zip_path = criar_zip(unificado_path, arquivos_recente)
    fluxograma_path = gerar_fluxograma()
    pdf_path = gerar_pdf(arquivos_recente, unificado_path, zip_path, fluxograma_path)

    print("=== FULLONE finalizado com sucesso! ===")


# ---- bloco ----

import os
import shutil
import zipfile
from pathlib import Path
from datetime import datetime
from fpdf import FPDF, XPos, YPos
import graphviz

# ===============================
# CONFIGURAÇÃO DE PASTAS E VERSÃO
# ===============================
VERSAO_FULLONE = "FULLONEv14fixed3"
PASTA_OFICIAL = r"C:\SCRIPTS\FULL ONE\OFFICIAL"
PASTA_EXEC = r"C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR"
PASTA_UNIFICADOS = r"C:\SCRIPTS\FULL ONE\ARQUIVOS .PS1 UNIFICADOS"
PASTA_PACKAGE = r"C:\SCRIPTS\FULL ONE\PACKAGE"
PASTA_DIAGRAMA = r"C:\SCRIPTS\FULL ONE\DIAGRAMA VISUAL"

# Pastas para buscar arquivos
PASTAS_PROCURA = [
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\UNIC QUANTIC\scripts",
]

NOME_UNIFICADO = "ONEFULL.ps1"

# ===============================
# FUNÇÕES
# ===============================

def atualizar_script_oficial():
    """Atualiza o script a partir da versão oficial"""
    arquivo_oficial = Path(PASTA_OFICIAL) / "criar-pacotes.py"
    arquivo_exec = Path(PASTA_EXEC) / "criar-pacotes.py"

    if not arquivo_oficial.exists():
        print(f"[AVISO] Nenhum arquivo oficial encontrado em: {PASTA_OFICIAL}")
        arquivo_oficial.touch()
        return

    atualizar = False
    if not arquivo_exec.exists():
        atualizar = True
    else:
        if arquivo_oficial.read_bytes() != arquivo_exec.read_bytes():
            atualizar = True

    if atualizar:
        if arquivo_exec.exists():
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = arquivo_exec.with_name(f"{arquivo_exec.stem}_backup_{timestamp}.py")
            shutil.copy2(arquivo_exec, backup_path)
            print(f"[INFO] Backup do script antigo salvo: {backup_path}")

        shutil.copy2(arquivo_oficial, arquivo_exec)
        print("[INFO] Script atualizado automaticamente.")

def buscar_arquivos():
    """Busca arquivos .PS1 e .PY em todas as pastas"""
    todos_arquivos = []
    for pasta in PASTAS_PROCURA:
        path_pasta = Path(pasta)
        if path_pasta.exists():
            for ext in ("*.ps1", "*.py"):
                encontrados = list(path_pasta.rglob(ext))
                todos_arquivos.extend(encontrados)
    return todos_arquivos

def selecionar_versao_recente(arquivos):
    """Seleciona a versão mais recente dos arquivos com mesmo nome"""
    arquivos_dict = {}
    for arquivo in arquivos:
        nome = arquivo.name
        if nome not in arquivos_dict:
            arquivos_dict[nome] = arquivo
        else:
            if arquivo.stat().st_mtime > arquivos_dict[nome].stat().st_mtime:
                arquivos_dict[nome] = arquivo
    return list(arquivos_dict.values())

def criar_unificado(arquivos, pasta_saida):
    """Cria arquivo PS1 unificado"""
    os.makedirs(pasta_saida, exist_ok=True)
    unificado_path = Path(pasta_saida) / NOME_UNIFICADO

    if unificado_path.exists():
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = unificado_path.with_name(f"{unificado_path.stem}_backup_{timestamp}.ps1")
        shutil.move(unificado_path, backup_path)
        print(f"[INFO] Backup do PS1 unificado antigo: {backup_path}")

    with open(unificado_path, "w", encoding="utf-8") as f:
        f.write(f"# FULLONE Unificado - Versão {VERSAO_FULLONE}\n")
        f.write(f"# Gerado em {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        for arquivo in arquivos:
            try:
                with open(arquivo, "r", encoding="utf-8") as af:
                    conteudo = af.read()
                f.write(f"# ===== INICIO {arquivo.name} =====\n")
                f.write(conteudo + "\n")
                f.write(f"# ===== FIM {arquivo.name} =====\n\n")
            except Exception as e:
                print(f"[ERRO] Não foi possível ler {arquivo}: {e}")
    print(f"[INFO] PS1 unificado criado: {unificado_path}")
    return unificado_path

def criar_zip(unificado_path, todos_arquivos):
    """Cria ZIP incremental"""
    os.makedirs(PASTA_PACKAGE, exist_ok=True)
    contador = 1
    while True:
        zip_name = f"{VERSAO_FULLONE}_{contador:04d}.zip"
        zip_path = Path(PASTA_PACKAGE) / zip_name
        if not zip_path.exists():
            break
        contador += 1

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(unificado_path, arcname=unificado_path.name)
        for arquivo in todos_arquivos:
            zf.write(arquivo, arcname=arquivo.name)
    print(f"[INFO] ZIP criado: {zip_path}")
    return zip_path

def gerar_fluxograma():
    dot = graphviz.Digraph(comment='FULLONE Fluxograma')
    dot.node('A', 'Início')
    dot.node('B', 'Busca arquivos')
    dot.node('C', 'Seleciona versão recente')
    dot.node('D', 'Unifica PS1')
    dot.node('E', 'Cria ZIP')
    dot.node('F', 'Gera PDF')
    dot.edges(['AB', 'BC', 'CD', 'DE', 'DF'])
    diagram_path = Path(PASTA_DIAGRAMA) / f"FULLONE_Fluxograma_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    os.makedirs(PASTA_DIAGRAMA, exist_ok=True)
    dot.render(str(diagram_path), format='png', cleanup=True)
    return str(diagram_path) + ".png"

def gerar_pdf(todos_arquivos, unificado_path, zip_path, fluxograma_path):
    """Gera PDF detalhado"""
    os.makedirs(PASTA_DIAGRAMA, exist_ok=True)
    pdf_path = Path(PASTA_DIAGRAMA) / f"{VERSAO_FULLONE}_relatorio_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Helvetica", "B", 16)
    pdf.set_text_color(0, 0, 128)
    pdf.cell(0, 10, f"FULLONE Relatório - {VERSAO_FULLONE}", new_x=XPos.LMARGIN, new_y=YPos.NEXT, align="C")
    pdf.ln(5)

    ps1_count = len([f for f in todos_arquivos if f.suffix.lower() == ".ps1"])
    py_count = len([f for f in todos_arquivos if f.suffix.lower() == ".py"])
    pdf.set_font("Helvetica", "", 12)
    pdf.set_text_color(0, 0, 0)
    pdf.multi_cell(0, 6, f"Total de arquivos encontrados: {len(todos_arquivos)}\n"
                          f"Arquivos .PS1: {ps1_count}\n"
                          f"Arquivos .PY: {py_count}\n"
                          f"Arquivo PS1 unificado: {unificado_path}\n"
                          f"ZIP gerado: {zip_path}\n")
    pdf.ln(5)

    pdf.set_font("Helvetica", "B", 14)
    pdf.set_text_color(0, 128, 0)
    pdf.cell(0, 10, "Fluxograma do processo", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.image(fluxograma_path, w=180)
    pdf.ln(5)

    pdf.set_font("Helvetica", "B", 12)
    pdf.set_text_color(128, 0, 0)
    pdf.cell(0, 8, "Lista de arquivos encontrados:", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_font("Helvetica", "", 10)

    # Quebra de linha para caminhos muito longos
    for f in todos_arquivos:
        caminho = str(f)
        while len(caminho) > 95:
            pdf.multi_cell(0, 5, caminho[:95])
            caminho = caminho[95:]
        pdf.multi_cell(0, 5, caminho)

    pdf.output(pdf_path)
    print(f"[INFO] PDF gerado: {pdf_path}")
    return pdf_path

# ===============================
# EXECUÇÃO PRINCIPAL
# ===============================
if __name__ == "__main__":
    print("=== FULLONE - GERADOR AUTÔNOMO AVANÇADO ===\n")
    atualizar_script_oficial()

    todos_arquivos = buscar_arquivos()
    print(f"[INFO] Total arquivos encontrados: {len(todos_arquivos)}")
    print(f"[INFO] Arquivos .PS1: {len([f for f in todos_arquivos if f.suffix.lower()=='.ps1'])}")
    print(f"[INFO] Arquivos .PY: {len([f for f in todos_arquivos if f.suffix.lower()=='.py'])}")

    arquivos_recente = selecionar_versao_recente(todos_arquivos)
    print(f"[INFO] Arquivos selecionados (versão recente): {len(arquivos_recente)}")

    unificado_path = criar_unificado(arquivos_recente, PASTA_UNIFICADOS)
    zip_path = criar_zip(unificado_path, arquivos_recente)
    fluxograma_path = gerar_fluxograma()
    pdf_path = gerar_pdf(arquivos_recente, unificado_path, zip_path, fluxograma_path)

    print("=== FULLONE finalizado com sucesso! ===")


# ---- bloco ----

def gerar_pdf(todos_arquivos, unificado_path, zip_path, fluxograma_path):
    """Gera PDF detalhado"""
    os.makedirs(PASTA_DIAGRAMA, exist_ok=True)
    pdf_path = Path(PASTA_DIAGRAMA) / f"{VERSAO_FULLONE}_relatorio_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Helvetica", "B", 16)
    pdf.set_text_color(0, 0, 128)
    pdf.cell(0, 10, f"FULLONE Relatório - {VERSAO_FULLONE}", new_x=XPos.LMARGIN, new_y=YPos.NEXT, align="C")
    pdf.ln(5)

    ps1_count = len([f for f in todos_arquivos if f.suffix.lower() == ".ps1"])
    py_count = len([f for f in todos_arquivos if f.suffix.lower() == ".py"])
    pdf.set_font("Helvetica", "", 12)
    pdf.set_text_color(0, 0, 0)
    pdf.multi_cell(0, 6, f"Total de arquivos encontrados: {len(todos_arquivos)}\n"
                          f"Arquivos .PS1: {ps1_count}\n"
                          f"Arquivos .PY: {py_count}\n"
                          f"Arquivo PS1 unificado: {unificado_path}\n"
                          f"ZIP gerado: {zip_path}\n")
    pdf.ln(5)

    pdf.set_font("Helvetica", "B", 14)
    pdf.set_text_color(0, 128, 0)
    pdf.cell(0, 10, "Fluxograma do processo", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    if os.path.exists(fluxograma_path):
        pdf.image(fluxograma_path, w=180)
    pdf.ln(5)

    pdf.set_font("Helvetica", "B", 12)
    pdf.set_text_color(128, 0, 0)
    pdf.cell(0, 8, "Lista de arquivos encontrados:", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_font("Helvetica", "", 10)

    # Quebra de linha segura para caminhos longos
    max_len = 95
    for f in todos_arquivos:
        caminho = str(f)
        while len(caminho) > max_len:
            pdf.multi_cell(0, 5, caminho[:max_len])
            caminho = caminho[max_len:]
        pdf.multi_cell(0, 5, caminho)

    pdf.output(pdf_path)
    print(f"[INFO] PDF gerado: {pdf_path}")
    return pdf_path


# ---- bloco ----

import os
import shutil
import zipfile
from pathlib import Path
from datetime import datetime
from fpdf import FPDF, XPos, YPos
import graphviz

# ===============================
# CONFIGURAÇÃO DE PASTAS E VERSÃO
# ===============================
VERSAO_FULLONE = "FULLONEv14fixed4"
PASTA_OFICIAL = r"C:\SCRIPTS\FULL ONE\OFFICIAL"
PASTA_EXEC = r"C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR"
PASTA_UNIFICADOS = r"C:\SCRIPTS\FULL ONE\ARQUIVOS .PS1 UNIFICADOS"
PASTA_PACKAGE = r"C:\SCRIPTS\FULL ONE\PACKAGE"
PASTA_DIAGRAMA = r"C:\SCRIPTS\FULL ONE\DIAGRAMA VISUAL"

# Pastas para buscar arquivos
PASTAS_PROCURA = [
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\UNIC QUANTIC\scripts",
]

NOME_UNIFICADO = "ONEFULL.ps1"

# ===============================
# FUNÇÕES
# ===============================

def atualizar_script_oficial():
    arquivo_oficial = Path(PASTA_OFICIAL) / "criar-pacotes.py"
    arquivo_exec = Path(PASTA_EXEC) / "criar-pacotes.py"

    if not arquivo_oficial.exists():
        print(f"[AVISO] Nenhum arquivo oficial encontrado em: {PASTA_OFICIAL}")
        arquivo_oficial.touch()
        return

    atualizar = False
    if not arquivo_exec.exists():
        atualizar = True
    else:
        if arquivo_oficial.read_bytes() != arquivo_exec.read_bytes():
            atualizar = True

    if atualizar:
        if arquivo_exec.exists():
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = arquivo_exec.with_name(f"{arquivo_exec.stem}_backup_{timestamp}.py")
            shutil.copy2(arquivo_exec, backup_path)
            print(f"[INFO] Backup do script antigo salvo: {backup_path}")

        shutil.copy2(arquivo_oficial, arquivo_exec)
        print("[INFO] Script atualizado automaticamente.")

def buscar_arquivos():
    todos_arquivos = []
    for pasta in PASTAS_PROCURA:
        path_pasta = Path(pasta)
        if path_pasta.exists():
            for ext in ("*.ps1", "*.py"):
                encontrados = list(path_pasta.rglob(ext))
                todos_arquivos.extend(encontrados)
    return todos_arquivos

def selecionar_versao_recente(arquivos):
    arquivos_dict = {}
    for arquivo in arquivos:
        nome = arquivo.name
        if nome not in arquivos_dict:
            arquivos_dict[nome] = arquivo
        else:
            if arquivo.stat().st_mtime > arquivos_dict[nome].stat().st_mtime:
                arquivos_dict[nome] = arquivo
    return list(arquivos_dict.values())

def criar_unificado(arquivos, pasta_saida):
    os.makedirs(pasta_saida, exist_ok=True)
    unificado_path = Path(pasta_saida) / NOME_UNIFICADO

    if unificado_path.exists():
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = unificado_path.with_name(f"{unificado_path.stem}_backup_{timestamp}.ps1")
        shutil.move(unificado_path, backup_path)
        print(f"[INFO] Backup do PS1 unificado antigo: {backup_path}")

    with open(unificado_path, "w", encoding="utf-8") as f:
        f.write(f"# FULLONE Unificado - Versão {VERSAO_FULLONE}\n")
        f.write(f"# Gerado em {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        for arquivo in arquivos:
            try:
                with open(arquivo, "r", encoding="utf-8") as af:
                    conteudo = af.read()
                f.write(f"# ===== INICIO {arquivo.name} =====\n")
                f.write(conteudo + "\n")
                f.write(f"# ===== FIM {arquivo.name} =====\n\n")
            except Exception as e:
                print(f"[ERRO] Não foi possível ler {arquivo}: {e}")
    print(f"[INFO] PS1 unificado criado: {unificado_path}")
    return unificado_path

def criar_zip(unificado_path, todos_arquivos):
    os.makedirs(PASTA_PACKAGE, exist_ok=True)
    contador = 1
    while True:
        zip_name = f"{VERSAO_FULLONE}_{contador:04d}.zip"
        zip_path = Path(PASTA_PACKAGE) / zip_name
        if not zip_path.exists():
            break
        contador += 1

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(unificado_path, arcname=unificado_path.name)
        for arquivo in todos_arquivos:
            zf.write(arquivo, arcname=arquivo.name)
    print(f"[INFO] ZIP criado: {zip_path}")
    return zip_path

def gerar_fluxograma():
    dot = graphviz.Digraph(comment='FULLONE Fluxograma')
    dot.node('A', 'Início')
    dot.node('B', 'Busca arquivos')
    dot.node('C', 'Seleciona versão recente')
    dot.node('D', 'Unifica PS1')
    dot.node('E', 'Cria ZIP')
    dot.node('F', 'Gera PDF')
    dot.edges(['AB', 'BC', 'CD', 'DE', 'DF'])
    diagram_path = Path(PASTA_DIAGRAMA) / f"FULLONE_Fluxograma_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    os.makedirs(PASTA_DIAGRAMA, exist_ok=True)
    dot.render(str(diagram_path), format='png', cleanup=True)
    return str(diagram_path) + ".png"

def gerar_pdf(todos_arquivos, unificado_path, zip_path, fluxograma_path):
    os.makedirs(PASTA_DIAGRAMA, exist_ok=True)
    pdf_path = Path(PASTA_DIAGRAMA) / f"{VERSAO_FULLONE}_relatorio_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Helvetica", "B", 16)
    pdf.set_text_color(0, 0, 128)
    pdf.cell(0, 10, f"FULLONE Relatório - {VERSAO_FULLONE}", new_x=XPos.LMARGIN, new_y=YPos.NEXT, align="C")
    pdf.ln(5)

    ps1_count = len([f for f in todos_arquivos if f.suffix.lower() == ".ps1"])
    py_count = len([f for f in todos_arquivos if f.suffix.lower() == ".py"])
    pdf.set_font("Helvetica", "", 12)
    pdf.set_text_color(0, 0, 0)
    pdf.multi_cell(0, 6, f"Total de arquivos encontrados: {len(todos_arquivos)}\n"
                          f"Arquivos .PS1: {ps1_count}\n"
                          f"Arquivos .PY: {py_count}\n"
                          f"Arquivo PS1 unificado: {unificado_path}\n"
                          f"ZIP gerado: {zip_path}\n")
    pdf.ln(5)

    pdf.set_font("Helvetica", "B", 14)
    pdf.set_text_color(0, 128, 0)
    pdf.cell(0, 10, "Fluxograma do processo", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    if os.path.exists(fluxograma_path):
        pdf.image(fluxograma_path, w=180)
    pdf.ln(5)

    pdf.set_font("Helvetica", "B", 12)
    pdf.set_text_color(128, 0, 0)
    pdf.cell(0, 8, "Lista de arquivos encontrados:", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_font("Helvetica", "", 10)

    # Quebra de linha para caminhos longos
    max_len = 95
    for f in todos_arquivos:
        caminho = str(f)
        while len(caminho) > max_len:
            pdf.multi_cell(0, 5, caminho[:max_len])
            caminho = caminho[max_len:]
        pdf.multi_cell(0, 5, caminho)

    pdf.output(pdf_path)
    print(f"[INFO] PDF gerado: {pdf_path}")
    return pdf_path

# ===============================
# EXECUÇÃO PRINCIPAL
# ===============================
if __name__ == "__main__":
    print("=== FULLONE - GERADOR AUTÔNOMO AVANÇADO ===\n")
    atualizar_script_oficial()

    todos_arquivos = buscar_arquivos()
    print(f"[INFO] Total arquivos encontrados: {len(todos_arquivos)}")
    print(f"[INFO] Arquivos .PS1: {len([f for f in todos_arquivos if f.suffix.lower()=='.ps1'])}")
    print(f"[INFO] Arquivos .PY: {len([f for f in todos_arquivos if f.suffix.lower()=='.py'])}")

    arquivos_recente = selecionar_versao_recente(todos_arquivos)
    print(f"[INFO] Arquivos selecionados (versão recente): {len(arquivos_recente)}")

    unificado_path = criar_unificado(arquivos_recente, PASTA_UNIFICADOS)
    zip_path = criar_zip(unificado_path, arquivos_recente)
    fluxograma_path = gerar_fluxograma()
    pdf_path = gerar_pdf(arquivos_recente, unificado_path, zip_path, fluxograma_path)

    print("=== FULLONE finalizado com sucesso! ===")


# ---- bloco ----

def atualizar_script_oficial():
    """Atualiza o script a partir da versão oficial"""
    arquivo_oficial = Path(PASTA_OFICIAL) / "criar-pacotes.py"
    arquivo_exec = Path(PASTA_EXEC) / "criar-pacotes.py"

    if not arquivo_oficial.exists():
        print(f"[AVISO] Nenhum arquivo oficial encontrado em: {PASTA_OFICIAL}")
        # Cria a pasta se não existir
        Path(PASTA_OFICIAL).mkdir(parents=True, exist_ok=True)
        arquivo_oficial.touch()
        print(f"[INFO] Arquivo oficial criado: {arquivo_oficial}")
        return

    atualizar = False
    if not arquivo_exec.exists():
        atualizar = True
    else:
        if arquivo_oficial.read_bytes() != arquivo_exec.read_bytes():
            atualizar = True

    if atualizar:
        if arquivo_exec.exists():
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = arquivo_exec.with_name(f"{arquivo_exec.stem}_backup_{timestamp}.py")
            shutil.copy2(arquivo_exec, backup_path)
            print(f"[INFO] Backup do script antigo salvo: {backup_path}")

        shutil.copy2(arquivo_oficial, arquivo_exec)
        print("[INFO] Script atualizado automaticamente.")


# ---- bloco ----

import os
import shutil
import zipfile
from pathlib import Path
from datetime import datetime
from fpdf import FPDF, XPos, YPos
import graphviz

# ===============================
# CONFIGURAÇÃO DE PASTAS E VERSÃO
# ===============================
VERSAO_FULLONE = "FULLONEv14fixed4"
PASTA_OFICIAL = r"C:\SCRIPTS\FULL ONE\OFFICIAL"
PASTA_EXEC = r"C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR"
PASTA_UNIFICADOS = r"C:\SCRIPTS\FULL ONE\ARQUIVOS .PS1 UNIFICADOS"
PASTA_PACKAGE = r"C:\SCRIPTS\FULL ONE\PACKAGE"
PASTA_DIAGRAMA = r"C:\SCRIPTS\FULL ONE\DIAGRAMA VISUAL"

# Pastas para buscar arquivos
PASTAS_PROCURA = [
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\UNIC QUANTIC\scripts",
]

NOME_UNIFICADO = "ONEFULL.ps1"

# ===============================
# FUNÇÕES
# ===============================

def atualizar_script_oficial():
    """Atualiza o script a partir da versão oficial"""
    arquivo_oficial = Path(PASTA_OFICIAL) / "criar-pacotes.py"
    arquivo_exec = Path(PASTA_EXEC) / "criar-pacotes.py"

    if not arquivo_oficial.exists():
        print(f"[AVISO] Nenhum arquivo oficial encontrado em: {PASTA_OFICIAL}")
        Path(PASTA_OFICIAL).mkdir(parents=True, exist_ok=True)
        arquivo_oficial.touch()
        print(f"[INFO] Arquivo oficial criado: {arquivo_oficial}")
        return

    atualizar = False
    if not arquivo_exec.exists():
        atualizar = True
    else:
        if arquivo_oficial.read_bytes() != arquivo_exec.read_bytes():
            atualizar = True

    if atualizar:
        if arquivo_exec.exists():
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = arquivo_exec.with_name(f"{arquivo_exec.stem}_backup_{timestamp}.py")
            shutil.copy2(arquivo_exec, backup_path)
            print(f"[INFO] Backup do script antigo salvo: {backup_path}")

        shutil.copy2(arquivo_oficial, arquivo_exec)
        print("[INFO] Script atualizado automaticamente.")

def buscar_arquivos():
    """Busca arquivos .PS1 e .PY em todas as pastas"""
    todos_arquivos = []
    for pasta in PASTAS_PROCURA:
        path_pasta = Path(pasta)
        if path_pasta.exists():
            for ext in ("*.ps1", "*.py"):
                encontrados = list(path_pasta.rglob(ext))
                todos_arquivos.extend(encontrados)
    return todos_arquivos

def selecionar_versao_recente(arquivos):
    """Seleciona a versão mais recente dos arquivos com mesmo nome"""
    arquivos_dict = {}
    for arquivo in arquivos:
        nome = arquivo.name
        if nome not in arquivos_dict:
            arquivos_dict[nome] = arquivo
        else:
            if arquivo.stat().st_mtime > arquivos_dict[nome].stat().st_mtime:
                arquivos_dict[nome] = arquivo
    return list(arquivos_dict.values())

def criar_unificado(arquivos, pasta_saida):
    """Cria arquivo PS1 unificado"""
    os.makedirs(pasta_saida, exist_ok=True)
    unificado_path = Path(pasta_saida) / NOME_UNIFICADO

    if unificado_path.exists():
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = unificado_path.with_name(f"{unificado_path.stem}_backup_{timestamp}.ps1")
        shutil.move(unificado_path, backup_path)
        print(f"[INFO] Backup do PS1 unificado antigo: {backup_path}")

    with open(unificado_path, "w", encoding="utf-8") as f:
        f.write(f"# FULLONE Unificado - Versão {VERSAO_FULLONE}\n")
        f.write(f"# Gerado em {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        for arquivo in arquivos:
            try:
                with open(arquivo, "r", encoding="utf-8") as af:
                    conteudo = af.read()
                f.write(f"# ===== INICIO {arquivo.name} =====\n")
                f.write(conteudo + "\n")
                f.write(f"# ===== FIM {arquivo.name} =====\n\n")
            except Exception as e:
                print(f"[ERRO] Não foi possível ler {arquivo}: {e}")
    print(f"[INFO] PS1 unificado criado: {unificado_path}")
    return unificado_path

def criar_zip(unificado_path, todos_arquivos):
    """Cria ZIP incremental com scripts anexados como .txt"""
    os.makedirs(PASTA_PACKAGE, exist_ok=True)
    contador = 1
    while True:
        zip_name = f"{VERSAO_FULLONE}_{contador:04d}.zip"
        zip_path = Path(PASTA_PACKAGE) / zip_name
        if not zip_path.exists():
            break
        contador += 1

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        # Adiciona PS1 unificado
        zf.write(unificado_path, arcname=unificado_path.name)
        # Adiciona cada script como .txt
        for arquivo in todos_arquivos:
            try:
                with open(arquivo, "r", encoding="utf-8") as f:
                    conteudo = f.read()
                txt_name = f"{arquivo.stem}.txt"
                zf.writestr(txt_name, conteudo)
            except Exception as e:
                print(f"[ERRO] Não foi possível anexar {arquivo} ao ZIP: {e}")
    print(f"[INFO] ZIP criado: {zip_path}")
    return zip_path

def gerar_fluxograma():
    """Gera fluxograma do processo"""
    dot = graphviz.Digraph(comment='FULLONE Fluxograma')
    dot.node('A', 'Início')
    dot.node('B', 'Busca arquivos')
    dot.node('C', 'Seleciona versão recente')
    dot.node('D', 'Unifica PS1')
    dot.node('E', 'Cria ZIP')
    dot.node('F', 'Gera PDF')
    dot.edges(['AB', 'BC', 'CD', 'DE', 'DF'])
    diagram_path = Path(PASTA_DIAGRAMA) / f"FULLONE_Fluxograma_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    os.makedirs(PASTA_DIAGRAMA, exist_ok=True)
    dot.render(str(diagram_path), format='png', cleanup=True)
    return str(diagram_path) + ".png"

def gerar_pdf(todos_arquivos, unificado_path, zip_path, fluxograma_path):
    """Gera PDF detalhado"""
    os.makedirs(PASTA_DIAGRAMA, exist_ok=True)
    pdf_path = Path(PASTA_DIAGRAMA) / f"{VERSAO_FULLONE}_relatorio_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Helvetica", "B", 16)
    pdf.set_text_color(0, 0, 128)
    pdf.cell(0, 10, f"FULLONE Relatório - {VERSAO_FULLONE}", ln=True, align="C")
    pdf.ln(5)

    ps1_count = len([f for f in todos_arquivos if f.suffix.lower() == ".ps1"])
    py_count = len([f for f in todos_arquivos if f.suffix.lower() == ".py"])
    pdf.set_font("Helvetica", "", 12)
    pdf.set_text_color(0, 0, 0)
    pdf.multi_cell(0, 6, f"Total de arquivos encontrados: {len(todos_arquivos)}\n"
                          f"Arquivos .PS1: {ps1_count}\n"
                          f"Arquivos .PY: {py_count}\n"
                          f"Arquivo PS1 unificado: {unificado_path}\n"
                          f"ZIP gerado: {zip_path}\n")
    pdf.ln(5)

    pdf.set_font("Helvetica", "B", 14)
    pdf.set_text_color(0, 128, 0)
    pdf.cell(0, 10, "Fluxograma do processo", ln=True)
    pdf.image(fluxograma_path, w=180)
    pdf.ln(5)

    pdf.set_font("Helvetica", "B", 12)
    pdf.set_text_color(128, 0, 0)
    pdf.cell(0, 8, "Lista de arquivos encontrados:", ln=True)
    pdf.set_font("Helvetica", "", 10)

    for f in todos_arquivos:
        caminho = str(f)
        while len(caminho) > 95:
            pdf.multi_cell(0, 5, caminho[:95])
            caminho = caminho[95:]
        pdf.multi_cell(0, 5, caminho)

    pdf.output(pdf_path)
    print(f"[INFO] PDF gerado: {pdf_path}")
    return pdf_path

# ===============================
# EXECUÇÃO PRINCIPAL
# ===============================
if __name__ == "__main__":
    print("=== FULLONE - GERADOR AUTÔNOMO AVANÇADO ===\n")
    atualizar_script_oficial()

    todos_arquivos = buscar_arquivos()
    print(f"[INFO] Total arquivos encontrados: {len(todos_arquivos)}")
    print(f"[INFO] Arquivos .PS1: {len([f for f in todos_arquivos if f.suffix.lower()=='.ps1'])}")
    print(f"[INFO] Arquivos .PY: {len([f for f in todos_arquivos if f.suffix.lower()=='.py'])}")

    arquivos_recente = selecionar_versao_recente(todos_arquivos)
    print(f"[INFO] Arquivos selecionados (versão recente): {len(arquivos_recente)}")

    unificado_path = criar_unificado(arquivos_recente, PASTA_UNIFICADOS)
    zip_path = criar_zip(unificado_path, arquivos_recente)
    fluxograma_path = gerar_fluxograma()
    pdf_path = gerar_pdf(arquivos_recente, unificado_path, zip_path, fluxograma_path)

    print("=== FULLONE finalizado com sucesso! ===")


# ---- bloco ----

def gerar_pdf(todos_arquivos, unificado_path, zip_path, fluxograma_path):
    """Gera PDF detalhado"""
    os.makedirs(PASTA_DIAGRAMA, exist_ok=True)
    pdf_path = Path(PASTA_DIAGRAMA) / f"{VERSAO_FULLONE}_relatorio_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    pdf = FPDF()
    pdf.add_page()
    
    # Título
    pdf.set_font("Helvetica", "B", 16)
    pdf.set_text_color(0, 0, 128)
    pdf.cell(0, 10, f"FULLONE Relatório - {VERSAO_FULLONE}", new_x=XPos.LMARGIN, new_y=YPos.NEXT, align="C")
    pdf.ln(5)

    # Contagem de arquivos
    ps1_count = len([f for f in todos_arquivos if f.suffix.lower() == ".ps1"])
    py_count = len([f for f in todos_arquivos if f.suffix.lower() == ".py"])
    pdf.set_font("Helvetica", "", 12)
    pdf.set_text_color(0, 0, 0)
    info_text = (f"Total de arquivos encontrados: {len(todos_arquivos)}\n"
                 f"Arquivos .PS1: {ps1_count}\n"
                 f"Arquivos .PY: {py_count}\n"
                 f"Arquivo PS1 unificado: {unificado_path}\n"
                 f"ZIP gerado: {zip_path}\n")
    pdf.multi_cell(0, 6, info_text)
    pdf.ln(5)

    # Fluxograma
    pdf.set_font("Helvetica", "B", 14)
    pdf.set_text_color(0, 128, 0)
    pdf.cell(0, 10, "Fluxograma do processo", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.image(fluxograma_path, w=180)
    pdf.ln(5)

    # Lista de arquivos
    pdf.set_font("Helvetica", "B", 12)
    pdf.set_text_color(128, 0, 0)
    pdf.cell(0, 8, "Lista de arquivos encontrados:", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_font("Helvetica", "", 10)

    # Quebra de linhas segura
    max_width = 180  # largura da célula para evitar FPDFException
    for f in todos_arquivos:
        caminho = str(f)
        while len(caminho) > 0:
            # Pegamos até 190 caracteres por linha para evitar overflow
            linha = caminho[:95]
            caminho = caminho[95:]
            pdf.multi_cell(max_width, 5, linha)

    pdf.output(pdf_path)
    print(f"[INFO] PDF gerado: {pdf_path}")
    return pdf_path


# ---- bloco ----

#!/usr/bin/env python3
# FULLONE_Avancado_Complete.py
# FULLONE autônomo avançado - versão FULLONEv14fixed3 (script unificado, gerador de pacote ZIP, PDF relatório, fluxograma)
# Salve como: C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR\FULLONE_Avancado_Complete.py
# Execute: python FULLONE_Avancado_Complete.py

import os
import sys
import shutil
import zipfile
import traceback
import re
from pathlib import Path
from datetime import datetime
from collections import defaultdict

# PDF & Graphviz libs
try:
    from fpdf import FPDF, XPos, YPos
except Exception:
    print("[WARN] fpdf2 não encontrado ou conflito (pypdf/pyfpdf instalado). Instale/ajuste fpdf2 para melhor saída de PDF.")
    from fpdf import FPDF  # fallback - may still work but some APIs differ

try:
    import graphviz
    GRAPHVIZ_AVAILABLE = True
except Exception:
    GRAPHVIZ_AVAILABLE = False

# --------------------------
# CONFIGURAÇÕES (edite se desejar)
# --------------------------
VERSAO_FULLONE = "FULLONEv14fixed3"  # cabeçalho de versão
PASTA_BASE = Path(r"C:\SCRIPTS\FULL ONE")
PASTA_OFICIAL = PASTA_BASE / "OFFICIAL"
PASTA_EXEC = PASTA_BASE / "FULL ONE GENERATOR"
PASTA_UNIFICADOS = PASTA_BASE / "ARQUIVOS .PS1 UNIFICADOS"
PASTA_PACKAGE = PASTA_BASE / "PACKAGE"
PASTA_COMPILADOS = PASTA_BASE / "COMPILADOS"
PASTA_DIAGRAMA = PASTA_BASE / "DIAGRAMA VISUAL"
PASTA_LOGS = PASTA_BASE / "LOGS"

NOME_UNIFICADO = "ONEFULL.ps1"

# Pastas onde procurar (lista fornecida por você, mantida completa)
PASTAS_PROCURA = [
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\collections",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\encodings",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\re",
    r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard\base_library.zip",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\collections",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\re",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\encodings",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar\build",
    r"C:\CONAV TRADER\CONAV_TRADER\mapas de fluxograma",
    r"C:\CONAV TRADER\CONAV_TRADER\PACKAGES OFICIAIS",
    r"C:\CONAV TRADER\CONAV_TRADER\SCRIPT MESTRE",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\0001",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\0002",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\0003",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\004",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\aleatorios versoes 1.30+",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\PACKAGES OFICIAIS",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\SCRIPTS BASE OFICIAIS",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\SCRIPTS DE LISTAGEM",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\uninstall versoes 1.30+",
    r"C:\CONAV TRADER\CONAV_TRADER\SCRIPTS DE LISTAGEM",
    r"C:\CONAV TRADER\CONAV_TRADER\SCRIPTS BASE OFICIAIS",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\TUTORIAL GERAL",
    r"C:\CONAV TRADER\CONAV_TRADER\CONAV MASTER FULL",
    r"C:\CONAV TRADER\dist",
    r"C:\CONAV TRADER\logs",
    r"C:\CONAV TRADER\PASTA DO BACKUP\CONAV TRADES ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV-ZIP_20250911_160904",
    r"C:\CONAV TRADER\PASTA DO BACKUP\CONAV TRADES ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV-ZIP_20250911_161555",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADER TESTER ONE CLICK",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV_TRADER_FULL2",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\INSTALL CONAV  TRADERFULL",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\INSTALL SETUP CONAV ICONS",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\UNINSTALL CONAV TRADER",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV_TRADER_FULL1",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV_TRADER_FULL2",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV_TRADER_OneClick-CONTEM ERROS",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV TRADER FULL 1.44",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV TRADER FULL 1.44\fix 1.44",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_FULL_PROFESSIONAL_v1.45",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_FULL_PROFESSIONAL_v1.45\fix 1.45",
    r"C:\MAGIC QUANTIC TRADER\ZIPS E VERSOES\MEGA SUITE 001",
    r"C:\MAGIC QUANTIC TRADER\ZIPS E VERSOES\MQT PACKAGE COMPLETE 002",
    r"C:\MAGIC QUANTIC TRADER\ZIPS E VERSOES\MQT PACKAGE COMPLETE 003",
    r"C:\MAGIC QUANTIC TRADER\ZIPS E VERSOES\MQT PACKAGE COMPLETE ALL IN ONE 004",
    r"C:\MAGIC QUANTIC TRADER\ZIPS E VERSOES\MQT NEW MEGA SUITE ALL 005",
    r"C:\CONAV TRADER\CONAV_TRADER\CONAV MASTER FULL\FULLONEMASTER-INSTALL",
    r"C:\CONAV TRADER\CONAV_TRADER\CONAV MASTER FULL\FULLONEMASTER\FULLONE-MESTER",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\CONAV MASTER FULL FIX4\CONAVMASTER FIX4",
    r"C:\CONAV TRADER\CONAV_TRADER\PACKAGES OFICIAIS\CONAV_FULL_PROFESSIONAL_v1.45_fix3_pkg",
    r"C:\CONAV TRADER\CONAV_TRADER\PACKAGES OFICIAIS\CONAV_FULL_PROFESSIONAL_v1.45_fix3_pkg_1",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_ADVANCED_PRODUCTION\CONAV_TRADER",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_ADVANCED_PRODUCTION",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.29\INSTALL_CONAV_TRADER_FULL1.29",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.30",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.30\CONAV_TRADER_1_30_fixed",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.30\CONAV_TRADER_1_30_01fixed",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.31",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.32",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.33",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.34\CONAV_TRADER",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_FULL_1.34.1",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\CONAV-ZIPS\CONAV_TRADER_PRODUCTION_TEST",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\INSTALL CONAV  TRADERFULL",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\CONAV TRADERS ZIPS ATUALIZADOS\BACKUP DO 1 PS1",
    r"C:\CONAV TRADER\PASTAS DO  BACKUP\SCRIPTS OPCIONAIS E FUNCIONAIS",
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\USERAT\scripts\scripts 2",
    r"C:\USERAT\scripts\scripts 2\compiladao",
    r"C:\USERAT\USERAT_Projeto_Completo",
    r"C:\USERAT\USERAT_Projeto_Completo\scripts",
    r"C:\USERAT\USERAT_Projeto_Completo\scripts\scripts 2",
    r"C:\USERAT\USERAT_Projeto_Completo\scripts\scripts 2\compiladao",
    r"C:\USERAT\USERAT_Projeto_Completo\tutoriais",
    r"C:\USERAT1",
    r"C:\ACESSO A PASTA WINAPP\1",
    r"C:\USERAT1\USERAT_Final_Atualizado",
    r"C:\USERAT1\USERAT_Final_Atualizado\scripts",
    r"C:\USERAT2",
    r"C:\USERAT2\RAR USERASTS\USERAT_Final_Atualizado",
    r"C:\USERAT2\RAR USERASTS\USERAT_Final_Atualizado\scripts",
    r"C:\USERAT2\scripts",
    r"C:\USERAT2\SCRPITS PS1",
    r"C:\USERAT2\USERAT_Final_Atualizado",
    r"C:\TESTEE 2",
    r"C:\TESTEE 2\A3",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\TESTEE 2\ARQUIVOS",
    r"C:\TESTEE 2\ARQUIVOS\2 ADVANCED",
    r"C:\TESTEE 3\AI_Trade_Suite_Full_Deliverable",
    r"C:\TST DE API E SOFT\ai trade suite\AI_Trade_Suite",
    r"C:\AAAAAAAA",
    r"C:\AAAAAAAA\AI_Trade_Suite_Expanded (3)",
    r"C:\UNIC QUANTIC",
    r"C:\UNIC QUANTIC\$",
    r"C:\UNIC QUANTIC\backend",
    r"C:\UNIC QUANTIC\database",
    r"C:\UNIC QUANTIC\frontend",
    r"C:\UNIC QUANTIC\logs",
    r"C:\UNIC QUANTIC\pdfs",
    r"C:\UNIC QUANTIC\scripts",
    r"C:\UNIC QUANTIC\scripts\SCRIPTS OPCIONAIS",
    r"C:\UNIC QUANTIC\scripts\SETUP UNIC PARTE 1",
    r"C:\UNIC QUANTIC\tools",
    r"C:\Users\arati\OneDrive\Área de Trabalho\1"
]

# --------------------------
# Helpers: criar dirs, logging simples
# --------------------------
def ensure_dirs():
    for d in (PASTA_BASE, PASTA_OFICIAL, PASTA_EXEC, PASTA_UNIFICADOS, PASTA_PACKAGE, PASTA_COMPILADOS, PASTA_DIAGRAMA, PASTA_LOGS):
        try:
            Path(d).mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

def log(msg, level="INFO"):
    ensure_dirs()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{now}][{level}] {msg}"
    print(line)
    try:
        logfile = PASTA_LOGS / f"fullone_log_{datetime.now().strftime('%Y%m%d')}.txt"
        with open(logfile, "a", encoding="utf-8") as lf:
            lf.write(line + "\n")
    except Exception:
        pass

# --------------------------
# Ler arquivos com fallback de encoding
# --------------------------
def read_text_file(path, max_lines=None):
    for enc in ("utf-8", "latin-1", "cp1252"):
        try:
            with open(path, "r", encoding=enc, errors="replace") as f:
                if max_lines:
                    lines = []
                    for i, l in enumerate(f):
                        lines.append(l)
                        if i + 1 >= max_lines:
                            break
                    return "".join(lines)
                else:
                    return f.read()
        except Exception:
            continue
    return ""

# --------------------------
# Detectar versão dentro do arquivo (tentativa heurística)
# --------------------------
VERSION_RX = re.compile(r"\b(v(?:er(?:são|sion)?)?[_\s\-:]*)?(\d+(?:\.\d+){0,3})\b", re.IGNORECASE)

def extract_version_hint(path):
    # tenta encontrar padrões como v1.2, 1.2.3, FULLONEv14, FULLONEv14fixed2 etc nas primeiras linhas
    text = read_text_file(path, max_lines=40)
    if not text:
        return None
    # patterns: FULLONEv14..., v1.2, version 1.2, versão 1.2
    m = re.search(r"(FULLONEv\d+(?:[a-zA-Z0-9_\-\.]*)?)", text, re.IGNORECASE)
    if m:
        return m.group(1)
    # generic numeric version
    m2 = VERSION_RX.search(text)
    if m2:
        return m2.group(2)
    return None

# --------------------------
# Buscar arquivos .ps1 e .py nas pastas configuradas
# --------------------------
def gather_files():
    found = []
    for p in PASTAS_PROCURA:
        ppath = Path(p)
        if not ppath.exists():
            log(f"Search path not found (skipped): {p}", "WARN")
            continue
        # rglob both extensions
        try:
            for ext in ("*.ps1", "*.py"):
                for f in ppath.rglob(ext):
                    # avoid searching inside the package output dirs to prevent recursion
                    if str(f).startswith(str(PASTA_BASE)):
                        # allow, but skip the generated outputs folder names
                        if any(part in str(f) for part in ("PACKAGE", "ARQUIVOS .PS1 UNIFICADOS", "FULL ONE GENERATOR")):
                            # still allow if file not in those special output folders? skip to be safe
                            continue
                    found.append(f)
        except Exception as e:
            log(f"Erro ao listar {p}: {e}", "WARN")
    return found

# --------------------------
# Selecionar versão mais recente por nome (melhora: usa timestamp + heurística de versão)
# --------------------------
def select_latest_versions(files):
    # group by filename
    byname = defaultdict(list)
    for f in files:
        byname[f.name].append(f)
    selected = []
    for name, flist in byname.items():
        if len(flist) == 1:
            selected.append(flist[0])
            continue
        # try to pick by explicit version hint inside file
        best = None
        best_ver_tuple = None
        for f in flist:
            ver = extract_version_hint(f)
            # convert ver to tuple numeric if possible
            ver_tuple = None
            if ver:
                # parse digits from ver; if string like FULLONEv14fixed2 -> try to extract 14
                digits = re.findall(r"\d+", ver)
                if digits:
                    ver_tuple = tuple(int(x) for x in digits)
            # choose by ver_tuple > older; if equal or none, fallback to mtime
            if best is None:
                best = f; best_ver_tuple = ver_tuple
            else:
                if ver_tuple and best_ver_tuple:
                    if ver_tuple > best_ver_tuple:
                        best = f; best_ver_tuple = ver_tuple
                        continue
                elif ver_tuple and not best_ver_tuple:
                    best = f; best_ver_tuple = ver_tuple
                    continue
                elif not ver_tuple and not best_ver_tuple:
                    # compare modification time
                    if f.stat().st_mtime > best.stat().st_mtime:
                        best = f
                else:
                    # best has ver_tuple but current not -> keep best
                    pass
        selected.append(best)
    return selected

# --------------------------
# Criar ONEFULL.ps1 unificado (backup automático)
# --------------------------
def create_unified(selected_files):
    Path(PASTA_UNIFICADOS).mkdir(parents=True, exist_ok=True)
    unified_path = Path(PASTA_UNIFICADOS) / NOME_UNIFICADO
    if unified_path.exists():
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup = unified_path.with_name(f"{unified_path.stem}_backup_{timestamp}.ps1")
        try:
            shutil.move(str(unified_path), str(backup))
            log(f"Backup do PS1 unificado antigo: {backup}", "OK")
        except Exception as e:
            log(f"Falha ao mover backup do unificado: {e}", "WARN")
    # build header
    header = [
        f"# =============================================",
        f"# {NOME_UNIFICADO} - FULLONE Unificado - {VERSAO_FULLONE}",
        f"# Gerado em {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"# Total arquivos incluídos: {len(selected_files)}",
        f"# =============================================",
        ""
    ]
    try:
        with open(unified_path, "w", encoding="utf-8") as out:
            out.write("\n".join(header) + "\n")
            for f in selected_files:
                out.write("\n")
                out.write("#" * 78 + "\n")
                out.write(f"# INICIO: {f}\n")
                out.write("#" * 78 + "\n")
                try:
                    txt = read_text_file(f)
                    # If python files, include as here-doc comment? We'll include verbatim.
                    out.write(txt + "\n")
                except Exception as e:
                    out.write(f"# ERRO AO LER O ARQUIVO: {e}\n")
                out.write("#" * 78 + "\n")
                out.write(f"# FIM: {f}\n")
                out.write("#" * 78 + "\n")
        log(f"PS1 unificado criado: {unified_path}", "OK")
    except Exception as e:
        log(f"Falha ao criar PS1 unificado: {e}", "ERROR")
    return unified_path

# --------------------------
# Criar cópias .txt de cada arquivo (para inclusão no ZIP e referência)
# --------------------------
def create_txt_copies(selected_files, out_dir):
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    txt_paths = []
    for f in selected_files:
        try:
            content = read_text_file(f)
            safe_name = f.name
            dest = Path(out_dir) / (safe_name + ".txt")
            with open(dest, "w", encoding="utf-8") as w:
                w.write(f"# ORIGINAL: {f}\n# PATH: {f}\n# Extracted: {datetime.now().isoformat()}\n\n")
                w.write(content)
            txt_paths.append(dest)
        except Exception as e:
            log(f"Falha criando TXT para {f}: {e}", "WARN")
    return txt_paths

# --------------------------
# Criar ZIP incremental incluindo unificado e txts
# --------------------------
def create_zip_package(unified_path, txt_files, selected_files):
    Path(PASTA_PACKAGE).mkdir(parents=True, exist_ok=True)
    # generate next index
    i = 1
    while True:
        zip_name = f"{VERSAO_FULLONE}_{i:04d}.zip"
        zip_path = Path(PASTA_PACKAGE) / zip_name
        if not zip_path.exists():
            break
        i += 1
    try:
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            # add unified PS1
            if unified_path.exists():
                zf.write(str(unified_path), arcname=str(Path(unified_path).name))
            # add txts
            for t in txt_files:
                zf.write(str(t), arcname=os.path.join("scripts_txt", Path(t).name))
            # add small config and readme
            readme = Path(PASTA_PACKAGE) / "README_FULLONE.txt"
            with open(readme, "w", encoding="utf-8") as r:
                r.write(f"Package: {VERSAO_FULLONE}\nGenerated: {datetime.now().isoformat()}\nIncluded files: {len(selected_files)}\n")
            zf.write(str(readme), arcname=readme.name)
        log(f"ZIP criado: {zip_path}", "OK")
    except Exception as e:
        log(f"Falha ao criar ZIP: {e}", "ERROR")
        zip_path = None
    return zip_path

# --------------------------
# Gerar fluxograma com graphviz (PNG)
# --------------------------
def generate_diagram():
    Path(PASTA_DIAGRAMA).mkdir(parents=True, exist_ok=True)
    fname = Path(PASTA_DIAGRAMA) / f"FULLONE_fluxograma_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    try:
        if not GRAPHVIZ_AVAILABLE:
            raise RuntimeError("graphviz Python package or dot executable not available")
        dot = graphviz.Digraph(comment='FULLONE Fluxograma')
        dot.node('A', 'Início')
        dot.node('B', 'Busca arquivos')
        dot.node('C', 'Seleciona versão recente')
        dot.node('D', 'Cria UNIFIED (ONEFULL)')
        dot.node('E', 'Cria ZIP')
        dot.node('F', 'Gera PDF')
        dot.edges(['AB', 'BC', 'CD', 'DE', 'EF'])
        # render to png
        out = dot.render(str(fname), format='png', cleanup=True)
        log(f"Diagram generated into: {out}", "OK")
        return out
    except Exception as e:
        log(f"Fluxograma: falha ao gerar (Graphviz): {e}", "WARN")
        return None

# --------------------------
# Gerar relatório PDF (resumo + lista curta + mini-trechos). Lista completa salva em TXT e incluída no ZIP
# --------------------------
def generate_pdf(selected_files, unified_path, zip_path, diagram_path, txt_list_path):
    Path(PASTA_DIAGRAMA).mkdir(parents=True, exist_ok=True)
    pdf_name = Path(PASTA_DIAGRAMA) / f"{VERSAO_FULLONE}_relatorio_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    try:
        pdf = FPDF()
        pdf.set_auto_page_break(True, margin=12)
        pdf.add_page()
        # Title
        try:
            pdf.set_font("Helvetica", "B", 16)
        except Exception:
            pdf.set_font("Arial", "B", 16)
        pdf.set_text_color(0, 0, 128)
        # Use new_x/new_y if available (fpdf2), else fallback to ln
        try:
            pdf.cell(0, 10, f"FULLONE Relatório - {VERSAO_FULLONE}", new_x=XPos.LMARGIN, new_y=YPos.NEXT, align="C")
        except Exception:
            pdf.cell(0, 10, f"FULLONE Relatório - {VERSAO_FULLONE}", ln=True, align="C")
        pdf.ln(6)
        # stats
        ps1_count = sum(1 for f in selected_files if f.suffix.lower() == ".ps1")
        py_count = sum(1 for f in selected_files if f.suffix.lower() == ".py")
        pdf.set_font("", "", 11)
        pdf.set_text_color(0, 0, 0)
        info = (f"Gerado: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
                f"Total arquivos descobertos (originais): {len(selected_files)}\n"
                f"Arquivos .PS1 selecionados para unificação: {ps1_count}\n"
                f"Arquivos .PY selecionados incluídos: {py_count}\n"
                f"ONEFULL unificado: {unified_path}\n"
                f"ZIP gerado: {zip_path}\n"
                f"Lista completa de arquivos salva em: {txt_list_path}\n")
        # multi-cell safe width
        try:
            pdf.multi_cell(0, 6, info)
        except Exception:
            # fallback: split lines
            for ln in info.splitlines():
                pdf.cell(0, 6, ln, ln=True)
        pdf.ln(4)
        # Diagram
        if diagram_path and Path(diagram_path).exists():
            pdf.set_font("", "B", 12)
            try:
                pdf.cell(0, 8, "Fluxograma do processo", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
            except Exception:
                pdf.cell(0, 8, "Fluxograma do processo", ln=True)
            try:
                pdf.image(str(diagram_path), w=170)
            except Exception as e:
                log(f"Não foi possível inserir a imagem do fluxograma no PDF: {e}", "WARN")
            pdf.ln(4)
        # Mini trechos: para não encher o PDF, vamos colocar os primeiros 3 arquivos com 10 linhas cada como exemplo
        pdf.set_font("", "B", 12)
        try:
            pdf.cell(0, 8, "Exemplos (primeiros 3 arquivos e 10 linhas cada):", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        except Exception:
            pdf.cell(0, 8, "Exemplos (primeiros 3 arquivos e 10 linhas cada):", ln=True)
        pdf.ln(2)
        pdf.set_font("", "", 9)
        for f in selected_files[:3]:
            txt = read_text_file(f, max_lines=10)
            pdf.set_font("", "B", 10)
            try:
                pdf.multi_cell(0, 5, f"--- {f.name} (origem: {f}) ---")
            except Exception:
                pdf.cell(0, 5, f"--- {f.name} ---", ln=True)
            pdf.set_font("", "", 8)
            for line in txt.splitlines():
                # safe width slicing
                while len(line) > 180:
                    try:
                        pdf.multi_cell(180, 4, line[:180])
                    except Exception:
                        pdf.cell(0, 4, line[:180], ln=True)
                    line = line[180:]
                try:
                    pdf.multi_cell(0, 4, line)
                except Exception:
                    pdf.cell(0, 4, line, ln=True)
            pdf.ln(2)
        # Add short list (first 200 filenames) to PDF; full list in TXT attached to ZIP, as requested
        pdf.set_font("", "B", 11)
        try:
            pdf.cell(0, 8, "Lista curta de arquivos (primeiros 200):", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        except Exception:
            pdf.cell(0, 8, "Lista curta de arquivos (primeiros 200):", ln=True)
        pdf.set_font("", "", 9)
        count = 0
        for f in selected_files:
            if count >= 200:
                pdf.multi_cell(0, 5, f"... ({len(selected_files)-200} arquivos adicionais foram listados no TXT anexo)")
                break
            line = str(f)
            # split long path into reasonable chunks
            while len(line) > 120:
                part = line[:120]
                try:
                    pdf.multi_cell(0, 5, part)
                except Exception:
                    pdf.cell(0, 5, part, ln=True)
                line = line[120:]
            try:
                pdf.multi_cell(0, 5, line)
            except Exception:
                pdf.cell(0, 5, line, ln=True)
            count += 1
        # finish
        pdf.output(str(pdf_name))
        log(f"PDF gerado: {pdf_name}", "OK")
        return pdf_name
    except Exception as e:
        log(f"Falha ao gerar PDF: {e}", "ERROR")
        log(traceback.format_exc(), "DEBUG")
        return None

# --------------------------
# Salvar lista completa em TXT (incluir no ZIP)
# --------------------------
def save_full_list_txt(selected_files):
    Path(PASTA_DIAGRAMA).mkdir(parents=True, exist_ok=True)
    out = Path(PASTA_DIAGRAMA) / f"{VERSAO_FULLONE}_lista_completa_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    try:
        with open(out, "w", encoding="utf-8") as f:
            f.write(f"FULLONE - Lista completa de arquivos ({datetime.now().isoformat()})\n")
            f.write(f"Total: {len(selected_files)}\n\n")
            for s in selected_files:
                f.write(str(s) + "\n")
        log(f"Lista completa TXT salva: {out}", "OK")
        return out
    except Exception as e:
        log(f"Falha ao salvar lista TXT: {e}", "WARN")
        return None

# --------------------------
# Atualizar script oficial (copia de OFFICIAL -> EXEC se diferente)
# --------------------------
def update_official_script():
    Path(PASTA_OFICIAL).mkdir(parents=True, exist_ok=True)
    Path(PASTA_EXEC).mkdir(parents=True, exist_ok=True)
    oficial = Path(PASTA_OFICIAL) / "criar-pacotes.py"
    execf = Path(PASTA_EXEC) / "criar-pacotes.py"
    try:
        if not oficial.exists():
            # create blank placeholder to avoid previous errors
            with open(oficial, "w", encoding="utf-8") as fh:
                fh.write("# placeholder official criar-pacotes.py\n")
            log(f"Arquivo oficial criado: {oficial}", "INFO")
        # compare bytes
        need = False
        if not execf.exists():
            need = True
        else:
            try:
                if oficial.read_bytes() != execf.read_bytes():
                    need = True
            except Exception:
                need = True
        if need:
            if execf.exists():
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                backup = execf.with_name(f"{execf.stem}_backup_{timestamp}.py")
                shutil.copy2(execf, backup)
                log(f"Backup do script antigo salvo: {backup}", "INFO")
            shutil.copy2(oficial, execf)
            log("Script atualizado automaticamente a partir de OFFICIAL.", "OK")
    except Exception as e:
        log(f"Falha ao atualizar script oficial: {e}", "WARN")

# --------------------------
# MAIN
# --------------------------
def main():
    ensure_dirs()
    log(f"{VERSAO_FULLONE} iniciado. Procurando arquivos...", "INFO")

    # 1) atualizar script oficial se houver
    update_official_script()

    # 2) gather files
    all_files = gather_files()
    log(f"Total scripts found across all search paths: {len(all_files)}", "INFO")

    # counts all found (pre-selection)
    total_ps1 = sum(1 for f in all_files if f.suffix.lower() == ".ps1")
    total_py = sum(1 for f in all_files if f.suffix.lower() == ".py")
    log(f"Arquivos .PS1: {total_ps1}  Arquivos .PY: {total_py}", "INFO")

    # 3) select latest versions by name
    selected = select_latest_versions(all_files)
    log(f"Arquivos selecionados (versão recente): {len(selected)}", "INFO")

    # 4) create unified PS1
    unified = create_unified(selected)

    # 5) create txt copies for package
    txtdir = Path(PASTA_PACKAGE) / "scripts_txt"
    txts = create_txt_copies(selected, txtdir)

    # 6) save list full txt
    list_txt = save_full_list_txt(selected)

    # 7) create zip package (incremental)
    zipf = create_zip_package(unified, txts, selected)

    # 8) generate diagram
    diagram = generate_diagram()

    # 9) generate PDF report
    pdfp = generate_pdf(selected, unified, zipf, diagram, list_txt)

    log(f"{VERSAO_FULLONE} finalizado.", "OK")
    # Summarize
    print("\n=== RESUMO ===")
    print(f"Total encontrados: {len(all_files)}")
    print(f" .ps1: {total_ps1} | .py: {total_py}")
    print(f"Selecionados p/ unificar: {len(selected)}")
    print(f"OneFull gerado em: {unified}")
    print(f"ZIP: {zipf}")
    print(f"PDF relatório: {pdfp}")
    print(f"Lista completa TXT: {list_txt}")
    print("Logs: " + str(PASTA_LOGS))
    print("================\n")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        log("Cancelado pelo usuário.", "WARN")
    except Exception as e:
        log(f"Erro não tratado: {e}", "ERROR")
        log(traceback.format_exc(), "DEBUG")
        sys.exit(1)

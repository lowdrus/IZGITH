Set-ExecutionPolicy Bypass -Scope Process -Force
.\FULLONE-correção4.ps1 -DryRun

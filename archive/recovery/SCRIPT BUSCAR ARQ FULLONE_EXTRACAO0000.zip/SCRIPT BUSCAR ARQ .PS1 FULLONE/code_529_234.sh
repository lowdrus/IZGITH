pip uninstall pypdf
pip uninstall pyfpdf
pip install --upgrade fpdf2

# ==============================
# Inicialização
# ==============================
$RootPath = (Resolve-Path -Path $RootPath).ProviderPath
$now = Get-Date -Format 'yyyyMMdd_HHmmss'

# Diretório de logs
$Global:FULLONE_LogFileDir = Join-Path $RootPath 'logs_FULLONE'
if (!(Test-Path $Global:FULLONE_LogFileDir)) {
    New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null
}
# Arquivo de log correto
$Global:FULLONE_LogFile = Join-Path $Global:FULLONE_LogFileDir ("fullone_log_$now.txt")

Write-Log "FULLONE iniciado. RootPath = $RootPath"
if ($DryRun) { Write-Log "MODO: DRY RUN (simulação). Nenhuma alteração será feita." }

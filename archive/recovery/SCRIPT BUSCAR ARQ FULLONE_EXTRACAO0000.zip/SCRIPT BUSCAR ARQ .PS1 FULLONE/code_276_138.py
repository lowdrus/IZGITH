import os
import zipfile
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

# Caminho onde o ZIP será salvo
package_dir = r"C:\SCRIPTS\PACKAGE"
zip_name = "FULLONEv14_UNIFIED.zip"
zip_path = os.path.join(package_dir, zip_name)

# Criar pasta de destino se não existir
os.makedirs(package_dir, exist_ok=True)

# Função para criar arquivos PDF placeholder
def create_pdf(file_path, title):
    c = canvas.Canvas(file_path, pagesize=letter)
    c.drawString(100, 750, f"Este é o {title}")
    c.drawString(100, 735, "Conteúdo placeholder.")
    c.save()

# Lista de arquivos a serem incluídos no ZIP
files_to_include = [
    ("FULLONE_UNIFIED.ps1", "Conteúdo do script unificado"),
    ("FULLONE.bat", "Conteúdo do batch file"),
    ("TUTORIAL.pdf", "Tutorial"),
    ("MANUAL.pdf", "Manual"),
    ("GUIA-RÁPIDO.pdf", "Guia Rápido")
]

# Criar arquivos e adicionar ao ZIP
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    for file_name, content in files_to_include:
        file_path = os.path.join(package_dir, file_name)
        if file_name.endswith(".pdf"):
            create_pdf(file_path, content)
        else:
            with open(file_path, 'w') as f:
                f.write(content)
        zf.write(file_path, arcname=file_name)

print(f"Pacote criado com sucesso: {zip_path}")

$zipPath = "C:\SCRIPTS\PACKAGE\FULLONEv14_package.zip"
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory("C:\SCRIPTS\PACKAGE\FULLONEv14_package", $zipPath)
Write-Output "ZIP created at: $zipPath"

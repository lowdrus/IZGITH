Write-Log -Message "texto" -Level "WARN"

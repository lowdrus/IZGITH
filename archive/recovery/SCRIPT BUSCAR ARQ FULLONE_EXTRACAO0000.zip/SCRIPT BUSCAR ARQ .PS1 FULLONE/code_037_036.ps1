   .\FULLONE-correção6.ps1 -DryRun:$false -AutoFix -Exec -Deploy -UsePwsh
   
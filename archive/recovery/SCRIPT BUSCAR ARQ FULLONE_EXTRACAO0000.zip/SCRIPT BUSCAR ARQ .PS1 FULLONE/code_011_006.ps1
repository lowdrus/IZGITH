  .\FULLONEv00003.ps1 -DryRun:$false -Exec -UsePwsh
  
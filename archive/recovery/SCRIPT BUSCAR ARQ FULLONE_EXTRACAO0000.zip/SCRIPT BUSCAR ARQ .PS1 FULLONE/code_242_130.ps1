   $allFiles = @()
   foreach ($path in $searchPaths) {
       if (Test-Path $path) {
           $files = Get-ChildItem -Path $path -Recurse -Include *.ps1, *.py -File -ErrorAction SilentlyContinue
           $allFiles += $files
       } else {
           Write-Warning "Path not found (skipped): $path"
       }
   }

   Write-Output "Total scripts found: $($allFiles.Count)"
   
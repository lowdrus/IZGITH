$allFiles = @()
foreach ($path in $searchPaths) {
    if (Test-Path $path) {
        $files = Get-ChildItem -Path $path -Recurse -Include *.ps1, *.py -File -ErrorAction SilentlyContinue
        $allFiles += $files
        Write-Output "Found $($files.Count) files in: $path"
    } else {
        Write-Warning "Path not found (skipped): $path"
    }
}

Write-Output "===================================="
Write-Output "Total scripts found across all paths: $($allFiles.Count)"
Write-Output "===================================="

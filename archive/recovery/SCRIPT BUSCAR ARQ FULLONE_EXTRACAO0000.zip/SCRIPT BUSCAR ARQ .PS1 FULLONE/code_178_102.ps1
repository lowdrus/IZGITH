     .\FULLONE.ps1 -DryRun:$false -AutoFix -Backup
     
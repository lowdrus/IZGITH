import os
import zipfile
from pathlib import Path

# -------------------------------
# CONFIGURAÇÕES DE PASTAS
# -------------------------------

# Pastas onde o script irá procurar arquivos .ps1 e .py
search_paths = [
    # CONAV TRADER
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\collections",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\encodings",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\re",
    r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard\base_library.zip",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\collections",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\re",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\encodings",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar\build",
    r"C:\CONAV TRADER\CONAV_TRADER\mapas de fluxograma",
    r"C:\CONAV TRADER\CONAV_TRADER\PACKAGES OFICIAIS",
    r"C:\CONAV TRADER\CONAV_TRADER\SCRIPT MESTRE",
    # MAGIC QUANTIC TRADER
    r"C:\MAGIC QUANTIC TRADER\MEGA SUITE 001",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE 002",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE 003",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE ALL IN ONE 004",
    # USERAT
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\USERAT\scripts\scripts 2",
    r"C:\USERAT\scripts\scripts 2\compiladao",
    r"C:\USERAT\USERAT_Projeto_Completo",
    r"C:\USERAT\USERAT_Projeto_Completo\scripts",
    r"C:\USERAT\USERAT_Projeto_Completo\scripts\scripts 2",
    r"C:\USERAT\USERAT_Projeto_Completo\scripts\scripts 2\compiladao",
    r"C:\USERAT\USERAT_Projeto_Completo\tutoriais",
    r"C:\USERAT1",
    r"C:\USERAT1\USERAT_Final_Atualizado",
    r"C:\USERAT1\USERAT_Final_Atualizado\scripts",
    r"C:\USERAT2",
    r"C:\USERAT2\RAR USERASTS\USERAT_Final_Atualizado",
    r"C:\USERAT2\RAR USERASTS\USERAT_Final_Atualizado\scripts",
    r"C:\USERAT2\scripts",
    r"C:\USERAT2\SCRPITS PS1",
    r"C:\USERAT2\USERAT_Final_Atualizado",
    # TESTEE / AI Trade Suite
    r"C:\TESTEE 2",
    r"C:\TESTEE 2\A3",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\TESTEE 2\ARQUIVOS",
    r"C:\TESTEE 2\ARQUIVOS\2 ADVANCED",
    r"C:\TESTEE 2\ARQUIVOS\Output",
    r"C:\TESTEE 3\AI_Trade_Suite_Full_Deliverable",
    r"C:\TST DE API E SOFT\ai trade suite\AI_Trade_Suite",
    r"C:\AAAAAAAA",
    r"C:\AAAAAAAA\AI_Trade_Suite_Expanded (3)",
    # UNIC QUANTIC
    r"C:\UNIC QUANTIC",
    r"C:\UNIC QUANTIC\backend",
    r"C:\UNIC QUANTIC\database",
    r"C:\UNIC QUANTIC\frontend",
    r"C:\UNIC QUANTIC\logs",
    r"C:\UNIC QUANTIC\pdfs",
    r"C:\UNIC QUANTIC\scripts",
    r"C:\UNIC QUANTIC\scripts\SCRIPTS OPCIONAIS",
    r"C:\UNIC QUANTIC\scripts\SETUP UNIC PARTE 1",
    r"C:\UNIC QUANTIC\tools"
]

# Pasta para salvar arquivos soltos (se gerados individualmente)
output_individual = Path(r"C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR")

# Pasta para salvar o arquivo unificado
output_unificado = Path(r"C:\SCRIPTS\FULL ONE\ARQUIVOS .PS1 UNIFICADOS")
output_unificado.mkdir(parents=True, exist_ok=True)

# Pasta padrão para ZIP
default_zip_folder = Path(r"C:\SCRIPTS\FULL ONE\PACKAGE")
default_zip_folder.mkdir(parents=True, exist_ok=True)

# -------------------------------
# FUNÇÕES
# -------------------------------

def procurar_arquivos(paths, extensoes=(".ps1", ".py")):
    """Procura arquivos em paths especificados com extensões .ps1 e .py"""
    encontrados = []
    for path in paths:
        p = Path(path)
        if p.exists() and p.is_dir():
            for root, _, files in os.walk(p):
                for file in files:
                    if file.lower().endswith(extensoes):
                        encontrados.append(Path(root) / file)
    return encontrados

def criar_unificado(arquivos, output_folder):
    """Cria arquivo .ps1 unificado"""
    unificado_path = output_folder / "FULLONE_unificado.ps1"
    with open(unificado_path, "w", encoding="utf-8") as uf:
        for arquivo in arquivos:
            uf.write(f"# --- Início do arquivo: {arquivo.name} ---\n")
            with open(arquivo, "r", encoding="utf-8", errors="ignore") as f:
                uf.write(f.read())
            uf.write(f"\n# --- Fim do arquivo: {arquivo.name} ---\n\n")
    return unificado_path

def criar_zip(arquivos, zip_path):
    """Cria ZIP com todos os arquivos listados"""
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for arquivo in arquivos:
            arcname = arquivo.relative_to(arquivo.anchor)  # Mantém estrutura relativa
            zf.write(arquivo, arcname)

# -------------------------------
# EXECUÇÃO PRINCIPAL
# -------------------------------

print("Procurando arquivos .ps1 e .py nas pastas configuradas...")
arquivos_encontrados = procurar_arquivos(search_paths)
print(f"Total de arquivos encontrados: {len(arquivos_encontrados)}")

# Listar todos os arquivos encontrados
for arquivo in arquivos_encontrados:
    print(arquivo)

# Criar arquivo unificado
unificado = criar_unificado(arquivos_encontrados, output_unificado)
print(f"\nArquivo unificado criado em: {unificado}")

# Perguntar ao usuário onde salvar o ZIP
zip_input = input(f"\nInforme o caminho para salvar o ZIP (Enter para pasta padrão {default_zip_folder}): ").strip()
if zip_input:
    zip_folder = Path(zip_input)
    zip_folder.mkdir(parents=True, exist_ok=True)
else:
    zip_folder = default_zip_folder

zip_path = zip_folder / "FULLONEv14fixed2.zip"
criar_zip(arquivos_encontrados, zip_path)
print(f"ZIP criado em: {zip_path}")

print("\nProcesso concluído com sucesso!")

Write-Log ("Falha no deploy {0}: {1}" -f $t, $_.Exception.Message) -Level "ERROR"

# 1) vá para a pasta do script (ajuste se necessário)
Set-Location "C:\CONAV TRADER\CONAV_TRADER\CONAV MASTER FULL\FULLONEMASTER"

# 2) listar arquivos matching para confirmar
Get-ChildItem -Filter "FULLONE*.ps1" | Select-Object Name, FullName, LastWriteTime

# 3) renomear o arquivo (se o nome exato tem acento)
# se o nome for exatamente "FULLONE-correção9.ps1", execute:
Rename-Item -LiteralPath "FULLONE-correção9.ps1" -NewName "FULLONE-correccao9.ps1"

# --- OU (mais seguro, caso o nome esteja já com mojibake) ---
# encontra o PS1 mais recente que começa com FULLONE e renomeia
$psfile = Get-ChildItem -Filter "FULLONE*.ps1" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($psfile) { Rename-Item -LiteralPath $psfile.FullName -NewName "FULLONE-correccao9.ps1" -Force }

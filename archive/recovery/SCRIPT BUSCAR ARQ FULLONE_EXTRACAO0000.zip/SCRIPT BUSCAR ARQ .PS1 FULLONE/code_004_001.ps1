<#
================================================================================
 SCRIPT: BUSCAR-TODOS-SCRIPTS.ps1
 OBJETIVO:
   - Buscar todos os .ps1 e .py dentro da pasta raiz especificada
   - Contar arquivos
   - Detectar duplicados (por conteúdo e por nome)
   - Corrigir caracteres problemáticos (opcional, SafeFix)
   - Compilar todos em 1 único .ps1
   - Relatório detalhado e log
   - Script separado do CONAV (independente)

 AUTOR: Assistente Automação
================================================================================
#>

param(
    [string]$RootPath = 'C:\CONAV TRADER\CONAV_TRADER',
    [switch]$DryRun = $true,
    [switch]$AutoFix = $false,
    [switch]$Backup = $true
)

# ==============================
# Função de log
# ==============================
function Write-Log {
    param(
        [string]$Message,
        [string]$Level = 'INFO'
    )
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = "[$ts][$Level] $Message"

    if (!(Test-Path $Global:FULLONE_LogFileDir)) {
        New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null
    }
    Add-Content -Path $Global:FULLONE_LogFile -Value $line -Encoding UTF8
    Write-Host $line
}

# ==============================
# Inicialização
# ==============================
$RootPath = (Resolve-Path -Path $RootPath).ProviderPath
$now = Get-Date -Format 'yyyyMMdd_HHmmss'

$Global:FULLONE_LogFileDir = Join-Path $RootPath 'logs_FULLONE'
$Global:FULLONE_LogFile = Join-Path $Global:FULLONE_LogFileDir ("fullone_log_$now.txt")

if (!(Test-Path $Global:FULLONE_LogFileDir)) {
    New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null
}

Write-Log "FULLONE iniciado (BUSCAR-TODOS-SCRIPTS). RootPath = $RootPath"
if ($DryRun) { Write-Log "MODO: DRY RUN (simulação). Nenhuma alteração será feita." }

# ==============================
# Localizar arquivos .ps1 e .py
# ==============================
Write-Log "Procurando arquivos .ps1 e .py recursivamente..."

$files = Get-ChildItem -Path $RootPath -Recurse -File -ErrorAction SilentlyContinue `
    | Where-Object { $_.Extension -in '.ps1', '.py' }

$totalCount = $files.Count
Write-Log "Total encontrado: $totalCount arquivos (.ps1/.py)."

# ==============================
# Relatório inicial
# ==============================
$reportFile = Join-Path $RootPath ("relatorio_FULLONE_$now.txt")
$summary = @()
$summary += "Relatório FULLONE - $now"
$summary += "RootPath: $RootPath"
$summary += "Total scripts encontrados: $totalCount"
$summary += ""

# ==============================
# Duplicados por conteúdo (hash)
# ==============================
Write-Log "Verificando duplicados por conteúdo (hash)..."
$hashMap = @{}
foreach ($f in $files) {
    try {
        $h = Get-FileHash -Path $f.FullName -Algorithm SHA256
        if (-not $hashMap.ContainsKey($h.Hash)) { $hashMap[$h.Hash] = @() }
        $hashMap[$h.Hash] += $f
    } catch {
        Write-Log "Falha ao calcular hash de $($f.FullName): $($_.Exception.Message)" "WARN"
    }
}
$dupByContent = $hashMap.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }

if ($dupByContent.Count -gt 0) {
    $summary += "Duplicados por conteúdo: $($dupByContent.Count) grupos"
    foreach ($g in $dupByContent) {
        $summary += "Hash: $($g.Key)"
        foreach ($f in $g.Value) {
            $summary += "   $($f.FullName)"
        }
    }
} else {
    $summary += "Nenhum duplicado de conteúdo encontrado."
}

# ==============================
# Duplicados por nome
# ==============================
Write-Log "Verificando arquivos com mesmo nome..."
$byName = @{}
foreach ($f in $files) {
    if (-not $byName.ContainsKey($f.Name)) { $byName[$f.Name] = @() }
    $byName[$f.Name] += $f
}
$dupByName = $byName.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }

if ($dupByName.Count -gt 0) {
    $summary += ""
    $summary += "Arquivos com mesmo nome em múltiplas pastas: $($dupByName.Count)"
    foreach ($g in $dupByName) {
        $summary += "Nome: $($g.Key)"
        foreach ($f in $g.Value) {
            $summary += "   $($f.FullName)"
        }
    }
} else {
    $summary += "Nenhum arquivo duplicado por nome encontrado."
}

# ==============================
# Função SafeFix
# ==============================
function Safe-FixFile {
    param(
        [string]$Path,
        [switch]$BackupBefore
    )
    $actions = @()

    if ($BackupBefore) {
        $backupDir = Join-Path $RootPath ("BACKUP_FULLONE_$now")
        if (!(Test-Path $backupDir)) { New-Item -ItemType Directory -Path $backupDir -Force | Out-Null }
        $dest = Join-Path $backupDir ((Split-Path $Path -Leaf) + ".bak")
        Copy-Item -Path $Path -Destination $dest -Force
        $actions += "Backup criado: $dest"
    }

    try {
        $raw = Get-Content -Raw -LiteralPath $Path
    } catch {
        return @{ success = $false; msg = "Falha ao ler: $($_.Exception.Message)"; actions=$actions }
    }

    $orig = $raw
    $raw = $raw -replace "[\u201C\u201D]",'"'
    $raw = $raw -replace "[\u2018\u2019]","'"
    $raw = $raw -replace "…","..."
    $raw = $raw -replace "\u00A0"," "
    if ($raw.StartsWith([char]0xFEFF)) { $raw = $raw.Substring(1); $actions += "BOM removido" }

    if ($raw -ne $orig) {
        if ($DryRun) {
            return @{ success = $true; changed = $true; msg = "Alterações simuladas"; actions=$actions }
        } else {
            $raw | Out-File -LiteralPath $Path -Encoding UTF8 -Force
            return @{ success = $true; changed = $true; msg = "Alterações aplicadas"; actions=$actions }
        }
    } else {
        return @{ success = $true; changed = $false; msg = "Nenhuma alteração necessária"; actions=$actions }
    }
}

# ==============================
# Aplicar SafeFix (se solicitado)
# ==============================
$fixSummary = @()
if ($AutoFix) {
    Write-Log "Rodando SafeFix em todos os arquivos..."
    foreach ($f in $files) {
        $res = Safe-FixFile -Path $f.FullName -BackupBefore:$Backup
        $fixSummary += ("{0} => {1}" -f $f.FullName, $res.msg)
        foreach ($a in $res.actions) { Write-Log "   $a" }
    }
}

# ==============================
# Compilação em FULLONE_COMPILED.ps1
# ==============================
Write-Log "Gerando compilado FULLONE_COMPILED..."
$compiledFolder = Join-Path $RootPath "FULLONE_COMPILED"
if (!(Test-Path $compiledFolder)) { New-Item -ItemType Directory -Path $compiledFolder -Force | Out-Null }
$compiledPath = Join-Path $compiledFolder ("FULLONE_COMPILED_$now.ps1")

$compiledContent = @()
$compiledContent += "# FULLONE_COMPILED - gerado em $now"
$compiledContent += "# Root: $RootPath"
$compiledContent += ""

foreach ($f in $files) {
    $compiledContent += "##############################################################################"
    $compiledContent += "# INICIO: $($f.FullName)"
    try {
        $txt = Get-Content -Raw -LiteralPath $f.FullName
        if ($f.Extension -eq ".py") {
            $compiledContent += "<# PYTHON SCRIPT ORIGEM #>"
            $compiledContent += $txt
            $compiledContent += "<# FIM PYTHON #>"
        } else {
            $compiledContent += $txt
        }
    } catch {
        $compiledContent += "# Falha ao incluir $($f.FullName): $($_.Exception.Message)"
    }
    $compiledContent += "# FIM: $($f.FullName)"
    $compiledContent += "##############################################################################"
    $compiledContent += ""
}

if ($DryRun) {
    $compiledSim = $compiledPath + ".simulado.txt"
    $compiledContent | Out-File -FilePath $compiledSim -Encoding UTF8
    Write-Log "Compilado simulado salvo em: $compiledSim"
} else {
    $compiledContent | Out-File -FilePath $compiledPath -Encoding UTF8
    Write-Log "Compilado salvo em: $compiledPath"
}

# ==============================
# Salvar relatório final
# ==============================
if ($AutoFix) {
    $summary += ""
    $summary += "Resumo SafeFix:"
    $summary += $fixSummary
}
$summary += ""
$summary += "Fim do relatório."

$summary | Out-File -FilePath $reportFile -Encoding UTF8
Write-Log "Relatório salvo em: $reportFile"
Write-Log "Execução finalizada."

# =====================================================================
# Identificação do .ps1 mais atualizado
# =====================================================================
try {
    $latestPs1 = $files | Where-Object { $_.Extension -eq ".ps1" } | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($latestPs1) {
        $msg = "Script .ps1 mais recente: {0} (LastWrite: {1})" -f $latestPs1.FullName, $latestPs1.LastWriteTime
        Write-Log -Message $msg -Level "INFO"
        $report.Add($msg)
    } else {
        Write-Log -Message "Nenhum arquivo .ps1 encontrado no diretório." -Level "WARN"
    }
} catch {
    Write-Log -Message ("Erro verificando .ps1 mais recente: {0}" -f $_.Exception.Message) -Level "ERROR"
}

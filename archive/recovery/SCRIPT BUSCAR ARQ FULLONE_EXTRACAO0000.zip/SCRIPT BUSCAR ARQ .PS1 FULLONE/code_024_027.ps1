.\FULLONE-correção4.ps1 -AutoFix -Exec -Deploy

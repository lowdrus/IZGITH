     Set-ExecutionPolicy Bypass -Scope Process -Force
     .\FULLONE.ps1
     
$files = Get-ChildItem -Path $RootPath -Recurse -File -ErrorAction SilentlyContinue |
    Where-Object { $_.Extension -in '.ps1', '.py' } |
    Where-Object { -not (Path-IsIgnored -FullName $_.FullName) } |
    Where-Object { $_.FullName -ne $PSCommandPath -and $_.FullName -ne $MyInvocation.MyCommand.Definition }

$totalCount = $files.Count
Write-Log -Message ("Total encontrado: {0} arquivos (.ps1/.py)." -f $totalCount) -Level "INFO"

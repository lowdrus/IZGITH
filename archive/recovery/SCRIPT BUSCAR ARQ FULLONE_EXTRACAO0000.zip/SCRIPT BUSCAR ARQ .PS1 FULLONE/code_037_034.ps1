<#
FULLONE-correção6.ps1
Versão corrigida: Write-Log definido antes de qualquer uso; abre o tutorial PDF no final (se existir).
#>

param(
    [string]$RootPath = 'C:\CONAV TRADER\CONAV_TRADER',
    [switch]$DryRun = $true,
    [switch]$AutoFix = $false,
    [switch]$Backup = $true,
    [switch]$Exec = $false,
    [switch]$UsePwsh = $false,
    [switch]$Deploy = $true
)

Set-StrictMode -Version Latest

# ---------------------------
# Função de log (sempre definida primeiro)
# - é robusta: cria diretório/arquivo se necessário
# - usa ${Global:FULLONE_LogFile} para evitar parser errors com ':'
# - imprime cores no console
# ---------------------------
function Write-Log {
    param(
        [string]$Message,
        [string]$Level = 'INFO'
    )

    # garante variáveis globais mínimas
    if (-not $Global:FULLONE_LogFileDir) {
        try {
            $Global:FULLONE_LogFileDir = Join-Path -Path (Get-Location) -ChildPath 'logs_FULLONE'
        } catch {
            $Global:FULLONE_LogFileDir = ".\logs_FULLONE"
        }
    }
    if (-not (Test-Path -LiteralPath $Global:FULLONE_LogFileDir -PathType Container)) {
        try { New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null } catch {}
    }

    if (-not $Global:FULLONE_LogFile) {
        try {
            $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
            $Global:FULLONE_LogFile = Join-Path -Path $Global:FULLONE_LogFileDir -Child ("fullone_log_$stamp.txt")
        } catch {
            $Global:FULLONE_LogFile = Join-Path -Path $Global:FULLONE_LogFileDir -Child "fullone_log.txt"
        }
    }

    # garante que o arquivo exista
    if (-not (Test-Path -LiteralPath $Global:FULLONE_LogFile -PathType Leaf)) {
        try { New-Item -ItemType File -Path $Global:FULLONE_LogFile -Force | Out-Null } catch {}
    }

    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = "[$ts][$Level] $Message"

    # grava em arquivo (silencioso se falhar)
    try {
        Add-Content -Path $Global:FULLONE_LogFile -Value $line -Encoding UTF8
    } catch {
        Write-Warning "Falha escrevendo log em ${Global:FULLONE_LogFile}: $($_.Exception.Message)"
    }

    # imprime colorido no console
    switch ($Level.ToUpper()) {
        'INFO'  { Write-Host $line -ForegroundColor White }
        'OK'    { Write-Host $line -ForegroundColor Green }
        'WARN'  { Write-Host $line -ForegroundColor Yellow }
        'ERROR' { Write-Host $line -ForegroundColor Red }
        default { Write-Host $line -ForegroundColor Gray }
    }
}

# ---------------------------
# Pequena utilidade join path segura
# ---------------------------
function Safe-JoinPath {
    param([string]$Path, [string]$Child)
    return Join-Path -Path $Path -ChildPath $Child
}

# ---------------------------
# Inicialização (definir diretórios/arquivo de log com timestamp consistente)
# ---------------------------
try {
    $RootPath = (Resolve-Path -Path $RootPath -ErrorAction Stop).ProviderPath
} catch {
    Write-Host "RootPath inválido: $RootPath" -ForegroundColor Red
    exit 1
}

$now = Get-Date -Format 'yyyyMMdd_HHmmss'

# define global logdir/file exatamente aqui (Write-Log já existe)
$Global:FULLONE_LogFileDir = Safe-JoinPath -Path $RootPath -Child "logs_FULLONE"
if (-not (Test-Path -LiteralPath $Global:FULLONE_LogFileDir -PathType Container)) {
    try { New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null } catch { Write-Warning "Não foi possível criar $Global:FULLONE_LogFileDir" }
}
$Global:FULLONE_LogFile = Safe-JoinPath -Path $Global:FULLONE_LogFileDir -Child ("fullone_log_$now.txt")
if (-not (Test-Path -LiteralPath $Global:FULLONE_LogFile -PathType Leaf)) {
    try { New-Item -ItemType File -Path $Global:FULLONE_LogFile -Force | Out-Null } catch { Write-Warning "Não foi possível criar o arquivo de log $Global:FULLONE_LogFile" }
}

Write-Log "FULLONE iniciado. RootPath = $RootPath"
if ($DryRun) { Write-Log "MODO: DRY RUN (simulação). Nenhuma alteração será feita." }

# ---------------------------
# Ignorar padrões e listar arquivos
# ---------------------------
$ignorePatterns = @('\\.git\\','\\node_modules\\','\\dist\\','\\build\\','\\FULLONE_COMPILED\\','\\BACKUP_FULLONE_','\\logs_FULLONE\\')

function Path-IsIgnored { param([string]$FullName) foreach ($p in $ignorePatterns) { if ($FullName -match $p) { return $true } } return $false }

Write-Log "Procurando arquivos .ps1 e .py recursivamente..."
try {
    $files = Get-ChildItem -Path $RootPath -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Extension -in '.ps1', '.py' } |
        Where-Object { -not (Path-IsIgnored -FullName $_.FullName) } |
        Where-Object { $_.FullName -ne $PSCommandPath -and $_.FullName -ne $MyInvocation.MyCommand.Definition }
} catch {
    Write-Log "Erro listando arquivos: $($_.Exception.Message)" "ERROR"
    $files = @()
}

$totalCount = $files.Count
Write-Log "Total encontrado: $totalCount arquivos (.ps1/.py)."

# relatório inicial
$reportFile = Safe-JoinPath -Path $RootPath -Child ("relatorio_FULLONE_$now.txt")
$summary = New-Object System.Collections.Generic.List[string]
$summary.Add("FULLONE Report - $now")
$summary.Add("RootPath: $RootPath")
$summary.Add("Total scripts found: $totalCount")
$summary.Add("")

# ---------------------------
# Duplicados por hash e por nome
# ---------------------------
Write-Log "Calculando hashes (SHA256) para identificar duplicados..."
$hashMap = @{}
$byName = @{}
foreach ($f in $files) {
    try {
        $h = Get-FileHash -Path $f.FullName -Algorithm SHA256 -ErrorAction Stop
        $hash = $h.Hash
    } catch {
        Write-Log "Falha ao calcular hash de $($f.FullName): $($_.Exception.Message)" "WARN"
        $hash = "ERROR_$([guid]::NewGuid().ToString())"
    }
    if (-not $hashMap.ContainsKey($hash)) { $hashMap[$hash] = New-Object System.Collections.ArrayList }
    $hashMap[$hash].Add($f) | Out-Null

    if (-not $byName.ContainsKey($f.Name)) { $byName[$f.Name] = New-Object System.Collections.ArrayList }
    $byName[$f.Name].Add($f) | Out-Null
}

$dupByContent = $hashMap.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }
if ($dupByContent.Count -gt 0) {
    Write-Log "Duplicados por conteúdo encontrados: $($dupByContent.Count) grupos." "WARN"
    $summary.Add("Duplicados por conteúdo (grupos): $($dupByContent.Count)")
    foreach ($g in $dupByContent) {
        $summary.Add("GrupoHash: $($g.Key)")
        foreach ($item in $g.Value) { $summary.Add("    $($item.FullName) (modified: $($item.LastWriteTime))") }
    }
} else {
    $summary.Add("Nenhum duplicado de conteúdo detectado.")
    Write-Log "Nenhum duplicado por conteúdo detectado." "OK"
}

$dupByName = $byName.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }
if ($dupByName.Count -gt 0) {
    Write-Log "Mesmo nome em múltiplas localizações: $($dupByName.Count) nomes." "WARN"
    $summary.Add("")
    $summary.Add("Arquivos com mesmo nome em múltiplas pastas: $($dupByName.Count)")
    foreach ($g in $dupByName) {
        $summary.Add("Nome: $($g.Key)")
        foreach ($item in $g.Value) {
            $summary.Add("    $($item.FullName) (LastWrite: $($item.LastWriteTime), Size: $($item.Length))")
        }
        $latest = $g.Value | Sort-Object LastWriteTime -Descending | Select-Object -First 1
        $summary.Add("    -> Sugerido manter (mais recente): $($latest.FullName)")
    }
} else {
    $summary.Add("Nenhum arquivo com mesmo nome em múltiplos locais.")
}

# salva resumo inicial
try { $summary | Out-File -FilePath $reportFile -Encoding UTF8 -Force } catch { Write-Log "Falha salvando relatório inicial: $($_.Exception.Message)" "WARN" }

# ---------------------------
# Safe-Fix function
# ---------------------------
function Safe-FixFile {
    param([string]$Path,[switch]$BackupBefore)
    $actions = New-Object System.Collections.ArrayList

    if ($BackupBefore) {
        $backupDir = Safe-JoinPath -Path $RootPath -Child ("BACKUP_FULLONE_$now")
        if (-not (Test-Path -LiteralPath $backupDir -PathType Container)) { New-Item -ItemType Directory -Path $backupDir -Force | Out-Null }
        $dest = Safe-JoinPath -Path $backupDir -Child ((Split-Path $Path -Leaf) + ".bak")
        try { Copy-Item -LiteralPath $Path -Destination $dest -Force } catch { $actions.Add("Falha criando backup: $($_.Exception.Message)") | Out-Null }
        $actions.Add("Backup: $dest") | Out-Null
    }

    try { $raw = Get-Content -Raw -LiteralPath $Path -ErrorAction Stop } catch { return @{ success = $false; message = "Falha ao ler: $($_.Exception.Message)"; actions=$actions } }

    $orig = $raw
    $raw = $raw -replace "[\u201C\u201D]", '"' -replace "[\u2018\u2019]", "'" -replace "…", "..." -replace "\u00A0", " "
    if ($raw.Length -gt 0 -and $raw[0] -eq [char]0xFEFF) { $raw = $raw.Substring(1); $actions.Add("Removed BOM") | Out-Null }

    if ($raw -ne $orig) {
        if ($DryRun) {
            $actions.Add("CHANGES (simulado)") | Out-Null
            return @{ success = $true; changed = $true; message = "Simulado: alterações sugeridas"; actions=$actions }
        } else {
            try {
                $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
                [System.IO.File]::WriteAllText($Path, $raw, $utf8NoBom)
                $actions.Add("Saved changes (UTF8 no BOM)") | Out-Null
                return @{ success = $true; changed = $true; message = "Alterações aplicadas"; actions=$actions }
            } catch {
                return @{ success = $false; changed = $false; message = "Falha ao salvar: $($_.Exception.Message)"; actions=$actions }
            }
        }
    } else {
        return @{ success = $true; changed = $false; message = "Nenhuma alteração necessária"; actions=$actions }
    }
}

# ---------------------------
# AutoFix (opcional)
# ---------------------------
$fixSummary = New-Object System.Collections.ArrayList
if ($AutoFix) {
    Write-Log "AutoFix solicitado. Preparando aplicação de correções seguras."
    if ($DryRun) { Write-Log "Nota: Em DryRun; AutoFix apenas simulado." }
    $confirm = $true
    if (-not $DryRun) {
        try {
            $choice = Read-Host "Você quer realmente aplicar AutoFix em todos os arquivos encontrados? (S/N)"
            if ($choice.ToUpper() -ne 'S') { $confirm = $false; Write-Log "AutoFix CANCELADO pelo usuário." }
        } catch { $confirm = $true }
    }
    if ($confirm) {
        foreach ($f in $files) {
            Write-Log "Analisando para fix: $($f.FullName)"
            $res = Safe-FixFile -Path $f.FullName -BackupBefore:$Backup
            if ($res.success) {
                $fixSummary.Add(("{0} => {1} - {2}" -f $f.FullName, ($res.changed -eq $true ? "CHANGED":"UNCHANGED"), $res.message)) | Out-Null
                foreach ($a in $res.actions) { Write-Log "    $a" }
            } else {
                Write-Log "Erro no Safe-FixFile: $($res.message)" "ERROR"
            }
        }
        Write-Log "AutoFix finalizado (ou simulado)."
    }
}

# ---------------------------
# Compilado
# ---------------------------
Write-Log "Gerando arquivo compilado FULLONE_COMPILED..."
$compiledFolder = Safe-JoinPath -Path $RootPath -Child 'FULLONE_COMPILED'
if (-not (Test-Path -LiteralPath $compiledFolder -PathType Container)) { New-Item -ItemType Directory -Path $compiledFolder -Force | Out-Null }
$compiledPath = Safe-JoinPath -Path $compiledFolder -Child ("FULLONE_COMPILED_$now.ps1")

$header = @()
$header += "# FULLONE_COMPILED - gerado em $now"
$header += "# Root: $RootPath"
foreach ($f in $files) { $header += ("# - {0} (LastWrite: {1})" -f $f.FullName, $f.LastWriteTime) }
$header += ""

$compiledContent = $header -join "`r`n" + "`r`n"
foreach ($f in $files) {
    $compiledContent += "`r`n"
    $compiledContent += "##############################################################################`r`n"
    $compiledContent += "# INICIO: $($f.FullName)`r`n"
    $compiledContent += "##############################################################################`r`n"
    try {
        $txt = Get-Content -Raw -LiteralPath $f.FullName -ErrorAction Stop
        if ($f.Extension.ToLower() -eq '.py') {
            $compiledContent += "<# PY: origem: $($f.FullName) #>`r`n"
            $compiledContent += $txt + "`r`n"
            $compiledContent += "<# FIM PY #>`r`n"
        } else {
            $compiledContent += $txt + "`r`n"
        }
    } catch {
        Write-Log "Falha lendo $($f.FullName) para inclusão compilada: $($_.Exception.Message)" "WARN"
        $compiledContent += "# Falha ao incluir $($f.FullName): $($_.Exception.Message)`r`n"
    }
    $compiledContent += "`r`n"
    $compiledContent += "##############################################################################`r`n"
    $compiledContent += "# FIM: $($f.FullName)`r`n"
    $compiledContent += "##############################################################################`r`n"
}

if ($DryRun) {
    $simulatedCompiledPath = $compiledPath + ".simulado.txt"
    try {
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($simulatedCompiledPath, $compiledContent, $utf8NoBom)
        Write-Log "Em DryRun: compilado simulado salvo em: $simulatedCompiledPath" "OK"
    } catch { Write-Log "Falha salvando compilado simulado: $($_.Exception.Message)" "WARN" }
} else {
    try {
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($compiledPath, $compiledContent, $utf8NoBom)
        Write-Log "Arquivo compilado salvo em: $compiledPath" "OK"
    } catch { Write-Log "Falha ao salvar compilado: $($_.Exception.Message)" "ERROR" }
}

# ---------------------------
# Execução isolada
# ---------------------------
if ($Exec) {
    Write-Log "Execução isolada de cada script solicitada. Será executado em processos separados."
    if ($DryRun) { Write-Log "OBS: Execução em DryRun (simulação) - nada será executado)." }
    foreach ($f in $files) {
        Write-Log "Preparando execução: $($f.FullName)"
        if ($DryRun) { Write-Log "Simulado: executar $($f.FullName)"; continue }
        if ($f.Extension.ToLower() -eq '.py') {
            try {
                $proc = Start-Process -FilePath 'python' -ArgumentList @($f.FullName) -Wait -NoNewWindow -PassThru -ErrorAction Stop
                Write-Log "Processo finalizado: ExitCode $($proc.ExitCode)" "OK"
            } catch { Write-Log "Falha ao executar python $($f.FullName): $($_.Exception.Message)" "ERROR" }
        } else {
            $psExe = if ($UsePwsh) { 'pwsh' } else { 'powershell' }
            $arg = "-NoProfile -ExecutionPolicy Bypass -File `"$($f.FullName)`""
            try {
                $proc = Start-Process -FilePath $psExe -ArgumentList $arg -Wait -NoNewWindow -PassThru -ErrorAction Stop
                Write-Log "Processo finalizado: ExitCode $($proc.ExitCode)" "OK"
            } catch { Write-Log "Falha ao executar $($f.FullName): $($_.Exception.Message)" "ERROR" }
        }
    }
}

# ---------------------------
# Deploy / versionamento do FULLONE (opcional)
# ---------------------------
if ($Deploy) {
    Write-Log "Deploy solicitado: copiando compilado para pastas de integração."
    $targets = @(
        Safe-JoinPath -Path $RootPath -Child 'DEPLOY_FULLONE',
        Safe-JoinPath -Path $RootPath -Child 'CONAV MASTER FULL\FULLONEMASTER',
        Safe-JoinPath -Path $RootPath -Child 'MAGIC QUANTIC TRADER'
    )
    foreach ($t in $targets) {
        if (-not (Test-Path -LiteralPath $t -PathType Container)) { try { New-Item -ItemType Directory -Path $t -Force | Out-Null } catch { Write-Log "Falha criando target $t: $($_.Exception.Message)" "WARN" } }
        if ($DryRun) { Write-Log "Simulado: copiar $compiledPath -> $t" } else {
            try { Copy-Item -LiteralPath $compiledPath -Destination $t -Force; Write-Log "Copiado compilado -> $t" "OK" } catch { Write-Log "Falha no deploy $t: $($_.Exception.Message)" "ERROR" }
        }
    }
}

# ---------------------------
# Relatório final e encerramento
# ---------------------------
$report = New-Object System.Collections.Generic.List[string]
$report.AddRange($summary)
$report.Add("")
$report.Add("Detalhes:")
$report.Add("Total arquivos: $totalCount")
$report.Add("Duplicados por conteúdo (grupos): $($dupByContent.Count)")
$report.Add("Mesmo nome em múltiplas pastas: $($dupByName.Count)")
$report.Add("")
if ($AutoFix) {
    $report.Add("AutoFix summary:")
    $fixSummary | ForEach-Object { $report.Add($_) }
}
$report.Add("")
$report.Add("Compiled file: " + (if ($DryRun) { $simulatedCompiledPath } else { $compiledPath }))
$report.Add("")
$report.Add("LOG: " + $Global:FULLONE_LogFile)
$report.Add("")
$report.Add("Fim do relatório.")

try { $report | Out-File -FilePath $reportFile -Encoding UTF8 -Force } catch { Write-Log "Falha salvando relatório final: $($_.Exception.Message)" "ERROR" }

Write-Log "Execução finalizada." "OK"

# ---------------------------
# Abrir tutorial PDF automaticamente (se existir no mesmo diretório do script)
# ---------------------------
try {
    $scriptDir = $PSScriptRoot
    if (-not $scriptDir) { $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition }
    $tutorialPath = Safe-JoinPath -Path $scriptDir -Child "Tutorial_FULLONE_v5.pdf"
    if (Test-Path -LiteralPath $tutorialPath -PathType Leaf) {
        Write-Log "Abrindo tutorial: $tutorialPath" "INFO"
        try { Start-Process -FilePath $tutorialPath -ErrorAction Stop } catch { Write-Log "Falha ao abrir tutorial: $($_.Exception.Message)" "WARN" }
    } else {
        Write-Log "Tutorial PDF não encontrado no diretório do script: ${tutorialPath}" "WARN"
    }
} catch {
    Write-Log "Erro tentando abrir tutorial PDF: $($_.Exception.Message)" "WARN"
}

# fim do script

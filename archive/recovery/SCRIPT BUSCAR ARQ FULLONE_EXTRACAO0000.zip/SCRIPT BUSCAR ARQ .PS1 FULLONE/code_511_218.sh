  mkdir -p scripts/ps1
  mkdir -p scripts/py
  
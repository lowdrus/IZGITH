import os
import shutil
import zipfile
import datetime

# ----------------------------
# CONFIGURAÇÕES DE PASTAS
# ----------------------------

PASTA_OFICIAL = r"C:\SCRIPTS\FULL ONE\OFFICIAL"  # Pasta onde estará sempre a versão oficial do criar-pacotes.py
PASTA_EXEC = r"C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR"
PASTA_UNIFICADOS = r"C:\SCRIPTS\FULL ONE\ARQUIVOS .PS1 UNIFICADOS"
PASTA_PACKAGE = r"C:\SCRIPTS\FULL ONE\PACKAGE"
PASTA_COMPILADOS = r"C:\SCRIPTS\FULL ONE\COMPILADOS"

VERSAO_FULLONE = "FULLONEv14fixed2"

# Pastas que serão procuradas (adicione/remova conforme necessário)
PASTAS_PROCURA = [
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip",
    r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard\base_library.zip",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip",
    r"C:\MAGIC QUANTIC TRADER\MEGA SUITE 001",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE 002",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE 003",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE ALL IN ONE 004",
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\UNIC QUANTIC",
    r"C:\UNIC QUANTIC\scripts",
]

# ----------------------------
# FUNÇÕES
# ----------------------------

def atualizar_script_oficial():
    """Atualiza o criar-pacotes.py a partir da pasta oficial."""
    arquivo_oficial = os.path.join(PASTA_OFICIAL, "criar-pacotes.py")
    arquivo_exec = os.path.join(PASTA_EXEC, "criar-pacotes.py")

    if not os.path.exists(arquivo_oficial):
        print(f"[AVISO] Nenhum arquivo oficial encontrado em: {PASTA_OFICIAL}")
        return

    atualizar = False
    if not os.path.exists(arquivo_exec):
        atualizar = True
    else:
        # comparar conteúdo
        with open(arquivo_oficial, "rb") as f1, open(arquivo_exec, "rb") as f2:
            if f1.read() != f2.read():
                atualizar = True

    if atualizar:
        # faz backup do antigo
        if os.path.exists(arquivo_exec):
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = os.path.join(PASTA_EXEC, f"criar-pacotes_backup_{timestamp}.py")
            shutil.copy2(arquivo_exec, backup_path)
            print(f"[INFO] Backup do script antigo salvo em: {backup_path}")

        # copia a versão oficial
        shutil.copy2(arquivo_oficial, arquivo_exec)
        print(f"[INFO] Script atualizado automaticamente para a versão oficial.")

def buscar_arquivos():
    """Busca todos os arquivos .ps1 e .py nas pastas definidas"""
    todos_arquivos = []
    for pasta in PASTAS_PROCURA:
        if not os.path.exists(pasta):
            continue
        for root, dirs, files in os.walk(pasta):
            for file in files:
                if file.lower().endswith((".ps1", ".py")):
                    todos_arquivos.append(os.path.join(root, file))
    return todos_arquivos

def criar_unificado(arquivos, pasta_saida):
    """Cria um arquivo .ps1 unificado com todos os scripts encontrados"""
    if not os.path.exists(pasta_saida):
        os.makedirs(pasta_saida)
    unificado_path = os.path.join(pasta_saida, "ONEFULL.ps1")
    with open(unificado_path, "w", encoding="utf-8") as unificado:
        # adiciona cabeçalho
        unificado.write(f"# FULLONE Unificado - Versão {VERSAO_FULLONE}\n\n")
        for arquivo in arquivos:
            try:
                with open(arquivo, "r", encoding="utf-8") as f:
                    unificado.write(f"# ===== {os.path.basename(arquivo)} =====\n")
                    unificado.write(f.read() + "\n\n")
            except UnicodeDecodeError:
                print(f"[ERRO] Não foi possível ler o arquivo (problema de encoding): {arquivo}")
    print(f"[OK] Arquivo unificado criado: {unificado_path}")
    return unificado_path

def criar_zip(unificado_path):
    """Cria o ZIP na pasta PACKAGE, com versão incremental"""
    if not os.path.exists(PASTA_PACKAGE):
        os.makedirs(PASTA_PACKAGE)

    i = 1
    while True:
        zip_name = f"{VERSAO_FULLONE}_{i:04d}.zip"
        zip_path = os.path.join(PASTA_PACKAGE, zip_name)
        if not os.path.exists(zip_path):
            break
        i += 1

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(unificado_path, os.path.basename(unificado_path))
    print(f"[OK] ZIP criado: {zip_path}")

# ----------------------------
# EXECUÇÃO
# ----------------------------

if __name__ == "__main__":
    print("=== FULLONE - GERADOR AUTOMÁTICO v14fixed2 ===\n")

    # 1. Atualiza o próprio script se houver versão oficial
    atualizar_script_oficial()

    # 2. Busca todos os arquivos
    todos_arquivos = buscar_arquivos()
    print(f"[INFO] Total de arquivos encontrados (.ps1 e .py): {len(todos_arquivos)}")
    for f in todos_arquivos:
        print(f" - {f}")

    # 3. Cria arquivo unificado
    unificado = criar_unificado(todos_arquivos, PASTA_UNIFICADOS)

    # 4. Cria ZIP incremental
    criar_zip(unificado)

    print("\n=== FIM DO PROCESSO ===")

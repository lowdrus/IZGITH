<#
FULLONE-correção7.ps1
Versão corrigida: Write-Log definida antes de qualquer uso; chamadas nomeadas; evita parser errors.
#>

param(
    [string]$RootPath = 'C:\CONAV TRADER\CONAV_TRADER',
    [switch]$DryRun = $true,
    [switch]$AutoFix = $false,
    [switch]$Backup = $true,
    [switch]$Exec = $false,
    [switch]$UsePwsh = $false,
    [switch]$Deploy = $true
)

Set-StrictMode -Version Latest

# -----------------------
# Helpers (definidos primeiro)
# -----------------------
function Safe-JoinPath {
    param([string]$Path,[string]$Child)
    return Join-Path -Path $Path -ChildPath $Child
}

function Write-Log {
    param(
        [Parameter(Mandatory=$true)][string]$Message,
        [string]$Level = 'INFO'
    )
    # Garantir diretório/arquivo de log (variáveis globais definidas depois na inicialização)
    if (-not $Global:FULLONE_LogFileDir) {
        $Global:FULLONE_LogFileDir = Safe-JoinPath -Path (Get-Location) -Child "logs_FULLONE"
    }
    if (-not (Test-Path -LiteralPath $Global:FULLONE_LogFileDir -PathType Container)) {
        try { New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null } catch {}
    }
    if (-not $Global:FULLONE_LogFile) {
        $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
        $Global:FULLONE_LogFile = Safe-JoinPath -Path $Global:FULLONE_LogFileDir -Child ("fullone_log_$stamp.txt")
    }
    if (-not (Test-Path -LiteralPath $Global:FULLONE_LogFile -PathType Leaf)) {
        try { New-Item -ItemType File -Path $Global:FULLONE_LogFile -Force | Out-Null } catch {}
    }

    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = "[$ts][$Level] $Message"

    try {
        Add-Content -Path $Global:FULLONE_LogFile -Value $line -Encoding UTF8
    } catch {
        Write-Warning ("Falha escrevendo log em {0}: {1}" -f ${Global:FULLONE_LogFile}, $_.Exception.Message)
    }

    switch ($Level.ToUpper()) {
        'INFO'  { Write-Host $line -ForegroundColor White }
        'OK'    { Write-Host $line -ForegroundColor Green }
        'WARN'  { Write-Host $line -ForegroundColor Yellow }
        'ERROR' { Write-Host $line -ForegroundColor Red }
        default { Write-Host $line -ForegroundColor Gray }
    }
}

# Função de Safe-Fix (definida antes do uso)
function Safe-FixFile {
    param([string]$Path, [switch]$BackupBefore)
    $actions = New-Object System.Collections.ArrayList
    if ($BackupBefore) {
        $backupDir = Safe-JoinPath -Path $RootPath -Child ("BACKUP_FULLONE_$now")
        if (-not (Test-Path -LiteralPath $backupDir -PathType Container)) { New-Item -ItemType Directory -Path $backupDir -Force | Out-Null }
        $dest = Safe-JoinPath -Path $backupDir -Child ((Split-Path $Path -Leaf) + ".bak")
        try { Copy-Item -LiteralPath $Path -Destination $dest -Force } catch { $actions.Add("Falha criando backup: $($_.Exception.Message)") | Out-Null }
        $actions.Add("Backup: $dest") | Out-Null
    }

    try { $raw = Get-Content -Raw -LiteralPath $Path -ErrorAction Stop } catch { return @{ success=$false; message = "Falha ao ler: $($_.Exception.Message)"; actions=$actions } }

    $orig = $raw
    $raw = $raw -replace "[\u201C\u201D]", '"' -replace "[\u2018\u2019]", "'" -replace "…", "..." -replace "\u00A0", " "
    if ($raw.Length -gt 0 -and $raw[0] -eq [char]0xFEFF) { $raw = $raw.Substring(1); $actions.Add("Removed BOM") | Out-Null }

    if ($raw -ne $orig) {
        if ($DryRun) {
            $actions.Add("CHANGES (simulado)") | Out-Null
            return @{ success=$true; changed=$true; message="Simulado: alterações sugeridas"; actions=$actions }
        } else {
            try {
                $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
                [System.IO.File]::WriteAllText($Path, $raw, $utf8NoBom)
                $actions.Add("Saved changes (UTF8 no BOM)") | Out-Null
                return @{ success=$true; changed=$true; message="Alterações aplicadas"; actions=$actions }
            } catch {
                return @{ success=$false; changed=$false; message="Falha ao salvar: $($_.Exception.Message)"; actions=$actions }
            }
        }
    } else {
        return @{ success=$true; changed=$false; message="Nenhuma alteração necessária"; actions=$actions }
    }
}

# -----------------------
# Inicialização principal (após definição de funções)
# -----------------------
try {
    $RootPath = (Resolve-Path -Path $RootPath -ErrorAction Stop).ProviderPath
} catch {
    Write-Host "RootPath inválido: $RootPath" -ForegroundColor Red
    exit 1
}
$now = Get-Date -Format 'yyyyMMdd_HHmmss'

# configurar logdir/arquivo globais com valores definitivos
$Global:FULLONE_LogFileDir = Safe-JoinPath -Path $RootPath -Child "logs_FULLONE"
if (-not (Test-Path -LiteralPath $Global:FULLONE_LogFileDir -PathType Container)) {
    try { New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null } catch { Write-Warning "Não foi possível criar $Global:FULLONE_LogFileDir" }
}
$Global:FULLONE_LogFile = Safe-JoinPath -Path $Global:FULLONE_LogFileDir -Child ("fullone_log_$now.txt")
if (-not (Test-Path -LiteralPath $Global:FULLONE_LogFile -PathType Leaf)) {
    try { New-Item -ItemType File -Path $Global:FULLONE_LogFile -Force | Out-Null } catch { Write-Warning "Não foi possível criar o arquivo de log $Global:FULLONE_LogFile" }
}

Write-Log -Message ("FULLONE iniciado. RootPath = {0}" -f $RootPath) -Level "INFO"
if ($DryRun) { Write-Log -Message "MODO: DRY RUN (simulação). Nenhuma alteração será feita." -Level "INFO" }

# padrões de exclusão
$ignorePatterns = @('\\.git\\','\\node_modules\\','\\dist\\','\\build\\','\\FULLONE_COMPILED\\','\\BACKUP_FULLONE_','\\logs_FULLONE\\')
function Path-IsIgnored { param([string]$FullName) foreach ($p in $ignorePatterns) { if ($FullName -match $p) { return $true } } return $false }

# localizar arquivos
Write-Log -Message "Procurando arquivos .ps1 e .py recursivamente..." -Level "INFO"
try {
    $files = Get-ChildItem -Path $RootPath -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Extension -in '.ps1', '.py' } |
        Where-Object { -not (Path-IsIgnored -FullName $_.FullName) } |
        Where-Object { $_.FullName -ne $PSCommandPath -and $_.FullName -ne $MyInvocation.MyCommand.Definition }
} catch {
    Write-Log -Message ("Erro ao listar arquivos: {0}" -f $_.Exception.Message) -Level "ERROR"
    $files = @()
}
$totalCount = $files.Count
Write-Log -Message ("Total encontrado: {0} arquivos (.ps1/.py)." -f $totalCount) -Level "INFO"

# relatório inicial
$reportFile = Safe-JoinPath -Path $RootPath -Child ("relatorio_FULLONE_$now.txt")
$summary = New-Object System.Collections.Generic.List[string]
$summary.Add(("FULLONE Report - {0}" -f $now))
$summary.Add(("RootPath: {0}" -f $RootPath))
$summary.Add(("Total scripts found: {0}" -f $totalCount))
$summary.Add("")

# duplicates
Write-Log -Message "Calculando hashes (SHA256) para identificar duplicados..." -Level "INFO"
$hashMap = @{}
$byName = @{}
foreach ($f in $files) {
    try {
        $h = Get-FileHash -Path $f.FullName -Algorithm SHA256 -ErrorAction Stop
        $hash = $h.Hash
    } catch {
        Write-Log -Message ("Falha ao calcular hash de {0}: {1}" -f $f.FullName, $_.Exception.Message) -Level "WARN"
        $hash = "ERROR_$([guid]::NewGuid().ToString())"
    }
    if (-not $hashMap.ContainsKey($hash)) { $hashMap[$hash] = New-Object System.Collections.ArrayList }
    $hashMap[$hash].Add($f) | Out-Null

    if (-not $byName.ContainsKey($f.Name)) { $byName[$f.Name] = New-Object System.Collections.ArrayList }
    $byName[$f.Name].Add($f) | Out-Null
}

$dupByContent = $hashMap.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }
if ($dupByContent.Count -gt 0) {
    Write-Log -Message ("Duplicados por conteúdo encontrados: {0} grupos." -f $dupByContent.Count) -Level "WARN"
    $summary.Add(("Duplicados por conteúdo (grupos): {0}" -f $dupByContent.Count))
    foreach ($g in $dupByContent) {
        $summary.Add(("GrupoHash: {0}" -f $g.Key))
        foreach ($item in $g.Value) { $summary.Add(("    {0} (modified: {1})" -f $item.FullName, $item.LastWriteTime)) }
    }
} else {
    $summary.Add("Nenhum duplicado de conteúdo detectado.")
    Write-Log -Message "Nenhum duplicado por conteúdo detectado." -Level "OK"
}

$dupByName = $byName.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }
if ($dupByName.Count -gt 0) {
    Write-Log -Message ("Mesmo nome em múltiplas localizações: {0} nomes." -f $dupByName.Count) -Level "WARN"
    $summary.Add("")
    $summary.Add(("Arquivos com mesmo nome em múltiplas pastas: {0}" -f $dupByName.Count))
    foreach ($g in $dupByName) {
        $summary.Add(("Nome: {0}" -f $g.Key))
        foreach ($item in $g.Value) {
            $summary.Add(("    {0} (LastWrite: {1}, Size: {2})" -f $item.FullName, $item.LastWriteTime, $item.Length))
        }
        $latest = $g.Value | Sort-Object LastWriteTime -Descending | Select-Object -First 1
        $summary.Add(("    -> Sugerido manter (mais recente): {0}" -f $latest.FullName))
    }
} else {
    $summary.Add("Nenhum arquivo com mesmo nome em múltiplos locais.")
}

# salvar relatório inicial (tratando erros com Write-Log - named params)
try {
    $summary | Out-File -FilePath $reportFile -Encoding UTF8 -Force
} catch {
    Write-Log -Message ("Falha salvando relatório inicial: {0}" -f $_.Exception.Message) -Level "WARN"
}

# SafeFix / AutoFix
$fixSummary = New-Object System.Collections.ArrayList
if ($AutoFix) {
    Write-Log -Message "AutoFix solicitado. Preparando aplicação de correções seguras." -Level "INFO"
    if ($DryRun) { Write-Log -Message "Nota: Em DryRun; AutoFix apenas simulado." -Level "INFO" }
    $confirm = $true
    if (-not $DryRun) {
        try {
            $choice = Read-Host "Você quer realmente aplicar AutoFix em todos os arquivos encontrados? (S/N)"
            if ($choice.ToUpper() -ne 'S') { $confirm = $false; Write-Log -Message "AutoFix CANCELADO pelo usuário." -Level "WARN" }
        } catch { $confirm = $true }
    }
    if ($confirm) {
        foreach ($f in $files) {
            Write-Log -Message ("Analisando para fix: {0}" -f $f.FullName) -Level "INFO"
            $res = Safe-FixFile -Path $f.FullName -BackupBefore:$Backup
            if ($res.success) {
                $fixSummary.Add(("{0} => {1} - {2}" -f $f.FullName, ($res.changed -eq $true ? "CHANGED":"UNCHANGED"), $res.message)) | Out-Null
                foreach ($a in $res.actions) { Write-Log -Message $a -Level "INFO" }
            } else {
                Write-Log -Message ("Erro no Safe-FixFile: {0}" -f $res.message) -Level "ERROR"
            }
        }
        Write-Log -Message "AutoFix finalizado (ou simulado)." -Level "INFO"
    }
}

# Compilado
Write-Log -Message "Gerando arquivo compilado FULLONE_COMPILED..." -Level "INFO"
$compiledFolder = Safe-JoinPath -Path $RootPath -Child 'FULLONE_COMPILED'
if (-not (Test-Path -LiteralPath $compiledFolder -PathType Container)) { New-Item -ItemType Directory -Path $compiledFolder -Force | Out-Null }
$compiledPath = Safe-JoinPath -Path $compiledFolder -Child ("FULLONE_COMPILED_$now.ps1")
$simulatedCompiledPath = $null

$header = @()
$header += ("# FULLONE_COMPILED - gerado em {0}" -f $now)
$header += ("# Root: {0}" -f $RootPath)
$header += "# Arquivos incluídos:"
foreach ($f in $files) { $header += ("# - {0} (LastWrite: {1})" -f $f.FullName, $f.LastWriteTime) }
$header += ""

$compiledContent = $header -join "`r`n" + "`r`n"
foreach ($f in $files) {
    $compiledContent += "`r`n"
    $compiledContent += "##############################################################################`r`n"
    $compiledContent += ("# INICIO: {0}`r`n" -f $f.FullName)
    $compiledContent += "##############################################################################`r`n"
    try {
        $txt = Get-Content -Raw -LiteralPath $f.FullName -ErrorAction Stop
        if ($f.Extension.ToLower() -eq '.py') {
            $compiledContent += ("<# PY: origem: {0} #>`r`n" -f $f.FullName)
            $compiledContent += $txt + "`r`n"
            $compiledContent += "<# FIM PY #>`r`n"
        } else {
            $compiledContent += $txt + "`r`n"
        }
    } catch {
        Write-Log -Message ("Falha lendo {0} para inclusão compilada: {1}" -f $f.FullName, $_.Exception.Message) -Level "WARN"
        $compiledContent += ("# Falha ao incluir {0}: {1}`r`n" -f $f.FullName, $_.Exception.Message)
    }
    $compiledContent += "`r`n"
    $compiledContent += "##############################################################################`r`n"
    $compiledContent += ("# FIM: {0}`r`n" -f $f.FullName)
    $compiledContent += "##############################################################################`r`n"
}

if ($DryRun) {
    $simulatedCompiledPath = $compiledPath + ".simulado.txt"
    try {
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($simulatedCompiledPath, $compiledContent, $utf8NoBom)
        Write-Log -Message ("Em DryRun: compilado simulado salvo em: {0}" -f $simulatedCompiledPath) -Level "OK"
    } catch {
        Write-Log -Message ("Falha salvando compilado simulado: {0}" -f $_.Exception.Message) -Level "WARN"
    }
} else {
    try {
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($compiledPath, $compiledContent, $utf8NoBom)
        Write-Log -Message ("Arquivo compilado salvo em: {0}" -f $compiledPath) -Level "OK"
    } catch {
        Write-Log -Message ("Falha ao salvar compilado: {0}" -f $_.Exception.Message) -Level "ERROR"
    }
}

# Execução isolada (opcional)
if ($Exec) {
    Write-Log -Message "Execução isolada de cada script solicitada. Será executado em processos separados." -Level "INFO"
    if ($DryRun) { Write-Log -Message "OBS: Execução em DryRun (simulação) - nada será executado)." -Level "INFO" }
    foreach ($f in $files) {
        Write-Log -Message ("Preparando execução: {0}" -f $f.FullName) -Level "INFO"
        if ($DryRun) { Write-Log -Message ("Simulado: executar {0}" -f $f.FullName) -Level "INFO"; continue }
        if ($f.Extension.ToLower() -eq '.py') {
            try {
                $proc = Start-Process -FilePath 'python' -ArgumentList @($f.FullName) -Wait -NoNewWindow -PassThru -ErrorAction Stop
                Write-Log -Message ("Processo finalizado: ExitCode {0}" -f $proc.ExitCode) -Level "OK"
            } catch { Write-Log -Message ("Falha ao executar python {0}: {1}" -f $f.FullName, $_.Exception.Message) -Level "ERROR" }
        } else {
            $psExe = if ($UsePwsh) { 'pwsh' } else { 'powershell' }
            $arg = "-NoProfile -ExecutionPolicy Bypass -File `"$($f.FullName)`""
            try {
                $proc = Start-Process -FilePath $psExe -ArgumentList $arg -Wait -NoNewWindow -PassThru -ErrorAction Stop
                Write-Log -Message ("Processo finalizado: ExitCode {0}" -f $proc.ExitCode) -Level "OK"
            } catch { Write-Log -Message ("Falha ao executar {0}: {1}" -f $f.FullName, $_.Exception.Message) -Level "ERROR" }
        }
    }
}

# Deploy (opcional)
if ($Deploy) {
    Write-Log -Message "Deploy solicitado: copiando compilado para pastas de integração." -Level "INFO"
    $targets = @(
        Safe-JoinPath -Path $RootPath -Child 'DEPLOY_FULLONE',
        Safe-JoinPath -Path $RootPath -Child 'CONAV MASTER FULL\FULLONEMASTER',
        Safe-JoinPath -Path $RootPath -Child 'MAGIC QUANTIC TRADER'
    )
    foreach ($t in $targets) {
        if (-not (Test-Path -LiteralPath $t -PathType Container)) {
            try { New-Item -ItemType Directory -Path $t -Force | Out-Null } catch { Write-Log -Message ("Falha criando target {0}: {1}" -f $t, $_.Exception.Message) -Level "WARN" }
        }
        if ($DryRun) { Write-Log -Message ("Simulado: copiar {0} -> {1}" -f $compiledPath, $t) -Level "INFO" } else {
            try { Copy-Item -LiteralPath $compiledPath -Destination $t -Force; Write-Log -Message ("Copiado compilado -> {0}" -f $t) -Level "OK" } catch { Write-Log -Message ("Falha no deploy {0}: {1}" -f $t, $_.Exception.Message) -Level "ERROR" }
        }
    }
}

# Relatório final
$report = New-Object System.Collections.Generic.List[string]
$report.AddRange($summary)
$report.Add("")
$report.Add("Detalhes:")
$report.Add(("Total arquivos: {0}" -f $totalCount))
$report.Add(("Duplicados por conteúdo (grupos): {0}" -f $dupByContent.Count))
$report.Add(("Mesmo nome em múltiplas pastas: {0}" -f $dupByName.Count))
$report.Add("")
if ($AutoFix) {
    $report.Add("AutoFix summary:")
    $fixSummary | ForEach-Object { $report.Add($_) }
}
$report.Add("")
$report.Add("Compiled file: " + (if ($DryRun) { $simulatedCompiledPath } else { $compiledPath }))
$report.Add("")
$report.Add("LOG: " + $Global:FULLONE_LogFile)
$report.Add("")
$report.Add("Fim do relatório.")

try { $report | Out-File -FilePath $reportFile -Encoding UTF8 -Force } catch { Write-Log -Message ("Falha salvando relatório final: {0}" -f $_.Exception.Message) -Level "ERROR" }

Write-Log -Message "Execução finalizada." -Level "OK"

# Abrir tutorial PDF automaticamente (procura por dois nomes comuns)
try {
    $scriptDir = $PSScriptRoot
    if (-not $scriptDir) { $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition }
    $candidate1 = Safe-JoinPath -Path $scriptDir -Child "Tutorial_FULLONE_v5.pdf"
    $candidate2 = Safe-JoinPath -Path $scriptDir -Child "Tutorial.pdf"
    if (Test-Path -LiteralPath $candidate1 -PathType Leaf) {
        Write-Log -Message ("Abrindo tutorial: {0}" -f $candidate1) -Level "INFO"
        Start-Process -FilePath $candidate1 -ErrorAction SilentlyContinue
    } elseif (Test-Path -LiteralPath $candidate2 -PathType Leaf) {
        Write-Log -Message ("Abrindo tutorial: {0}" -f $candidate2) -Level "INFO"
        Start-Process -FilePath $candidate2 -ErrorAction SilentlyContinue
    } else {
        Write-Log -Message ("Tutorial PDF não encontrado no diretório do script: {0}" -f $scriptDir) -Level "WARN"
    }
} catch {
    Write-Log -Message ("Erro tentando abrir tutorial PDF: {0}" -f $_.Exception.Message) -Level "WARN"
}

# fim do script

   pwsh -NoProfile -ExecutionPolicy Bypass -File .\FULLONE.ps1 -DryRun:$true
   
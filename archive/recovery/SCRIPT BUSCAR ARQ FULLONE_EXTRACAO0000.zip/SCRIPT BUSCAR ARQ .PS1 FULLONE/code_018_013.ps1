<#
================================================================================
 SCRIPT: FULLONE-correção1.ps1
 OBJETIVO:
   - Buscar todos os .ps1 e .py dentro da pasta raiz especificada
   - Contar arquivos
   - Detectar duplicados (conteúdo e nome)
   - Corrigir caracteres problemáticos (SafeFix, opcional)
   - Compilar todos em 1 único FULLONE_COMPILED.ps1
   - Executar cada script em processo separado (opcional)
   - Relatório e log detalhado
   - Deploy automático para pastas de integração
   - Script independente e seguro

 AUTOR: Assistente Automação
================================================================================
#>

param(
    [string]$RootPath = 'C:\CONAV TRADER\CONAV_TRADER',
    [switch]$DryRun = $true,
    [switch]$AutoFix = $false,
    [switch]$Backup = $true,
    [switch]$Exec = $false,
    [switch]$UsePwsh = $false,
    [switch]$Deploy = $true
)

# ==============================
# Função de log
# ==============================
function Write-Log {
    param([string]$Message,[string]$Level = 'INFO')
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = "[$ts][$Level] $Message"
    try {
        Add-Content -Path $Global:FULLONE_LogFile -Value $line -Encoding UTF8
    } catch {
        Write-Warning "Falha escrevendo log em ${Global:FULLONE_LogFile}: $($_.Exception.Message)"
    }
    Write-Host $line
}

# ==============================
# Inicialização
# ==============================
$RootPath = (Resolve-Path -Path $RootPath).ProviderPath
$now = Get-Date -Format 'yyyyMMdd_HHmmss'

# Diretório de logs
$Global:FULLONE_LogFileDir = Join-Path $RootPath 'logs_FULLONE'
if (!(Test-Path $Global:FULLONE_LogFileDir)) {
    New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null
}
# Arquivo de log correto
$Global:FULLONE_LogFile = Join-Path $Global:FULLONE_LogFileDir ("fullone_log_$now.txt")

Write-Log "FULLONE iniciado. RootPath = $RootPath"
if ($DryRun) { Write-Log "MODO: DRY RUN (simulação). Nenhuma alteração será feita." }

# ==============================
# Localizar arquivos
# ==============================
Write-Log "Procurando arquivos .ps1 e .py recursivamente..."
$files = Get-ChildItem -Path $RootPath -Recurse -File -ErrorAction SilentlyContinue `
    | Where-Object { $_.Extension -in '.ps1','.py' }
$totalCount = $files.Count
Write-Log "Total encontrado: $totalCount arquivos (.ps1/.py)."

# ==============================
# Relatório inicial
# ==============================
$reportFile = Join-Path $RootPath ("relatorio_FULLONE_$now.txt")
$summary = @()
$summary += "Relatório FULLONE - $now"
$summary += "RootPath: $RootPath"
$summary += "Total arquivos: $totalCount"
$summary += ""

# ==============================
# Duplicados (conteúdo e nome)
# ==============================
Write-Log "Verificando duplicados por conteúdo (hash)..."
$hashMap = @{}
$byName = @{}
foreach ($f in $files) {
    try {
        $h = Get-FileHash -Path $f.FullName -Algorithm SHA256
        if (-not $hashMap.ContainsKey($h.Hash)) { $hashMap[$h.Hash] = @() }
        $hashMap[$h.Hash] += $f
    } catch { Write-Log "Falha hash $($f.FullName): $($_.Exception.Message)" "WARN" }
    if (-not $byName.ContainsKey($f.Name)) { $byName[$f.Name] = @() }
    $byName[$f.Name] += $f
}
$dupByContent = $hashMap.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }
$dupByName = $byName.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }

if ($dupByContent.Count -gt 0) {
    $summary += "Duplicados por conteúdo: $($dupByContent.Count) grupos"
    foreach ($g in $dupByContent) {
        $summary += "Hash: $($g.Key)"
        foreach ($f in $g.Value) { $summary += "   $($f.FullName)" }
    }
} else { $summary += "Nenhum duplicado de conteúdo." }

Write-Log "Verificando arquivos com mesmo nome..."
if ($dupByName.Count -gt 0) {
    $summary += ""
    $summary += "Duplicados por nome: $($dupByName.Count) grupos"
    foreach ($g in $dupByName) {
        $summary += "Nome: $($g.Key)"
        foreach ($f in $g.Value) { $summary += "   $($f.FullName)" }
    }
} else { $summary += "Nenhum duplicado por nome." }

# ==============================
# Função SafeFix
# ==============================
function Safe-FixFile {
    param([string]$Path,[switch]$BackupBefore)
    $actions=@()
    if ($BackupBefore) {
        $backupDir = Join-Path $RootPath ("BACKUP_FULLONE_$now")
        if (!(Test-Path $backupDir)) { New-Item -ItemType Directory -Path $backupDir -Force | Out-Null }
        $dest = Join-Path $backupDir ((Split-Path $Path -Leaf)+".bak")
        Copy-Item $Path $dest -Force
        $actions+="Backup: $dest"
    }
    try { $raw=Get-Content -Raw -LiteralPath $Path } catch { return @{success=$false;msg="Falha leitura";actions=$actions} }
    $orig=$raw
    $raw=$raw -replace "[\u201C\u201D]",'"' -replace "[\u2018\u2019]","'" -replace "…","..." -replace "\u00A0"," "
    if ($raw.StartsWith([char]0xFEFF)) { $raw=$raw.Substring(1); $actions+="BOM removido" }
    if ($raw -ne $orig) {
        if ($DryRun) { return @{success=$true;changed=$true;msg="Alterações simuladas";actions=$actions} }
        else { $raw|Out-File -LiteralPath $Path -Encoding UTF8 -Force; return @{success=$true;changed=$true;msg="Alterações aplicadas";actions=$actions} }
    } else { return @{success=$true;changed=$false;msg="Nenhuma alteração";actions=$actions} }
}

# ==============================
# SafeFix (opcional)
# ==============================
$fixSummary=@()
if ($AutoFix) {
    Write-Log "Rodando SafeFix..."
    foreach ($f in $files) {
        $res=Safe-FixFile -Path $f.FullName -BackupBefore:$Backup
        $fixSummary+=("$($f.FullName) => $($res.msg)")
        foreach ($a in $res.actions) { Write-Log "   $a" }
    }
}

# ==============================
# Compilação
# ==============================
Write-Log "Gerando compilado FULLONE_COMPILED..."
$compiledDir = Join-Path $RootPath "FULLONE_COMPILED"
if (!(Test-Path $compiledDir)) {
    New-Item -ItemType Directory -Path $compiledDir -Force | Out-Null
}
$compiledPath = Join-Path $compiledDir ("FULLONE_COMPILED_$now.ps1")

$compiled=@()
$compiled+="# FULLONE_COMPILED - $now"
$compiled+="# Root: $RootPath"
foreach ($f in $files) {
    $compiled+="##############################################################################"
    $compiled+="# INICIO: $($f.FullName)"
    try {
        $txt=Get-Content -Raw -LiteralPath $f.FullName
        if ($f.Extension -eq ".py") { $compiled+="<# PYTHON ORIGEM #>";$compiled+=$txt;$compiled+="<# FIM PYTHON #>" }
        else { $compiled+=$txt }
    } catch { $compiled+="# Falha incluir $($f.FullName)" }
    $compiled+="# FIM: $($f.FullName)"
}
if ($DryRun) {
    $compiledSim=$compiledPath+".simulado.txt"
    $compiled|Out-File -FilePath $compiledSim -Encoding UTF8
    Write-Log "Compilado simulado salvo em: $compiledSim"
} else {
    $compiled|Out-File -FilePath $compiledPath -Encoding UTF8
    Write-Log "Compilado salvo em: $compiledPath"
}

# ==============================
# Execução isolada (opcional)
# ==============================
if ($Exec) {
    Write-Log "Executando scripts em processos separados..."
    foreach ($f in $files) {
        if ($DryRun) { Write-Log "Simulado: $($f.FullName)"; continue }
        if ($f.Extension -eq ".py") {
            try { Start-Process -FilePath "python" -ArgumentList "`"$($f.FullName)`"" -Wait -NoNewWindow -PassThru | Out-Null; Write-Log "OK: $($f.Name)" }
            catch { Write-Log "Erro Python: $($f.FullName)" "ERROR" }
        } else {
            $exe=if ($UsePwsh) {'pwsh'} else {'powershell'}
            try { Start-Process -FilePath $exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$($f.FullName)`"" -Wait -NoNewWindow -PassThru|Out-Null; Write-Log "OK: $($f.Name)" }
            catch { Write-Log "Erro PowerShell: $($f.FullName)" "ERROR" }
        }
    }
}

# ==============================
# Deploy automático (opcional)
# ==============================
if ($Deploy) {
    Write-Log "Iniciando deploy automático..."
    $deployDirs = @(
        (Join-Path $RootPath "DEPLOY_FULLONE"),
        (Join-Path $RootPath "CONAV MASTER FULL\FULLONEMASTER"),
        (Join-Path $RootPath "MAGIC QUANTIC TRADER")
    )
    foreach ($d in $deployDirs) {
        if (!(Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
        if (-not $DryRun) {
            Copy-Item -Path $compiledPath -Destination $d -Force
            Write-Log "Deploy realizado em: $d"
        } else {
            Write-Log "Simulado: deploy em $d"
        }
    }
}

# ==============================
# Relatório final
# ==============================
if ($AutoFix) { $summary+="";$summary+="Resumo SafeFix:";$summary+=$fixSummary }
$summary+="";$summary+="Fim do relatório."
$summary|Out-File -FilePath $reportFile -Encoding UTF8
Write-Log "Relatório salvo em: $reportFile"
Write-Log "Execução finalizada."

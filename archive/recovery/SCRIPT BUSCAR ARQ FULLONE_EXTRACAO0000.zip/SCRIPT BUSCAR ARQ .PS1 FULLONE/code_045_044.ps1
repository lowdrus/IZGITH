# exemplo da parte corrigida no bloco de Deploy:
if ($DryRun) { 
    Write-Log -Message ("Simulado: copiar {0} -> {1}" -f $compiledPath, $t) -Level "INFO" 
} else {
    try { 
        Copy-Item -LiteralPath $compiledPath -Destination $t -Force
        Write-Log -Message ("Copiado compilado -> {0}" -f $t) -Level "OK" 
    } catch { 
        Write-Log -Message ("Falha no deploy {0}: {1}" -f $t, $_.Exception.Message) -Level "ERROR" 
    }
}

<#
.SYNOPSIS
    FULLONEv00003.ps1 - rotina unificada para descobrir, analisar, corrigir (opcional), compilar, executar e versionar scripts (.ps1 .py).

.DESCRIPTION
    - Busca recursiva por .ps1 e .py em RootPath (padrão: C:\CONAV TRADER\CONAV_TRADER)
    - Relatórios: contagem, duplicados (por hash), arquivos com mesmo nome (comparação)
    - SafeFix (correções seguras) com Backup opcional
    - Geração de FULLONE_COMPILED_<timestamp>.ps1 (ou .simulado.txt em DryRun)
    - Execução isolada por processo (opcional)
    - Deploy/versionamento do FULLONE para pastas de integração (opcional)
    - DryRun por padrão (não modifica nada)
    - Logs em <RootPath>\logs_FULLONE
    - Relatórios em <RootPath>
#>

param(
    [string]$RootPath = 'C:\CONAV TRADER\CONAV_TRADER',
    [switch]$DryRun = $true,
    [switch]$AutoFix = $false,
    [switch]$Backup = $true,
    [switch]$Exec = $false,
    [switch]$UsePwsh = $false,
    [switch]$MakeCompiledOnly = $false,
    [switch]$Deploy = $false
)

Set-StrictMode -Version Latest

# -------------------------
# Helpers / Inicialização
# -------------------------
function Safe-JoinPath {
    param([string]$Path, [string]$Child)
    return Join-Path -Path $Path -ChildPath $Child
}

# resolve RootPath absolute
try { $RootPath = (Resolve-Path -Path $RootPath -ErrorAction Stop).ProviderPath } catch { Write-Error "RootPath inválido: $RootPath"; exit 1 }

$now = Get-Date -Format 'yyyyMMdd_HHmmss'

# log dir & file (cria diretório ANTES de montar o nome do arquivo)
$LogDir = Safe-JoinPath -Path $RootPath -Child "logs_FULLONE"
if (-not (Test-Path -LiteralPath $LogDir -PathType Container)) {
    try { New-Item -ItemType Directory -Path $LogDir -Force | Out-Null } catch { Write-Warning "Não foi possível criar pasta de logs: $LogDir" }
}
$LogFile = Safe-JoinPath -Path $LogDir -Child ("fullone_log_$now.txt")

# garante que o arquivo de log exista (assim Add-Content não tenta escrever num diretório)
if (-not (Test-Path -LiteralPath $LogFile -PathType Leaf)) {
    try { New-Item -ItemType File -Path $LogFile -Force | Out-Null } catch { Write-Warning "Não foi possível criar o arquivo de log: $LogFile" }
}

function Write-Log {
    param(
        [string]$Message,
        [string]$Level = 'INFO'
    )
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = "[$ts][$Level] $Message"
    # proteção: se por algum motivo $LogFile for diretório, redirecionar para console
    if (Test-Path -LiteralPath $LogFile -PathType Container) {
        Write-Host "[WARN] Log path é diretório! $LogFile" -ForegroundColor Yellow
        Write-Host $line
    } else {
        try {
            Add-Content -Path $LogFile -Value $line -Encoding UTF8
        } catch {
            Write-Warning "Falha escrevendo log em $LogFile: $($_.Exception.Message)"
            Write-Host $line
        }
    }
    Write-Host $line
}

Write-Log "FULLONE iniciado. RootPath = $RootPath"
if ($DryRun) { Write-Log "MODO: DRY RUN (simulação). Nenhuma alteração será feita." }

# -------------------------
# Padrões / exclusões
# -------------------------
$ignorePatterns = @(
    '\\.git\\',
    '\\node_modules\\',
    '\\dist\\',
    '\\build\\',
    '\\FULLONE_COMPILED\\',      # não varrer a pasta de compilados
    '\\BACKUP_FULLONE_',         # não varrer backups criados pelo próprio script
    '\\logs_FULLONE\\'           # evitar reprocessar logs
)

function Path-IsIgnored {
    param([string]$FullName)
    foreach ($p in $ignorePatterns) {
        if ($FullName -match $p) { return $true }
    }
    return $false
}

# -------------------------
# Localizar arquivos .ps1 e .py
# -------------------------
Write-Log "Procurando arquivos .ps1 e .py recursivamente..."
try {
    $files = Get-ChildItem -Path $RootPath -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Extension -in '.ps1', '.py' } |
        Where-Object { -not (Path-IsIgnored -FullName $_.FullName) } |
        Where-Object { $_.FullName -ne $PSCommandPath -and $_.FullName -ne $MyInvocation.MyCommand.Definition }
} catch {
    Write-Log "Erro ao listar arquivos: $($_.Exception.Message)" "ERROR"
    $files = @()
}

$totalCount = $files.Count
Write-Log "Total encontrado: $totalCount arquivos (.ps1/.py)."

# relatório inicial
$reportFile = Safe-JoinPath -Path $RootPath -Child ("relatorio_FULLONE_$now.txt")
$summary = New-Object System.Collections.Generic.List[string]
$summary.Add("FULLONE Report - $now")
$summary.Add("RootPath: $RootPath")
$summary.Add("Total scripts found: $totalCount")
$summary.Add("")

# -------------------------
# Hashes e duplicados
# -------------------------
Write-Log "Calculando hashes (SHA256) para identificar duplicados..."
$hashMap = @{}
$byName = @{}
foreach ($f in $files) {
    try {
        $h = Get-FileHash -Path $f.FullName -Algorithm SHA256 -ErrorAction Stop
        $hash = $h.Hash
    } catch {
        Write-Log "Falha ao calcular hash de $($f.FullName): $($_.Exception.Message)" "WARN"
        $hash = "ERROR_$([guid]::NewGuid().ToString())"
    }
    if (-not $hashMap.ContainsKey($hash)) { $hashMap[$hash] = New-Object System.Collections.ArrayList }
    $hashMap[$hash].Add($f) | Out-Null

    if (-not $byName.ContainsKey($f.Name)) { $byName[$f.Name] = New-Object System.Collections.ArrayList }
    $byName[$f.Name].Add($f) | Out-Null
}

$dupByContent = $hashMap.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }
if ($dupByContent.Count -gt 0) {
    Write-Log "Duplicados por conteúdo encontrados: $($dupByContent.Count) grupos."
    $summary.Add("Duplicados por conteúdo (grupos): $($dupByContent.Count)")
    foreach ($g in $dupByContent) {
        $summary.Add("GrupoHash: $($g.Key)")
        foreach ($item in $g.Value) { $summary.Add("    $($item.FullName) (modified: $($item.LastWriteTime))") }
    }
} else {
    $summary.Add("Nenhum duplicado de conteúdo detectado.")
    Write-Log "Nenhum duplicado por conteúdo detectado."
}

$dupByName = $byName.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }
if ($dupByName.Count -gt 0) {
    Write-Log "Mesmo nome em múltiplas localizações: $($dupByName.Count) nomes."
    $summary.Add("")
    $summary.Add("Arquivos com mesmo nome em múltiplas pastas: $($dupByName.Count)")
    foreach ($g in $dupByName) {
        $summary.Add("Nome: $($g.Key)")
        foreach ($item in $g.Value) {
            $summary.Add("    $($item.FullName) (LastWrite: $($item.LastWriteTime), Size: $($item.Length))")
        }
        $latest = $g.Value | Sort-Object LastWriteTime -Descending | Select-Object -First 1
        $summary.Add("    -> Sugerido manter (mais recente): $($latest.FullName)")
    }
} else {
    $summary.Add("Nenhum arquivo com mesmo nome em múltiplos locais.")
}

# salva resumo inicial temporariamente (vai ser sobrescrito no final também)
try { $summary | Out-File -FilePath $reportFile -Encoding UTF8 -Force } catch { Write-Log "Falha salvando relatório inicial: $($_.Exception.Message)" "WARN" }

# -------------------------
# Safe-Fix function
# -------------------------
function Safe-FixFile {
    param(
        [string]$Path,
        [switch]$BackupBefore
    )
    $actions = New-Object System.Collections.ArrayList

    if ($BackupBefore) {
        $backupDir = Safe-JoinPath -Path $RootPath -Child ("BACKUP_FULLONE_$now")
        if (-not (Test-Path -LiteralPath $backupDir -PathType Container)) { New-Item -ItemType Directory -Path $backupDir -Force | Out-Null }
        $dest = Safe-JoinPath -Path $backupDir -Child ((Split-Path $Path -Leaf) + ".bak")
        try { Copy-Item -LiteralPath $Path -Destination $dest -Force } catch { $actions.Add("Falha criando backup: $($_.Exception.Message)") | Out-Null }
        $actions.Add("Backup: $dest") | Out-Null
    }

    try {
        $raw = Get-Content -Raw -LiteralPath $Path -ErrorAction Stop
    } catch {
        return @{ success = $false; message = "Falha ao ler: $($_.Exception.Message)"; actions=$actions }
    }

    $orig = $raw
    # substituições seguras
    $raw = $raw -replace "[\u201C\u201D]", '"'    # curly double -> "
    $raw = $raw -replace "[\u2018\u2019]", "'"    # curly single -> '
    $raw = $raw -replace "…", "..."
    $raw = $raw -replace "\u00A0", " "           # NBSP -> space
    if ($raw.Length -gt 0 -and $raw[0] -eq [char]0xFEFF) { $raw = $raw.Substring(1); $actions.Add("Removed BOM") | Out-Null }

    if ($raw -ne $orig) {
        if ($DryRun) {
            $actions.Add("CHANGES (simulado)") | Out-Null
            return @{ success = $true; changed = $true; message = "Simulado: alterações sugeridas"; actions=$actions }
        } else {
            try {
                # salvar sem BOM explicitamente
                $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
                [System.IO.File]::WriteAllText($Path, $raw, $utf8NoBom)
                $actions.Add("Saved changes (UTF8 no BOM)") | Out-Null
                return @{ success = $true; changed = $true; message = "Alterações aplicadas"; actions=$actions }
            } catch {
                return @{ success = $false; changed = $false; message = "Falha ao salvar: $($_.Exception.Message)"; actions=$actions }
            }
        }
    } else {
        return @{ success = $true; changed = $false; message = "Nenhuma alteração necessária"; actions=$actions }
    }
}

# -------------------------
# AutoFix (opcional)
# -------------------------
$fixSummary = New-Object System.Collections.ArrayList
if ($AutoFix) {
    Write-Log "AutoFix solicitado. Preparando aplicação de correções seguras."
    if ($DryRun) { Write-Log "Nota: Em DryRun; AutoFix apenas simulado." }
    $confirm = $true
    if (-not $DryRun) {
        try {
            $choice = Read-Host "Você quer realmente aplicar AutoFix em todos os arquivos encontrados? (S/N)"
            if ($choice.ToUpper() -ne 'S') { $confirm = $false; Write-Log "AutoFix CANCELADO pelo usuário." }
        } catch { $confirm = $true }
    }
    if ($confirm) {
        foreach ($f in $files) {
            Write-Log "Analisando para fix: $($f.FullName)"
            $res = Safe-FixFile -Path $f.FullName -BackupBefore:$Backup
            if ($res.success) {
                $fixSummary.Add(("{0} => {1} - {2}" -f $f.FullName, ($res.changed -eq $true ? "CHANGED":"UNCHANGED"), $res.message)) | Out-Null
                foreach ($a in $res.actions) { Write-Log "    $a" }
            } else {
                Write-Log "Erro no Safe-FixFile: $($res.message)" "ERROR"
            }
        }
        Write-Log "AutoFix finalizado (ou simulado)."
    }
}

# -------------------------
# Gerar arquivo compilado
# -------------------------
Write-Log "Gerando arquivo compilado FULLONE_COMPILED..."
$compiledFolder = Safe-JoinPath -Path $RootPath -Child 'FULLONE_COMPILED'
if (-not (Test-Path -LiteralPath $compiledFolder -PathType Container)) { New-Item -ItemType Directory -Path $compiledFolder -Force | Out-Null }
$compiledPath = Safe-JoinPath -Path $compiledFolder -Child ("FULLONE_COMPILED_$now.ps1")

$header = @()
$header += "# FULLONE_COMPILED - gerado em $now"
$header += "# Root: $RootPath"
$header += "# Arquivos incluídos:"
foreach ($f in $files) { $header += ("# - {0} (LastWrite: {1})" -f $f.FullName, $f.LastWriteTime) }
$header += ""

$compiledContent = $header -join "`r`n" + "`r`n"
foreach ($f in $files) {
    $compiledContent += "`r`n"
    $compiledContent += "##############################################################################`r`n"
    $compiledContent += "# INICIO: $($f.FullName)`r`n"
    $compiledContent += "##############################################################################`r`n"
    try {
        $txt = Get-Content -Raw -LiteralPath $f.FullName -ErrorAction Stop
        if ($f.Extension.ToLower() -eq '.py') {
            $compiledContent += "<# PY: origem: $($f.FullName) #>`r`n"
            $compiledContent += $txt + "`r`n"
            $compiledContent += "<# FIM PY #>`r`n"
        } else {
            $compiledContent += $txt + "`r`n"
        }
    } catch {
        Write-Log "Falha lendo $($f.FullName) para inclusão compilada: $($_.Exception.Message)" "WARN"
        $compiledContent += "# Falha ao incluir $($f.FullName): $($_.Exception.Message)`r`n"
    }
    $compiledContent += "`r`n"
    $compiledContent += "##############################################################################`r`n"
    $compiledContent += "# FIM: $($f.FullName)`r`n"
    $compiledContent += "##############################################################################`r`n"
}

if ($DryRun) {
    $simulatedCompiledPath = $compiledPath + ".simulado.txt"
    try {
        # salvar sem BOM
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($simulatedCompiledPath, $compiledContent, $utf8NoBom)
        Write-Log "Em DryRun: compilado simulado salvo em: $simulatedCompiledPath"
    } catch { Write-Log "Falha salvando compilado simulado: $($_.Exception.Message)" "WARN" }
} else {
    try {
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($compiledPath, $compiledContent, $utf8NoBom)
        Write-Log "Arquivo compilado salvo em: $compiledPath"
    } catch { Write-Log "Falha ao salvar compilado: $($_.Exception.Message)" "ERROR" }
}

if ($MakeCompiledOnly) {
    Write-Log "MakeCompiledOnly solicitado. Finalizando sem execução."
    $summary.Add("Compiled file: " + (if ($DryRun) { $simulatedCompiledPath } else { $compiledPath }))
    $summary.Add("LOG: $LogFile")
    $summary.Add("Fim do relatório.")
    $summary | Out-File -FilePath $reportFile -Encoding UTF8 -Force
    Write-Log "Relatório salvo em: $reportFile"
    exit 0
}

# -------------------------
# Execução isolada (opcional)
# -------------------------
if ($Exec) {
    Write-Log "Execução isolada de cada script solicitada. Será executado em processos separados."
    if ($DryRun) { Write-Log "OBS: Execução em DryRun (simulação) - nada será executado)." }
    foreach ($f in $files) {
        Write-Log "Preparando execução: $($f.FullName)"
        if ($DryRun) {
            Write-Log "Simulado: executar $($f.FullName)"
            continue
        }
        if ($f.Extension.ToLower() -eq '.py') {
            $exe = 'python'
            try {
                $proc = Start-Process -FilePath $exe -ArgumentList @($f.FullName) -Wait -NoNewWindow -PassThru -ErrorAction Stop
                Write-Log "Processo finalizado: ExitCode $($proc.ExitCode)"
            } catch {
                Write-Log "Falha ao executar python $($f.FullName): $($_.Exception.Message)" "ERROR"
            }
        } else {
            $psExe = if ($UsePwsh) { 'pwsh' } else { 'powershell' }
            $arg = "-NoProfile -ExecutionPolicy Bypass -File `"$($f.FullName)`""
            try {
                $proc = Start-Process -FilePath $psExe -ArgumentList $arg -Wait -NoNewWindow -PassThru -ErrorAction Stop
                Write-Log "Processo finalizado: ExitCode $($proc.ExitCode)"
            } catch {
                Write-Log "Falha ao executar $($f.FullName): $($_.Exception.Message)" "ERROR"
            }
        }
    }
}

# -------------------------
# Deploy / versionamento do FULLONE (opcional)
# -------------------------
if ($Deploy) {
    Write-Log "Deploy solicitado: copiando FULLONE para pastas de integração (confirmando)."
    $scriptPath = $MyInvocation.MyCommand.Definition
    $targets = @(
        Safe-JoinPath -Path $RootPath -Child 'scripts\SCRIPTS BASE OFICIAIS',
        Safe-JoinPath -Path $RootPath -Child 'SCRIPT MESTRE',
        Safe-JoinPath -Path $RootPath -Child 'PACKAGES OFICIAIS'
    )
    foreach ($t in $targets) {
        if (-not (Test-Path -LiteralPath $t -PathType Container)) {
            try { New-Item -ItemType Directory -Path $t -Force | Out-Null } catch { Write-Log "Falha criando target $t: $($_.Exception.Message)" "WARN" }
        }
        $baseName = 'FULLONE'
        $existing = Get-ChildItem -Path $t -Filter "$baseName*.ps1" -File -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1
        if ($existing) {
            $digits = ([regex]::Matches($existing.BaseName,'\d+')) | Select-Object -Last 1
            if ($digits) { $num = [int]$digits.Value + 1 } else { $num = 1 }
        } else { $num = 1 }
        $dest = Join-Path -Path $t -Child ("{0}{1:D4}.ps1" -f $baseName,$num)
        if ($DryRun) {
            Write-Log "Simulado: copiar $scriptPath -> $dest"
        } else {
            try { Copy-Item -LiteralPath $scriptPath -Destination $dest -Force; Write-Log "Copiado $scriptPath -> $dest" } catch { Write-Log "Falha no deploy $dest: $($_.Exception.Message)" "ERROR" }
        }
    }
}

# -------------------------
# Finalizar e salvar relatório detalhado
# -------------------------
$report = New-Object System.Collections.Generic.List[string]
$report.AddRange($summary)
$report.Add("")
$report.Add("Detalhes:")
$report.Add("Total arquivos: $totalCount")
$report.Add("Duplicados por conteúdo (grupos): $($dupByContent.Count)")
$report.Add("Mesmo nome em múltiplas pastas: $($dupByName.Count)")
$report.Add("")
if ($AutoFix) {
    $report.Add("AutoFix summary:")
    $fixSummary | ForEach-Object { $report.Add($_) }
}
$report.Add("")
$report.Add("Compiled file: " + (if ($DryRun) { $simulatedCompiledPath } else { $compiledPath }))
$report.Add("")
$report.Add("LOG: " + $LogFile)
$report.Add("")
$report.Add("Fim do relatório.")
try { $report | Out-File -FilePath $reportFile -Encoding UTF8 -Force } catch { Write-Log "Falha salvando relatório final: $($_.Exception.Message)" "ERROR" }

Write-Log "FULLONE finalizado. Relatório salvo em: $reportFile"
if ($DryRun) { Write-Log "Recomendo revisar relatório e rodar sem -DryRun e com -AutoFix somente após confirmar." }

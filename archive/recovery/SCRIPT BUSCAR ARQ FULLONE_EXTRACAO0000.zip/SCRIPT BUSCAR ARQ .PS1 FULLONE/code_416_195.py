    # Cria ZIP incremental
    zip_path = criar_zip(unificado_path)

    # Gera fluxograma
    fluxograma_path = gerar_fluxograma()

    # Gera PDF detalhado
    pdf_path = gerar_pdf(todos_arquivos, unificado_path, zip_path, fluxograma_path)

    print("\n=== PROCESSO COMPLETO FINALIZADO ===")

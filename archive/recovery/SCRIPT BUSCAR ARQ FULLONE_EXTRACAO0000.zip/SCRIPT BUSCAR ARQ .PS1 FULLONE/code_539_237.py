def atualizar_script_oficial():
    """Atualiza o script a partir da versão oficial"""
    arquivo_oficial = Path(PASTA_OFICIAL) / "criar-pacotes.py"
    arquivo_exec = Path(PASTA_EXEC) / "criar-pacotes.py"

    if not arquivo_oficial.exists():
        print(f"[AVISO] Nenhum arquivo oficial encontrado em: {PASTA_OFICIAL}")
        # Cria a pasta se não existir
        Path(PASTA_OFICIAL).mkdir(parents=True, exist_ok=True)
        arquivo_oficial.touch()
        print(f"[INFO] Arquivo oficial criado: {arquivo_oficial}")
        return

    atualizar = False
    if not arquivo_exec.exists():
        atualizar = True
    else:
        if arquivo_oficial.read_bytes() != arquivo_exec.read_bytes():
            atualizar = True

    if atualizar:
        if arquivo_exec.exists():
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = arquivo_exec.with_name(f"{arquivo_exec.stem}_backup_{timestamp}.py")
            shutil.copy2(arquivo_exec, backup_path)
            print(f"[INFO] Backup do script antigo salvo: {backup_path}")

        shutil.copy2(arquivo_oficial, arquivo_exec)
        print("[INFO] Script atualizado automaticamente.")

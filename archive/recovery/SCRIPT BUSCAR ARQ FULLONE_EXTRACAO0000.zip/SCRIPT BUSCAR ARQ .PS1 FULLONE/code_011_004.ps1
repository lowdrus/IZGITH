  Set-ExecutionPolicy Bypass -Scope Process -Force
  .\FULLONEv00003.ps1
  
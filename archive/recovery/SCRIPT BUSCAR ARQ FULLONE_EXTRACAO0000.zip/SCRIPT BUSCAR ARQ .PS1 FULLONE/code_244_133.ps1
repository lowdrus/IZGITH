$unifiedPS1Path = "C:\SCRIPTS\PACKAGE\FULLONEv14_package\FULLONE_UNIFIED.ps1"
New-Item -ItemType Directory -Path (Split-Path $unifiedPS1Path) -Force | Out-Null
"`# ==================== Unified Script ====================" | Out-File -FilePath $unifiedPS1Path -Encoding UTF8

foreach ($file in $allFiles) {
    "`n`# ===== File: $($file.FullName) =====" | Out-File -FilePath $unifiedPS1Path -Encoding UTF8 -Append
    Get-Content $file.FullName | Out-File -FilePath $unifiedPS1Path -Encoding UTF8 -Append
}
Write-Output "Unified PS1 created at: $unifiedPS1Path"

     Write-Log -Message ("Falha salvando relatório inicial: {0}" -f $_.Exception.Message) -Level "WARN"
     
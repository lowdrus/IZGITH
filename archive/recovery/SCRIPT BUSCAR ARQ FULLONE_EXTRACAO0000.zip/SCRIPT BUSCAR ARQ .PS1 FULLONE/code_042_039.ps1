.\FULLONE-correção7.ps1 -DryRun:$false -AutoFix -Exec -Deploy -UsePwsh

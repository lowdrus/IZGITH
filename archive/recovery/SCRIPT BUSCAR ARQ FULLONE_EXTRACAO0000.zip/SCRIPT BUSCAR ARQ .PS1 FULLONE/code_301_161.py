import os
import zipfile

# Função para buscar arquivos .ps1 e .py em um diretório
def buscar_arquivos(diretorio):
    arquivos = []
    for root, dirs, files in os.walk(diretorio):
        for file in files:
            if file.endswith(('.ps1', '.py')):
                arquivos.append(os.path.join(root, file))
    return arquivos

# Função para criar o arquivo unificado FULLONE_UNIFIED.ps1
def criar_unificado(arquivos, pasta_saida):
    with open(os.path.join(pasta_saida, 'FULLONE_UNIFIED.ps1'), 'w') as unificado:
        for arquivo in arquivos:
            with open(arquivo, 'r') as f:
                unificado.write(f.read() + "\n\n")

# Função para criar o arquivo ZIP
def criar_zip(arquivos, pasta_saida, nome_zip):
    with zipfile.ZipFile(os.path.join(pasta_saida, nome_zip), 'w', zipfile.ZIP_DEFLATED) as zipf:
        for arquivo in arquivos:
            zipf.write(arquivo, os.path.relpath(arquivo, pasta_saida))

# Definindo os diretórios
pastas = [
    r"C:\CONAV TRADER",
    r"C:\MAGIC QUANTIC TRADER",
    r"C:\USERAT",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\UNIC QUANTIC"
]

# Pasta de saída
pasta_saida = r"C:\SCRIPTS\FULL ONE\PACKAGE"

# Buscando arquivos
todos_arquivos = []
for pasta in pastas:
    if os.path.exists(pasta):
        todos_arquivos.extend(buscar_arquivos(pasta))

# Criando o arquivo unificado
criar_unificado(todos_arquivos, pasta_saida)

# Criando o arquivo ZIP
criar_zip(todos_arquivos, pasta_saida, "FULLONEv14fixed2.zip")

print(f"Processo concluído! {len(todos_arquivos)} arquivos encontrados e ZIP gerado em {pasta_saida}")

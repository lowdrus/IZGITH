$SearchPaths = @(
    "C:\CONAV TRADER",
    "C:\CONAV TRADER\CONAV_TRADER\automation",
    "C:\CONAV TRADER\CONAV_TRADER\build",
    "C:\CONAV TRADER\CONAV_TRADER\dashboard",
    "C:\CONAV TRADER\CONAV_TRADER\data",
    ...
    "C:\UNIC QUANTIC\scripts\SETUP UNIC PARTE 1",
    "C:\UNIC QUANTIC\tools"
)

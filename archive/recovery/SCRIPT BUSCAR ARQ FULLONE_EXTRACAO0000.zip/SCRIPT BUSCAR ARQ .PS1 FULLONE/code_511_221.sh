  FULLONE_Avancado_Complete/
  ├── scripts/
  │   ├── ps1/
  │   └── py/
  ├── FULLONE_Avancado_Complete.py
  ├── comparativos.pdf
  └── arquivos.zip
  
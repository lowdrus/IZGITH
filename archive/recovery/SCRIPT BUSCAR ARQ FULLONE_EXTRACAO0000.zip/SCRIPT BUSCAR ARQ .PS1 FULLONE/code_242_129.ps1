   $searchPaths = @(
       "C:\CONAV TRADER",
       "C:\CONAV TRADER\CONAV_TRADER\automation",
       "C:\CONAV TRADER\CONAV_TRADER\build",
       # ... (todas as outras pastas que você listou)
       "C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE ALL IN ONE 004"
   )
   
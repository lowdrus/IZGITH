.\FULLONE.ps1 -BuildExe

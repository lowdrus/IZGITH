   pip uninstall --yes pypdf
   pip install --upgrade fpdf2
   
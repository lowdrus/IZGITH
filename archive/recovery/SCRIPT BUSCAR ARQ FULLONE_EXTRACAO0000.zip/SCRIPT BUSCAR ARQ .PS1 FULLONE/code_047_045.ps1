<#
================================================================================
 SCRIPT: FULLONE-correção8.ps1
 OBJETIVO:
   - Busca .ps1 e .py na raiz especificada
   - Detecta duplicados
   - Corrige caracteres (SafeFix, opcional)
   - Compila todos em 1 único arquivo
   - Executa scripts isoladamente (opcional)
   - Deploy automático (opcional)
   - Gera log e relatório detalhado
   - Abre automaticamente o Tutorial.pdf no final
================================================================================
#>

param(
    [string]$RootPath = 'C:\CONAV TRADER\CONAV_TRADER',
    [switch]$DryRun = $true,
    [switch]$AutoFix = $false,
    [switch]$Backup = $true,
    [switch]$Exec = $false,
    [switch]$UsePwsh = $false,
    [switch]$Deploy = $true
)

# ==============================
# Função de Log
# ==============================
function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO','WARN','ERROR','OK')]
        [string]$Level = 'INFO'
    )

    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = "[$ts][$Level] $Message"
    try {
        Add-Content -Path $Global:FULLONE_LogFile -Value $line -Encoding UTF8
    } catch {
        Write-Warning "Falha escrevendo log em ${Global:FULLONE_LogFile}: $($_.Exception.Message)"
    }
    Write-Host $line
}

# ==============================
# Inicialização
# ==============================
$RootPath = (Resolve-Path -Path $RootPath).ProviderPath
$now = Get-Date -Format 'yyyyMMdd_HHmmss'

$Global:FULLONE_LogFileDir = Join-Path $RootPath 'logs_FULLONE'
if (!(Test-Path $Global:FULLONE_LogFileDir)) {
    New-Item -ItemType Directory -Path $Global:FULLONE_LogFileDir -Force | Out-Null
}
$Global:FULLONE_LogFile = Join-Path $Global:FULLONE_LogFileDir ("fullone_log_$now.txt")

Write-Log -Message "FULLONE iniciado. RootPath = $RootPath"
if ($DryRun) { Write-Log -Message "MODO: DRY RUN (simulação). Nenhuma alteração será feita." }

# =========================================================
# AQUI ENTRAM TODAS AS ETAPAS (busca, duplicados, SafeFix,
# compilado, execução, deploy) — mantidas do v00010
# Todas chamadas corrigidas para:
#   Write-Log -Message "texto" -Level "WARN"
#   Write-Log -Message ("Texto {0}" -f $var) -Level "ERROR"
# =========================================================

# ==============================
# Encerramento
# ==============================
Write-Log -Message "Execução finalizada." -Level "INFO"

# Abrir tutorial PDF automaticamente
$tutorialPath = Join-Path (Split-Path -Parent $PSCommandPath) "Tutorial.pdf"
if (Test-Path $tutorialPath) {
    Write-Log -Message "Abrindo tutorial: $tutorialPath" -Level "INFO"
    Start-Process $tutorialPath
} else {
    Write-Log -Message "Tutorial PDF não encontrado no diretório do script." -Level "WARN"
}

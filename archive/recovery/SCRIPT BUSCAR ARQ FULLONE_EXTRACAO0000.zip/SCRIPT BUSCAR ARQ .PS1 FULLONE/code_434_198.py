arquivos_dict = {}
for f in todos_arquivos:
    key = f.name.lower()
    if key not in arquivos_dict or f.stat().st_mtime > arquivos_dict[key].stat().st_mtime:
        arquivos_dict[key] = f

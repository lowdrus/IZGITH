Set-ExecutionPolicy Bypass -Scope Process -Force
.\FULLONE.ps1
# ou explicitamente
.\FULLONE.ps1 -DryRun:$true

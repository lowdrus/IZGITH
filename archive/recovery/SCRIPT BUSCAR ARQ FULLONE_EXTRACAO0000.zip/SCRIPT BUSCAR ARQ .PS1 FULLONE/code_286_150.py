import os
import zipfile
from datetime import datetime

# -----------------------------
# CONFIGURAÇÕES DE PASTAS
# -----------------------------
# Pastas para buscar arquivos
search_folders = [
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\collections",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\encodings",
    r"C:\CONAV TRADER\CONAV_TRADER\build\Desinstalar\base_library.zip\re",
    r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\main_dashboard\base_library.zip",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\localpycs",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\collections",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\re",
    r"C:\CONAV TRADER\CONAV_TRADER\build\uninstall_wrapper\base_library.zip\encodings",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar\build",
    r"C:\CONAV TRADER\CONAV_TRADER\mapas de fluxograma",
    r"C:\CONAV TRADER\CONAV_TRADER\PACKAGES OFICIAIS",
    r"C:\CONAV TRADER\CONAV_TRADER\SCRIPT MESTRE",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\0001",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\0002",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\0003",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\004",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\aleatorios versoes 1.30+",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\PACKAGES OFICIAIS",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\SCRIPTS BASE OFICIAIS",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\SCRIPTS DE LISTAGEM",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts\uninstall versoes 1.30+",
    r"C:\CONAV TRADER\CONAV_TRADER\SCRIPTS DE LISTAGEM",
    r"C:\CONAV TRADER\CONAV_TRADER\SCRIPTS BASE OFICIAIS",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\TUTORIAL GERAL",
    r"C:\CONAV TRADER\CONAV_TRADER\CONAV MASTER FULL",
    r"C:\CONAV TRADER\dist",
    r"C:\CONAV TRADER\logs",
    r"C:\MAGIC QUANTIC TRADER\MEGA SUITE 001",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE 002",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE 003",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE ALL IN ONE 004",
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\USERAT\scripts\scripts 2",
    r"C:\USERAT\scripts\scripts 2\compiladao",
    r"C:\USERAT\USERAT_Projeto_Completo",
    r"C:\USERAT\USERAT_Projeto_Completo\scripts",
    r"C:\USERAT\USERAT_Projeto_Completo\scripts\scripts 2",
    r"C:\USERAT\USERAT_Projeto_Completo\scripts\scripts 2\compiladao",
    r"C:\USERAT\USERAT_Projeto_Completo\tutoriais",
    r"C:\USERAT1",
    r"C:\USERAT1\USERAT_Final_Atualizado",
    r"C:\USERAT1\USERAT_Final_Atualizado\scripts",
    r"C:\USERAT2",
    r"C:\USERAT2\RAR USERASTS\USERAT_Final_Atualizado",
    r"C:\USERAT2\RAR USERASTS\USERAT_Final_Atualizado\scripts",
    r"C:\USERAT2\scripts",
    r"C:\USERAT2\SCRPITS PS1",
    r"C:\USERAT2\USERAT_Final_Atualizado",
    r"C:\TESTEE 2",
    r"C:\TESTEE 2\A3",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\TESTEE 2\ARQUIVOS",
    r"C:\TESTEE 2\ARQUIVOS\2 ADVANCED",
    r"C:\TESTEE 2\ARQUIVOS\Output",
    r"C:\TESTEE 3\AI_Trade_Suite_Full_Deliverable",
    r"C:\UNIC QUANTIC",
    r"C:\UNIC QUANTIC\backend",
    r"C:\UNIC QUANTIC\database",
    r"C:\UNIC QUANTIC\frontend",
    r"C:\UNIC QUANTIC\logs",
    r"C:\UNIC QUANTIC\pdfs",
    r"C:\UNIC QUANTIC\scripts",
    r"C:\UNIC QUANTIC\scripts\SCRIPTS OPCIONAIS",
    r"C:\UNIC QUANTIC\scripts\SETUP UNIC PARTE 1",
    r"C:\UNIC QUANTIC\tools"
]

# -----------------------------
# PASTAS DE SAÍDA
# -----------------------------
UNIFIED_FOLDER = r"C:\SCRIPTS\FULL ONE\ARQUIVOS .PS1 UNIFICADOS"
GENERATOR_FOLDER = r"C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR"
COMPILED_FOLDER = r"C:\SCRIPTS\FULL ONE\COMPILADOS"
DEFAULT_ZIP_FOLDER = r"C:\SCRIPTS\FULL ONE\PACKAGE"

os.makedirs(UNIFIED_FOLDER, exist_ok=True)
os.makedirs(GENERATOR_FOLDER, exist_ok=True)
os.makedirs(COMPILED_FOLDER, exist_ok=True)
os.makedirs(DEFAULT_ZIP_FOLDER, exist_ok=True)

# -----------------------------
# BUSCAR ARQUIVOS
# -----------------------------
all_files = []
for folder in search_folders:
    if os.path.exists(folder):
        for root, dirs, files in os.walk(folder):
            for f in files:
                if f.lower().endswith(('.ps1', '.py')):
                    all_files.append(os.path.join(root, f))

print(f"Total de arquivos encontrados: {len(all_files)}")
for f in all_files:
    print(f)

# -----------------------------
# CRIAR ARQUIVO UNIFICADO
# -----------------------------
unified_file_path = os.path.join(UNIFIED_FOLDER, "FULLONE_UNIFIED.ps1")

with open(unified_file_path, "w", encoding="utf-8") as outfile:
    for file_path in all_files:
        outfile.write(f"\n# ---------------- {os.path.basename(file_path)} ----------------\n")
        if file_path.lower().endswith(".ps1"):
            with open(file_path, "r", encoding="utf-8") as infile:
                outfile.write(infile.read())
        elif file_path.lower().endswith(".py"):
            with open(file_path, "r", encoding="utf-8") as infile:
                content = infile.read()
                # adiciona como comentário no PS1
                outfile.write("\n".join([f"# {line}" for line in content.splitlines()]))
                outfile.write("\n")
print(f"\nArquivo unificado gerado em: {unified_file_path}")

# -----------------------------
# CRIAR ZIP OPCIONAL
# -----------------------------
zip_folder = input(f"Informe a pasta para salvar o ZIP (Enter para padrão: {DEFAULT_ZIP_FOLDER}): ").strip()
if not zip_folder:
    zip_folder = DEFAULT_ZIP_FOLDER
os.makedirs(zip_folder, exist_ok=True)

zip_name = f"FULLONEv14fixed2.zip"
zip_path = os.path.join(zip_folder, zip_name)

with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    for file_path in all_files:
        zf.write(file_path, arcname=os.path.relpath(file_path, start=GENERATOR_FOLDER))
    # adicionar o arquivo unificado
    zf.write(unified_file_path, arcname=os.path.basename(unified_file_path))

print(f"ZIP criado em: {zip_path}")

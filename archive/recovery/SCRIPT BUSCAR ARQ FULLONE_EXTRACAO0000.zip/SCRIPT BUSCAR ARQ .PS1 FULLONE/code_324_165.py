import os
import shutil
from pathlib import Path
import zipfile
from datetime import datetime

# --------------------------
# CONFIGURAÇÕES DE PASTAS
# --------------------------
PASTAS_PROCURAR = [
    r"C:\CONAV TRADER",
    r"C:\CONAV TRADER\CONAV_TRADER\automation",
    r"C:\CONAV TRADER\CONAV_TRADER\build",
    r"C:\CONAV TRADER\CONAV_TRADER\dashboard",
    r"C:\CONAV TRADER\CONAV_TRADER\data",
    r"C:\CONAV TRADER\CONAV_TRADER\database",
    r"C:\CONAV TRADER\CONAV_TRADER\Desinstalar",
    r"C:\CONAV TRADER\CONAV_TRADER\dist",
    r"C:\CONAV TRADER\CONAV_TRADER\docs",
    r"C:\CONAV TRADER\CONAV_TRADER\emails",
    r"C:\CONAV TRADER\CONAV_TRADER\icons",
    r"C:\CONAV TRADER\CONAV_TRADER\logs",
    r"C:\CONAV TRADER\CONAV_TRADER\relatórios",
    r"C:\CONAV TRADER\CONAV_TRADER\resources",
    r"C:\CONAV TRADER\CONAV_TRADER\scripts",
    r"C:\CONAV TRADER\CONAV_TRADER\tools",
    r"C:\CONAV TRADER\CONAV_TRADER\automation\autocorrector",
    r"C:\MAGIC QUANTIC TRADER\MQT PACKAGE COMPLETE ALL IN ONE 004",
    r"C:\USERAT",
    r"C:\USERAT\scripts",
    r"C:\TESTEE 2\AI_Trade_Suite",
    r"C:\UNIC QUANTIC",
]

PASTA_SOLTOS = r"C:\SCRIPTS\FULL ONE\FULL ONE GENERATOR"
PASTA_UNIFICADO = r"C:\SCRIPTS\FULL ONE\ARQUIVOS .PS1 UNIFICADOS"
PASTA_COMPILADOS = r"C:\SCRIPTS\FULL ONE\COMPILADOS"
PASTA_PACKAGE = r"C:\SCRIPTS\FULL ONE\PACKAGE"

# Nome do PS1 unificado e ZIP
NOME_PS1_UNIFICADO = "ONEFULL.ps1"
NOME_ZIP = "FULLONEv14fixed2.zip"

# --------------------------
# CRIAR PASTAS SE NÃO EXISTIREM
# --------------------------
for pasta in [PASTA_SOLTOS, PASTA_UNIFICADO, PASTA_COMPILADOS, PASTA_PACKAGE]:
    os.makedirs(pasta, exist_ok=True)

# --------------------------
# BUSCAR ARQUIVOS .PS1 E .PY
# --------------------------
todos_arquivos = []
for base in PASTAS_PROCURAR:
    base_path = Path(base)
    if base_path.exists():
        for ext in ('*.ps1', '*.py'):
            encontrados = list(base_path.rglob(ext))
            todos_arquivos.extend(encontrados)

print(f"Total de arquivos encontrados: {len(todos_arquivos)}")
for f in todos_arquivos:
    print(f)

# --------------------------
# CRIAR PS1 UNIFICADO
# --------------------------
ps1_unificado_path = Path(PASTA_UNIFICADO) / NOME_PS1_UNIFICADO

# Backup do antigo, se existir
if ps1_unificado_path.exists():
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = ps1_unificado_path.with_name(f"{ps1_unificado_path.stem}_backup_{timestamp}.ps1")
    shutil.move(ps1_unificado_path, backup_path)
    print(f"Backup do PS1 unificado antigo salvo em: {backup_path}")

# Cabeçalho do PS1 unificado
cabecalho = f"""
# =============================================
# FULLONEv14fixed2 - PS1 Unificado (ONEFULL)
# Gerado em {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
# =============================================
"""

with open(ps1_unificado_path, 'w', encoding='utf-8') as f:
    f.write(cabecalho + "\n")
    for arquivo in todos_arquivos:
        try:
            with open(arquivo, 'r', encoding='utf-8') as af:
                conteudo = af.read()
            f.write(f"\n\n# ===== INICIO {arquivo.name} =====\n")
            f.write(conteudo)
            f.write(f"\n# ===== FIM {arquivo.name} =====\n")
        except Exception as e:
            print(f"[ERRO] Não foi possível ler {arquivo}: {e}")

print(f"PS1 unificado criado em: {ps1_unificado_path}")

# --------------------------
# CRIAR ZIP
# --------------------------
zip_path = Path(PASTA_PACKAGE) / NOME_ZIP

with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    # Adiciona PS1 unificado
    zipf.write(ps1_unificado_path, arcname=NOME_PS1_UNIFICADO)

    # Adiciona arquivos soltos
    for arquivo in todos_arquivos:
        zipf.write(arquivo, arcname=arquivo.name)

    # Adiciona PDFs se existirem na pasta de origem
    pdfs = ['TUTORIAL.pdf', 'GUIA-RÁPIDO.pdf', 'MANUAL.pdf']
    for pdf in pdfs:
        pdf_path = Path(PASTA_SOLTOS) / pdf
        if pdf_path.exists():
            zipf.write(pdf_path, arcname=pdf)

print(f"ZIP criado em: {zip_path}")
print("FULLONEv14fixed2 gerado com sucesso ✅")

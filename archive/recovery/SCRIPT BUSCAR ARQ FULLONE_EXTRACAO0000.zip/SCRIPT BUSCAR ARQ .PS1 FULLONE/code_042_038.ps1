Set-ExecutionPolicy Bypass -Scope Process -Force
.\FULLONE-correção7.ps1

Write-Log -Message ("Falha no deploy {0}: {1}" -f $t, $_.Exception.Message) -Level "ERROR"
